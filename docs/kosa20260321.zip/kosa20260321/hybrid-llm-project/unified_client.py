# ============================================================
# 실습 6: 통합 LLM 클라이언트 (unified_client.py)
# ============================================================
# [필수 설치]
#   pip install openai python-dotenv
#
# [사전 준비]
#   - .env 파일에 OPENAI_API_KEY 설정
#   - Ollama 서버 실행 (선택사항, ollama로만 테스트 가능)
#
# [실행 방법]
#   python unified_client.py
#
# [예상 출력]
#   OpenAI 호출: "Python은..." (응답)
#   Ollama 호출: "Python is..." (응답)
#
# [특징]
#   - OpenAI와 Ollama를 동일 인터페이스로 사용
#   - 프로바이더 자동 감지 (모델명으로)
#   - 스트리밍 지원
# ============================================================

from openai import OpenAI
from dotenv import load_dotenv
import os
from typing import Optional, List, Dict, Any

class UnifiedLLMClient:
    """
    OpenAI와 Ollama를 통일된 인터페이스로 제공하는 클래스
    
    사용법:
        client = UnifiedLLMClient()
        response = client.chat("질문", model="gpt-4o-mini")  # OpenAI
        response = client.chat("질문", model="mistral:7b")   # Ollama
    """
    
    def __init__(self):
        """
        통합 클라이언트를 초기화합니다
        """
        # (1) 환경변수 로드
        load_dotenv()
        
        # (2) OpenAI 클라이언트 생성
        self.openai_client = OpenAI(
            api_key=os.getenv("OPENAI_API_KEY")
        )
        
        # (3) Ollama 클라이언트 생성 (OpenAI SDK 호환 모드)
        self.ollama_client = OpenAI(
            api_key="ollama",  # 더미 값
            base_url="http://localhost:11434/v1"
        )
        
        # (4) 모델 정보 저장
        self.openai_models = [
            "gpt-4o",
            "gpt-4o-mini",
            "gpt-4-turbo",
            "gpt-3.5-turbo"
        ]
        
        self.ollama_models = [
            "gemma3:4b"
            "mistral:7b",
            "llama2:7b",
            "neural-chat:7b",
            "orca-mini:3b",
            "vicuna:13b"
        ]
    
    def _detect_provider(self, model: str) -> str:
        """
        모델명으로 프로바이더를 자동 감지합니다
        
        Args:
            model: 모델명
            
        Returns:
            "openai" 또는 "ollama"
        """
        # (1) 모델명이 OpenAI 목록에 있으면 openai
        if any(m in model for m in self.openai_models):
            return "openai"
        
        # (2) 그 외는 ollama (Ollama는 "모델:태그" 형식)
        return "ollama"
    
    def chat(
        self,
        message: str,
        model: str = "gpt-4o-mini",
        temperature: float = 0.7,
        max_tokens: int = 500,
        stream: bool = False
    ) -> str:
        """
        질문에 대한 답변을 받습니다
        
        Args:
            message: 사용자 질문
            model: 사용할 모델
            temperature: 창의성 (0~2)
            max_tokens: 최대 응답 길이
            stream: 스트리밍 여부
            
        Returns:
            모델의 응답 텍스트
        """
        # (1) 프로바이더 자동 감지
        provider = self._detect_provider(model)
        
        # (2) 해당 클라이언트 선택
        if provider == "openai":
            client = self.openai_client
        else:
            client = self.ollama_client
        
        # (3) 프로바이더별로 API 호출
        try:
            if stream:
                # (4) 스트리밍 모드
                stream_response = client.chat.completions.create(
                    model=model,
                    messages=[{"role": "user", "content": message}],
                    temperature=temperature,
                    max_tokens=max_tokens,
                    stream=True
                )
                
                # (5) 청크를 모아서 전체 응답 생성
                full_response = ""
                for chunk in stream_response:
                    if chunk.choices[0].delta.content:
                        full_response += chunk.choices[0].delta.content
                
                return full_response
            else:
                # (6) 일반 모드 (전체 응답 한 번에)
                response = client.chat.completions.create(
                    model=model,
                    messages=[{"role": "user", "content": message}],
                    temperature=temperature,
                    max_tokens=max_tokens,
                    stream=False
                )
                
                return response.choices[0].message.content
        
        except Exception as e:
            # (7) 오류 처리
            return f"오류 발생: {str(e)}"
    
    def chat_with_history(
        self,
        messages: List[Dict[str, str]],
        model: str = "gpt-4o-mini",
        temperature: float = 0.7,
        max_tokens: int = 500
    ) -> str:
        """
        대화 히스토리를 포함한 응답을 받습니다
        
        Args:
            messages: 메시지 리스트
                [{"role": "user", "content": "..."},
                 {"role": "assistant", "content": "..."},
                 ...]
            model: 사용할 모델
            temperature: 창의성
            max_tokens: 최대 길이
            
        Returns:
            모델의 응답
        """
        # (1) 프로바이더 감지
        provider = self._detect_provider(model)
        
        # (2) 클라이언트 선택
        if provider == "openai":
            client = self.openai_client
        else:
            client = self.ollama_client
        
        # (3) API 호출 (히스토리 포함)
        try:
            response = client.chat.completions.create(
                model=model,
                messages=messages,
                temperature=temperature,
                max_tokens=max_tokens
            )
            
            return response.choices[0].message.content
        
        except Exception as e:
            return f"오류 발생: {str(e)}"
    
    def get_token_count_estimate(self, text: str) -> int:
        """
        텍스트의 대략적인 토큰 수를 추정합니다
        
        Args:
            text: 텍스트
            
        Returns:
            추정 토큰 수
        """
        # (1) 간단한 추정 (정확하지 않음)
        #     일반적으로: 4글자 ≈ 1 토큰
        #     한국어: 2~3글자 ≈ 1 토큰 (더 많음)
        
        # (2) 한국어와 영어 구분
        korean_count = sum(1 for c in text if ord(c) >= 0xAC00)
        english_count = len(text) - korean_count
        
        # (3) 추정
        korean_tokens = korean_count // 2  # 보수적 추정
        english_tokens = english_count // 4
        
        return korean_tokens + english_tokens


# ========== 테스트 ==========
if __name__ == "__main__":
    print("=" * 60)
    print("UnifiedLLMClient 테스트")
    print("=" * 60 + "\n")
    
    # (1) 클라이언트 생성
    client = UnifiedLLMClient()
    
    # (2) OpenAI로 테스트
    print("[OpenAI 호출]")
    print("질문: Python이란?")
    response_openai = client.chat(
        "Python이란 무엇인가요? 3줄로 요약해주세요.",
        model="gpt-4o-mini",
        max_tokens=200
    )
    print(f"응답: {response_openai[:100]}...\n")
    
    # (3) Ollama로 테스트 (선택사항)
    try:
        print("[Ollama 호출]")
        print("질문: Python이란?")
        response_ollama = client.chat(
            "Python이란 무엇인가요? 3줄로 요약해주세요.",
            model="mistral:7b",
            max_tokens=200
        )
        print(f"응답: {response_ollama[:100]}...\n")
    except Exception as e:
        print(f"[Ollama 오류] {e} (Ollama 서버 미실행)\n")
    
    # (4) 토큰 수 추정
    text = "Python은 프로그래밍 언어입니다. AI를 배우기에 좋습니다."
    tokens = client.get_token_count_estimate(text)
    print(f"토큰 수 추정: '{text}'")
    print(f"추정 토큰: {tokens}\n")
    
    # (5) 대화 히스토리 테스트
    print("[대화 히스토리 테스트]")
    history = [
        {"role": "user", "content": "Python 배우기 시작했어요"},
        {"role": "assistant", "content": "좋습니다! Python은 배우기 쉬운 언어입니다."},
        {"role": "user", "content": "추천 자료가 있나요?"}
    ]
    
    response = client.chat_with_history(
        history,
        model="gpt-4o-mini",
        max_tokens=200
    )
    print(f"응답: {response}\n")
    
    print("=" * 60)
