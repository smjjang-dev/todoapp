# ============================================================
# 실습 10: Hybrid Engine 조립 (hybrid_engine.py)
# ============================================================
# [필수 설치]
#   pip install openai python-dotenv numpy
#
# [사전 준비]
#   - unified_client.py, provider_router.py, model_tiering.py,
#     cache_layer.py가 같은 폴더에 있어야 함
#   - .env 파일 설정
#   - Ollama 서버 실행
#
# [실행 방법]
#   python hybrid_engine.py
#
# [아키텍처]
#   
#   사용자 질문
#        ↓
#   [1] 캐시 확인 (SQLite)
#        ├─ Exact Hit → 즉시 응답
#        └─ Semantic Hit → 즉시 응답
#        ↓
#   [2] PII 감지 (Provider Router)
#        ├─ 있음 → Ollama 선택
#        └─ 없음 → 다음 단계
#        ↓
#   [3] 복잡도 분류 (Model Tiering)
#        ├─ 간단 → gpt-4o-mini
#        └─ 복잡 → gpt-4o
#        ↓
#   [4] LLM 호출 (Unified Client)
#        ├─ 응답 획득
#        └─ 캐시에 저장
#        ↓
#   최종 응답
#
# [기능]
#   - 통합 라우팅 (PII + 복잡도 + 캐시)
#   - 자동 모델 선택
#   - 통계 추적 및 비용 계산
# ============================================================

import time
from typing import Dict, Any
from unified_client import UnifiedLLMClient
from provider_router import ProviderRouter
from model_tiering import ModelTieringRouter
from cache_layer import SQLiteCacheLayer

class HybridEngine:
    """
    완전한 Hybrid LLM 엔진
    
    조립된 모듈들:
    1. cache_layer.py - 캐시 레이어
    2. provider_router.py - PII 감지 & OpenAI/Ollama 라우팅
    3. model_tiering.py - 복잡도 분류 & 모델 선택
    4. unified_client.py - 통합 LLM 호출
    """
    
    def __init__(
        self,
        cache_db: str = "hybrid_cache.db",
        complexity_threshold: int = 30
    ):
        """
        Hybrid Engine 초기화
        
        Args:
            cache_db: 캐시 데이터베이스 경로
            complexity_threshold: 복잡도 임계값
        """
        # (1) 각 모듈 초기화
        print("[엔진 초기화] Hybrid LLM Engine")
        
        self.cache_layer = SQLiteCacheLayer(db_path=cache_db)
        print("  ✓ 캐시 레이어 준비")
        
        self.provider_router = ProviderRouter()
        print("  ✓ Provider Router 준비")
        
        self.model_tiering = ModelTieringRouter(complexity_threshold=complexity_threshold)
        print("  ✓ Model Tiering Router 준비")
        
        self.unified_client = UnifiedLLMClient()
        print("  ✓ Unified Client 준비")
        
        # (2) 통계 추적
        self.stats = {
            'total_requests': 0,
            'cache_hits': 0,
            'exact_hits': 0,
            'semantic_hits': 0,
            'pii_routed_to_ollama': 0,
            'total_tokens': 0,
            'total_cost': 0.0,
            'response_times': []
        }
    
    def process_query(
        self,
        query: str,
        temperature: float = 0.7,
        max_tokens: int = 500
    ) -> Dict[str, Any]:
        """
        질문을 전체 Hybrid 파이프라인으로 처리합니다
        
        Args:
            query: 사용자 질문
            temperature: 창의성
            max_tokens: 최대 길이
            
        Returns:
            처리 결과
        """
        # (1) 통계: 요청 카운트
        self.stats['total_requests'] += 1
        start_time = time.time()
        
        print(f"\n[요청 #{self.stats['total_requests']}] {query[:30]}...")
        
        # ========== STEP 1: 캐시 확인 ==========
        print("  [Step 1] 캐시 확인...")
        
        cache_result = self.cache_layer.get_response(query)
        if cache_result:
            # (2) 캐시 히트
            elapsed = time.time() - start_time
            
            if cache_result['match_type'] == 'exact':
                self.stats['exact_hits'] += 1
            else:
                self.stats['semantic_hits'] += 1
            
            self.stats['cache_hits'] += 1
            self.stats['response_times'].append(elapsed)
            
            print(f"    ✓ 캐시 히트! ({cache_result['match_type']})")
            print(f"    응답: {cache_result['response'][:50]}...")
            
            return {
                'query': query,
                'response': cache_result['response'],
                'source': 'cache',
                'match_type': cache_result['match_type'],
                'model': cache_result.get('model'),
                'provider': cache_result.get('provider'),
                'tokens': cache_result.get('tokens', 0),
                'cost': cache_result.get('cost', 0.0),
                'response_time': elapsed
            }
        
        print("    ✗ 캐시 미스. LLM 호출 필요")
        
        # ========== STEP 2: PII 감지 (Provider 선택) ==========
        print("  [Step 2] PII 감지...")
        
        has_pii, pii_types = self.provider_router.detect_pii(query)
        if has_pii:
            print(f"    ⚠️  PII 감지됨: {', '.join(pii_types)}")
            self.stats['pii_routed_to_ollama'] += 1
            provider_choice = 'ollama'
        else:
            print("    ✓ PII 없음")
            provider_choice = 'openai'
        
        # ========== STEP 3: 복잡도 분류 (모델 선택) ==========
        print("  [Step 3] 복잡도 분류...")
        
        complexity = self.model_tiering.calculate_complexity_score(query)
        model_choice, reason = self.model_tiering.select_model(complexity)
        
        print(f"    복잡도: {complexity}/100")
        print(f"    모델: {model_choice} ({reason})")
        
        # (3) PII가 있으면 Ollama로 오버라이드
        if has_pii:
            model_choice = "mistral:7b"
            print(f"    → PII 때문에 Ollama로 변경: {model_choice}")
        
        # ========== STEP 4: LLM 호출 (Unified Client) ==========
        print("  [Step 4] LLM 호출...")
        
        try:
            response = self.unified_client.chat(
                message=query,
                model=model_choice,
                temperature=temperature,
                max_tokens=max_tokens
            )
            
            # (4) 응답 획득 성공
            elapsed = time.time() - start_time
            
            print(f"    ✓ 응답 획득 ({elapsed:.2f}초)")
            print(f"    응답: {response[:50]}...")
            
            # ========== STEP 5: 캐시에 저장 ==========
            print("  [Step 5] 캐시 저장...")
            
            # 토큰 추정 및 비용 계산
            tokens = self.unified_client.get_token_count_estimate(response)
            
            # 비용 계산 (모델에 따라)
            if model_choice == "gpt-4o-mini":
                cost = tokens * 0.0006 / 1_000_000  # 출력 기준
            elif model_choice == "gpt-4o":
                cost = tokens * 0.015 / 1_000_000
            else:
                cost = 0.0  # Ollama는 비용 없음
            
            # (5) 캐시 저장
            cache_id = self.cache_layer.save_response(
                query=query,
                response=response,
                model=model_choice,
                provider="ollama" if has_pii else "openai",
                tokens=tokens,
                cost=cost
            )
            
            # (6) 통계 업데이트
            self.stats['total_tokens'] += tokens
            self.stats['total_cost'] += cost
            self.stats['response_times'].append(elapsed)
            
            return {
                'query': query,
                'response': response,
                'source': 'llm',
                'model': model_choice,
                'provider': "ollama" if has_pii else "openai",
                'complexity': complexity,
                'has_pii': has_pii,
                'tokens': tokens,
                'cost': cost,
                'cache_id': cache_id,
                'response_time': elapsed
            }
        
        except Exception as e:
            elapsed = time.time() - start_time
            print(f"    ✗ 오류: {str(e)}")
            
            return {
                'query': query,
                'response': f"오류 발생: {str(e)}",
                'source': 'error',
                'model': model_choice,
                'response_time': elapsed
            }
    
    def get_stats(self) -> Dict[str, Any]:
        """
        엔진 통계 조회
        
        Returns:
            통계 딕셔너리
        """
        cache_stats = self.cache_layer.get_stats()
        
        avg_response_time = (
            sum(self.stats['response_times']) / len(self.stats['response_times'])
            if self.stats['response_times'] else 0
        )
        
        cache_hit_rate = (
            self.stats['cache_hits'] / self.stats['total_requests'] * 100
            if self.stats['total_requests'] > 0 else 0
        )
        
        return {
            # 요청 통계
            'total_requests': self.stats['total_requests'],
            'cache_hits': self.stats['cache_hits'],
            'cache_hit_rate': f"{cache_hit_rate:.1f}%",
            'exact_hits': self.stats['exact_hits'],
            'semantic_hits': self.stats['semantic_hits'],
            'pii_routed_to_ollama': self.stats['pii_routed_to_ollama'],
            
            # 성능 통계
            'avg_response_time': f"{avg_response_time:.3f}초",
            'total_tokens': self.stats['total_tokens'],
            'total_cost': f"${self.stats['total_cost']:.6f}",
            
            # 캐시 통계
            'cached_items': cache_stats['total_cached'],
            'valid_cached_items': cache_stats['valid_cached'],
            'cache_savings': f"${cache_stats['cost_savings']:.6f}"
        }


# ========== 테스트 ==========
if __name__ == "__main__":
    print("=" * 60)
    print("Hybrid Engine 통합 테스트")
    print("=" * 60)
    
    # (1) 엔진 생성
    engine = HybridEngine()
    
    print()
    
    # (2) 다양한 질문 처리
    test_queries = [
        # 간단한 질문 (gpt-4o-mini 예상)
        "Python?",
        
        # 복잡한 질문 (gpt-4o 예상)
        "메모리 관리와 가비지 컬렉션의 작동 원리",
        
        # PII 포함 (Ollama 예상)
        "user@example.com의 계정 정보는?",
        
        # 캐시 재조회 (캐시 히트 예상)
        "Python?",
    ]
    
    for query in test_queries:
        result = engine.process_query(query, max_tokens=200)
    
    print("\n" + "=" * 60)
    print("엔진 통계")
    print("=" * 60)
    
    stats = engine.get_stats()
    for key, value in stats.items():
        print(f"{key}: {value}")
    
    print("=" * 60)
