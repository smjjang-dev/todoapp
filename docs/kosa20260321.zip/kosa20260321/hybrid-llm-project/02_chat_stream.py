# ============================================================
# 실습 2: 스트리밍 대화 (chat_stream.py)
# ============================================================
# [필수 설치]
#   pip install openai python-dotenv
#
# [실행 방법]
#   python chat_stream.py
#
# [예상 출력]
#   사용자: Python 배우는 가장 좋은 방법은?
#   어시스턴트: Python을 배우기 위해... (실시간으로 글자씩 출력)
#
# [주의사항]
#   - stream=True: 응답을 한 번에 받지 않고, 청크 단위로 받음
#   - 사용자 입력이 여러 번 가능 (exit 입력 시 종료)
# ============================================================

from openai import OpenAI
from dotenv import load_dotenv
import os

load_dotenv()
client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

# (1) 대화 히스토리를 저장할 리스트를 생성합니다
#     멀티턴 대화를 위해 이전 메시지들을 계속 유지해야 합니다
conversation_history = [
    {
        "role": "system",
        # system 메시지: AI의 성격/역할을 정의합니다
        # 이 메시지는 숨겨져 있고, 사용자는 보지 못합니다
        "content": "당신은 친절한 Python 튜터입니다. 초보자 수준으로 설명해주세요."
    }
]

print("=" * 60)
print("Python 튜터 챗봇 (exit 입력 시 종료)")
print("=" * 60)

while True:
    # (2) 사용자 입력을 받습니다
    user_input = input("\n사용자: ").strip()
    
    # (3) 'exit' 입력 시 대화 종료
    if user_input.lower() == "exit":
        print("안녕히 가세요!")
        break
    
    # (4) 사용자 메시지를 대화 히스토리에 추가합니다
    #     대화 히스토리는 계속 쌓여서 컨텍스트 역할을 합니다
    conversation_history.append({
        "role": "user",
        "content": user_input
    })
    
    # (5) 스트리밍 API를 호출합니다
    #     stream=True: 응답을 청크 단위로 받음 (실시간 처리 가능)
    #     messages=conversation_history: 모든 이전 대화를 포함
    stream = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=conversation_history,    # 전체 대화 히스토리 전송
        temperature=0.7,
        max_tokens=500,
        stream=True                       # ★ 이 값이 True면 스트리밍 시작
    )
    
    # (6) 스트리밍된 청크들을 처리합니다
    #     stream은 이터러블(반복 가능)이므로 for 루프로 처리
    print("어시스턴트: ", end="", flush=True)  # 프롬프트 출력
    
    # 전체 응답을 저장하기 위한 변수
    full_response = ""
    
    # 청크 단위로 응답을 받으면서 즉시 출력합니다
    for chunk in stream:
        # chunk는 StreamingChatCompletionChunk 객체
        # chunk.choices[0].delta.content에 텍스트가 있음
        if chunk.choices[0].delta.content is not None:
            # delta.content는 이 청크의 텍스트 조각
            text = chunk.choices[0].delta.content
            # end="", flush=True: 개행 없이, 즉시 출력
            print(text, end="", flush=True)
            # 전체 응답 저장 (나중에 히스토리에 추가)
            full_response += text
    
    # (7) 줄바꿈 출력
    print()
    
    # (8) 어시스턴트 응답을 대화 히스토리에 추가합니다
    #     이렇게 하면 다음 요청에서 이전 대답이 컨텍스트로 작용합니다
    conversation_history.append({
        "role": "assistant",
        "content": full_response
    })
    
    # (9) 토큰 제한 확인 (선택사항)
    #     컨텍스트 윈도우 초과 방지
    #     gpt-4o-mini는 128K 토큰이므로 대부분 문제 없음
    #     하지만 매우 긴 대화에서는 유의해야 함
    if len(conversation_history) > 20:
        # 20번 이상 대화하면 초기 메시지 제거 (최근 메시지만 유지)
        conversation_history = [conversation_history[0]] + conversation_history[-19:]
        print("[알림] 대화 히스토리 정리 (20번 이상 대화함)")
