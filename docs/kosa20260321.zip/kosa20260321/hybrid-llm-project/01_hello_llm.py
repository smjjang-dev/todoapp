# ============================================================
# 실습 1: OpenAI API 첫 번째 호출 (hello_llm.py)
# ============================================================
# [필수 설치] CMD에서 아래 명령어를 먼저 실행하세요:
#   pip install openai python-dotenv
# 
# [사전 준비]
#   - .env 파일에 OPENAI_API_KEY=sk-... 설정
#
# [실행 방법] CMD에서:
#   python hello_llm.py
#
# [예상 출력]
#   모델: gpt-4o-mini
#   입력 토큰: ~50
#   출력 토큰: ~100
#   비용: $0.00075
#   응답: "Python은 프로그래밍 언어입니다..."
#
# [주의사항]
#   - API 키는 절대 코드에 직접 입력하지 않기 (.env 사용)
#   - 첫 API 호출은 네트워크 지연 가능 (1~3초)
# ============================================================

# (1) 필요한 라이브러리를 불러옵니다
from openai import OpenAI              # OpenAI API 호출용 핵심 라이브러리
from dotenv import load_dotenv         # .env 파일에서 환경변수 읽기
import os                              # 운영체제 환경변수 접근

# (2) .env 파일에서 API 키를 자동으로 읽어옵니다
#     .env 파일이 현재 폴더에 있어야 합니다
load_dotenv()

# (3) OpenAI 클라이언트 객체를 생성합니다
#     api_key는 .env 파일의 OPENAI_API_KEY 값을 사용합니다
#     만약 None이면 환경변수 자동 검색
client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

# (4) OpenAI API에 요청을 보냅니다
#     chat.completions.create() : 채팅 완성 API 호출
#     - model: 사용할 AI 모델 선택
#     - messages: 대화 내용 (list of dicts)
#     - temperature: 창의성 정도 (0=정확, 1=창의적)
#     - max_tokens: 최대 응답 길이 (token 단위)
response = client.chat.completions.create(
    model="gpt-4o-mini",               # gpt-4o-mini: 가장 저렴하고 빠름
    messages=[                         # 메시지 배열
        {
            "role": "user",            # role은 3가지: "user", "assistant", "system"
            "content": "Python이란 무엇인가요? 5줄로 요약해주세요."
        }
    ],
    temperature=0.7,                   # 0.7: 적당한 창의성 (0~2 범위)
    max_tokens=200                     # 최대 200 token까지만 응답 (비용 제어)
)

# (5) API 응답에서 필요한 정보를 추출합니다

# 모델명 출력
print("=" * 60)
print(f"모델: {response.model}")        # API가 실제 사용한 모델

# 토큰 정보 추출 (API 비용 계산에 필수)
# response.usage는 OpenAI가 계산해서 반환한 토큰 통계
input_tokens = response.usage.prompt_tokens        # 입력 토큰 수
output_tokens = response.usage.completion_tokens   # 출력 토큰 수
total_tokens = response.usage.total_tokens         # 총 토큰 수

print(f"입력 토큰: {input_tokens}")
print(f"출력 토큰: {output_tokens}")
print(f"총 토큰: {total_tokens}")

# (6) 비용을 계산합니다 (gpt-4o-mini 기준, 2025년)
#     gpt-4o-mini 요금:
#     - 입력: 1M 토큰당 $0.15 = 1 토큰당 $0.00015
#     - 출력: 1M 토큰당 $0.6 = 1 토큰당 $0.0006
INPUT_COST_PER_TOKEN = 0.15 / 1_000_000      # $0.00015 per token
OUTPUT_COST_PER_TOKEN = 0.6 / 1_000_000      # $0.0006 per token

input_cost = input_tokens * INPUT_COST_PER_TOKEN   # 입력 비용
output_cost = output_tokens * OUTPUT_COST_PER_TOKEN # 출력 비용
total_cost = input_cost + output_cost              # 총 비용

print(f"입력 비용: ${input_cost:.6f}")
print(f"출력 비용: ${output_cost:.6f}")
print(f"총 비용: ${total_cost:.6f}")

# (7) 응답 내용을 출력합니다
#     response.choices[0]은 첫 번째 응답
#     .message.content는 실제 텍스트 내용
assistant_message = response.choices[0].message.content
print(f"\n응답:\n{assistant_message}")
print("=" * 60)
