# ============================================================
# 실습 8: Model Tiering Router (model_tiering.py)
# ============================================================
# [필수 설치]
#   pip install openai python-dotenv
#
# [실행 방법]
#   python model_tiering.py
#
# [예상 출력]
#   질문: "Python?" (간단)
#   → 복잡도 점수: 15
#   → gpt-4o-mini 선택 (저비용)
#   
#   질문: "나인텔 EUV 공정이..." (복잡)
#   → 복잡도 점수: 85
#   → gpt-4o 선택 (고정확도)
#
# [기능]
#   - 자동 복잡도 분류
#   - 모델 자동 선택 (mini vs 4o)
#   - 비용 최적화
# ============================================================

import re
from unified_client import UnifiedLLMClient

class ModelTieringRouter:
    """
    복잡도 기반 Model Tiering
    
    기능:
    1. 복잡도 점수 계산
    2. gpt-4o-mini / gpt-4o 자동 선택
    3. 비용 최적화
    """
    
    def __init__(self, complexity_threshold: int = 30):
        """
        라우터 초기화
        
        Args:
            complexity_threshold: mini/4o 선택 기준 (기본 30점)
        """
        # (1) 통합 클라이언트
        self.client = UnifiedLLMClient()
        
        # (2) 복잡도 임계값
        self.complexity_threshold = complexity_threshold
        
        # (3) 전문 용어 리스트 (복잡도 계산용)
        self.technical_keywords = {
            # 프로그래밍
            'advanced_keywords': [
                'algorithm', 'architecture', 'optimization',
                'parallel', 'asynchronous', 'concurrency',
                'memory management', 'garbage collection',
                'compilation', 'bytecode', 'metaclass',
                '알고리즘', '구조', '최적화', '병렬',
                '동시성', '메모리', '가비지',
            ],
            
            # 수학/과학
            'math_keywords': [
                'derivative', 'integral', 'matrix', 'vector',
                'differential', 'fourier', 'probability',
                'regression', 'correlation',
                '미분', '적분', '행렬', '벡터',
                '푸리에', '확률', '회귀',
            ],
            
            # 비즈니스
            'business_keywords': [
                'strategy', 'pricing', 'valuation', 'roi',
                'cash flow', 'dividend', 'hedge',
                '전략', '가격결정', '평가', '수익률',
            ]
        }
    
    def calculate_complexity_score(self, query: str) -> int:
        """
        질문의 복잡도 점수를 계산합니다 (0~100)
        
        Args:
            query: 사용자 질문
            
        Returns:
            복잡도 점수 (0: 매우 간단, 100: 매우 복잡)
        """
        score = 0
        
        # (1) 길이 기반 점수 (0~20)
        #     길수록 복잡하다고 가정
        query_length = len(query)
        if query_length < 20:
            score += 5
        elif query_length < 50:
            score += 10
        elif query_length < 100:
            score += 15
        else:
            score += 20
        
        # (2) 문장 수 기반 점수 (0~15)
        #     여러 문장 = 여러 주제 = 복잡
        sentence_count = len(re.split(r'[.!?]', query))
        score += min(sentence_count * 5, 15)
        
        # (3) 전문 용어 기반 점수 (0~40)
        query_lower = query.lower()
        
        # advanced 키워드: 각 1점
        for keyword in self.technical_keywords['advanced_keywords']:
            if keyword in query_lower:
                score += 10
        
        # math 키워드: 각 3점
        for keyword in self.technical_keywords['math_keywords']:
            if keyword in query_lower:
                score += 12
        
        # business 키워드: 각 2점
        for keyword in self.technical_keywords['business_keywords']:
            if keyword in query_lower:
                score += 8
        
        # (4) 수학식/코드 감지 (0~15)
        #     코드 블록이나 수식 있으면 복잡
        if re.search(r'\[.*?=.*?\]|\(.*?\*.*?\)', query):  # 수식
            score += 10
        if re.search(r'def |class |import ', query):  # Python 코드
            score += 10
        if re.search(r'SELECT|INSERT|UPDATE|DELETE', query):  # SQL
            score += 10
        
        # (5) 점수 정규화 (0~100)
        score = min(score, 100)
        
        return score
    
    def select_model(self, complexity_score: int) -> tuple[str, str]:
        """
        복잡도 점수에 따라 모델을 선택합니다
        
        Args:
            complexity_score: 복잡도 점수 (0~100)
            
        Returns:
            (모델명, 사유)
        """
        # (1) 임계값과 비교
        if complexity_score < self.complexity_threshold:
            # (2) 간단한 질문 → gpt-4o-mini
            return "gpt-4o-mini", f"낮은 복잡도 ({complexity_score}점)"
        else:
            # (3) 복잡한 질문 → gpt-4o
            return "gpt-4o", f"높은 복잡도 ({complexity_score}점)"
    
    def route_and_respond(
        self,
        query: str,
        temperature: float = 0.7,
        max_tokens: int = 500
    ) -> dict:
        """
        질문을 분석하고 적절한 모델로 응답합니다
        
        Args:
            query: 사용자 질문
            temperature: 창의성
            max_tokens: 최대 길이
            
        Returns:
            라우팅 및 응답 결과
        """
        
        # (1) 복잡도 점수 계산
        complexity_score = self.calculate_complexity_score(query)
        
        # (2) 모델 선택
        model, reason = self.select_model(complexity_score)
        
        # (3) API 호출
        response = self.client.chat(
            message=query,
            model=model,
            temperature=temperature,
            max_tokens=max_tokens
        )
        
        # (4) 결과 반환
        return {
            'query': query,
            'complexity_score': complexity_score,
            'model': model,
            'selection_reason': reason,
            'response': response
        }


# ========== 테스트 ==========
if __name__ == "__main__":
    print("=" * 60)
    print("Model Tiering Router 테스트")
    print("=" * 60 + "\n")
    
    # (1) 라우터 생성
    router = ModelTieringRouter(complexity_threshold=30)
    
    # (2) 테스트 질문들 (간단 ~ 복잡)
    test_queries = [
        # 매우 간단
        "Python?",
        
        # 간단
        "Python 배우려면?",
        
        # 중간
        "Python 멀티스레딩 구현 방법과 장단점",
        
        # 복잡
        "메모리 관리와 가비지 컬렉션의 작동 원리, GIL의 영향",
        
        # 매우 복잡
        "CPU 캐시 계층 구조와 메모리 접근 패턴의 성능 영향",
    ]
    
    # (3) 각 질문을 분석
    for query in test_queries:
        print(f"[질문] {query}")
        
        complexity = router.calculate_complexity_score(query)
        model, reason = router.select_model(complexity)
        
        print(f"  복잡도: {complexity}/100")
        print(f"  모델 선택: {model}")
        print(f"  사유: {reason}")
        print()
