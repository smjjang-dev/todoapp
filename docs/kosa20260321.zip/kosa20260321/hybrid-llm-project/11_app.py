# ============================================================
# 실습 11: Flask 웹앱 (app.py)
# ============================================================
# [필수 설치]
#   pip install flask openai python-dotenv numpy
#
# [실행 방법]
#   python app.py
#   브라우저에서 http://localhost:5000 접속
#
# [기능]
#   - 웹 UI: 채팅 인터페이스
#   - API: /api/chat 엔드포인트
#   - 대시보드: 실시간 통계
#   - Hybrid Engine 통합
# ============================================================

from flask import Flask, render_template, request, jsonify
from hybrid_engine import HybridEngine
import json
from datetime import datetime

# (1) Flask 앱 생성
app = Flask(__name__)

# (2) Hybrid Engine 초기화 (싱글톤)
engine = HybridEngine()

# (3) 대화 히스토리 (메모리 저장, 실무에서는 DB 사용)
conversation_history = []

# ========== API 엔드포인트 ==========

@app.route('/')
def index():
    """메인 페이지 (HTML 제공)"""
    return render_template('index.html')

@app.route('/api/chat', methods=['POST'])
def chat_api():
    """
    채팅 API 엔드포인트
    
    요청 형식:
    {
        "message": "사용자 메시지"
    }
    
    응답 형식:
    {
        "response": "AI 응답",
        "source": "cache" | "llm" | "error",
        "tokens": 150,
        "cost": 0.00045,
        "response_time": 1.23
    }
    """
    # (1) 요청 데이터 수신
    data = request.json
    user_message = data.get('message', '').strip()
    
    if not user_message:
        return jsonify({'error': '메시지가 비어있습니다'}), 400
    
    # (2) Hybrid Engine으로 처리
    result = engine.process_query(user_message)
    
    # (3) 대화 히스토리에 추가
    conversation_history.append({
        'role': 'user',
        'content': user_message,
        'timestamp': datetime.now().isoformat()
    })
    
    conversation_history.append({
        'role': 'assistant',
        'content': result['response'],
        'timestamp': datetime.now().isoformat(),
        'metadata': {
            'source': result.get('source'),
            'model': result.get('model'),
            'tokens': result.get('tokens', 0),
            'cost': result.get('cost', 0.0)
        }
    })
    
    # (4) 응답 반환
    return jsonify({
        'response': result['response'],
        'source': result.get('source'),
        'model': result.get('model'),
        'provider': result.get('provider'),
        'tokens': result.get('tokens', 0),
        'cost': f"${result.get('cost', 0.0):.6f}",
        'response_time': f"{result.get('response_time', 0):.3f}초"
    })

@app.route('/api/stats', methods=['GET'])
def stats_api():
    """
    통계 조회 API
    
    응답 형식:
    {
        "total_requests": 10,
        "cache_hit_rate": "30.0%",
        "total_cost": "$0.00456",
        ...
    }
    """
    stats = engine.get_stats()
    return jsonify(stats)

@app.route('/api/history', methods=['GET'])
def history_api():
    """대화 히스토리 조회"""
    return jsonify({
        'history': conversation_history,
        'count': len(conversation_history)
    })

@app.route('/api/clear', methods=['POST'])
def clear_api():
    """대화 히스토리 초기화"""
    global conversation_history
    conversation_history = []
    return jsonify({'status': 'cleared'})

# ========== 에러 핸들러 ==========

@app.errorhandler(404)
def not_found(error):
    return jsonify({'error': '페이지를 찾을 수 없습니다'}), 404

@app.errorhandler(500)
def internal_error(error):
    return jsonify({'error': '서버 오류가 발생했습니다'}), 500

# ========== 실행 ==========

if __name__ == '__main__':
    print("=" * 60)
    print("Flask 웹앱 시작")
    print("=" * 60)
    print("\nhttp://localhost:5000 에서 접속하세요")
    print("Ctrl+C로 종료할 수 있습니다\n")
    
    # (1) 개발 서버 실행 (자동 리로드)
    app.run(
        host='0.0.0.0',        # 모든 IP에서 접속 가능
        port=5000,             # 기본 포트
        debug=True,            # 개발 모드 (자동 리로드)
        use_reloader=False     # 단일 인스턴스 (Engine 중복 생성 방지)
    )
