# ============================================================
# 실습 5: SQLite 캐시 기초 (sqlite_cache.py)
# ============================================================
# [필수 설치]
#   pip install openai python-dotenv
#   (sqlite3는 Python 내장 모듈)
#
# [실행 방법]
#   python sqlite_cache.py
#
# [예상 출력]
#   캐시 테이블 생성 완료
#   캐시 저장: "Python이란?" → ID 1
#   캐시 조회: "Python이란?" → 찾음! (hit_count: 2)
#   
# [주의사항]
#   - 데이터베이스 파일 (cache.db) 자동 생성
#   - TTL 체크: 7일 후 자동 만료
# ============================================================

import sqlite3
import hashlib
from datetime import datetime, timedelta
from typing import Optional, Dict, Any

class SimpleSQLiteCache:
    """
    간단한 SQLite 기반 LLM 응답 캐시 클래스
    
    기능:
    1. Exact Match 캐시: SHA256 해시로 정확한 질문 매칭
    2. TTL 관리: 지정된 기간 후 자동 만료
    3. 히트 통계: 캐시 재사용 횟수 추적
    """
    
    def __init__(self, db_path: str = "cache.db"):
        """
        SQLite 캐시 초기화
        
        Args:
            db_path: 데이터베이스 파일 경로
        """
        self.db_path = db_path
        self._initialize_db()
    
    def _initialize_db(self):
        """
        데이터베이스와 캐시 테이블을 초기화합니다
        """
        # (1) 데이터베이스 연결
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # (2) 캐시 테이블 생성 (없으면 생성, 있으면 유지)
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS llm_cache (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                cache_key TEXT UNIQUE NOT NULL,
                query TEXT NOT NULL,
                response TEXT NOT NULL,
                model TEXT,
                provider TEXT,
                tokens INTEGER DEFAULT 0,
                cost REAL DEFAULT 0.0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                expires_at TIMESTAMP,
                hit_count INTEGER DEFAULT 0
            )
        """)
        
        # (3) 조회 성능을 위한 인덱스 생성
        cursor.execute("""
            CREATE INDEX IF NOT EXISTS idx_cache_key 
            ON llm_cache(cache_key)
        """)
        cursor.execute("""
            CREATE INDEX IF NOT EXISTS idx_expires_at 
            ON llm_cache(expires_at)
        """)
        
        # (4) 변경사항 저장 및 연결 종료
        conn.commit()
        conn.close()
        
        print(f"[초기화] 캐시 테이블 준비 완료 (DB: {self.db_path})")
    
    def _get_cache_key(self, query: str) -> str:
        """
        질문을 SHA256 해시로 변환합니다 (캐시 키로 사용)
        
        Args:
            query: 원본 질문
            
        Returns:
            SHA256 해시값 (16진수 문자열)
        """
        # (1) 질문을 정규화합니다 (공백 정리, 소문자 변환)
        normalized = query.strip().lower()
        
        # (2) SHA256 해시 계산
        hash_obj = hashlib.sha256(normalized.encode('utf-8'))
        cache_key = hash_obj.hexdigest()
        
        return cache_key
    
    def save_response(
        self,
        query: str,
        response: str,
        model: str = "unknown",
        provider: str = "unknown",
        tokens: int = 0,
        cost: float = 0.0,
        ttl_days: int = 7
    ) -> int:
        """
        LLM 응답을 캐시에 저장합니다
        
        Args:
            query: 원본 질문
            response: LLM 응답
            model: 사용한 모델명
            provider: 프로바이더명
            tokens: 사용한 토큰 수
            cost: 비용 (달러)
            ttl_days: 캐시 유효 기간 (기본 7일)
            
        Returns:
            저장된 캐시 ID
        """
        # (1) 캐시 키 생성
        cache_key = self._get_cache_key(query)
        
        # (2) TTL 계산 (현재 시간 + ttl_days)
        expires_at = datetime.now() + timedelta(days=ttl_days)
        
        # (3) 데이터베이스 연결
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        try:
            # (4) 캐시 데이터 삽입
            cursor.execute("""
                INSERT INTO llm_cache 
                (cache_key, query, response, model, provider, tokens, cost, expires_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """, (cache_key, query, response, model, provider, tokens, cost, expires_at))
            
            # (5) 변경사항 저장
            conn.commit()
            
            # (6) 삽입된 행의 ID 가져오기
            cache_id = cursor.lastrowid
            
            print(f"[저장] 캐시 #{cache_id}: '{query[:30]}...' ({ttl_days}일 유효)")
            return cache_id
            
        except sqlite3.IntegrityError:
            # (7) 중복 캐시 키 (이미 같은 질문이 있음)
            print(f"[중복] 동일한 질문이 이미 캐시됨: '{query[:30]}...'")
            return -1
        
        finally:
            conn.close()
    
    def get_response(self, query: str) -> Optional[Dict[str, Any]]:
        """
        캐시에서 응답을 조회합니다
        
        Args:
            query: 조회할 질문
            
        Returns:
            캐시된 데이터 딕셔너리, 없으면 None
        """
        # (1) 캐시 키 생성
        cache_key = self._get_cache_key(query)
        
        # (2) 데이터베이스 연결
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # (3) 캐시 조회 (TTL 체크 포함)
        #     expires_at이 현재 시간보다 미래여야 함
        cursor.execute("""
            SELECT id, response, model, provider, tokens, cost, hit_count, created_at
            FROM llm_cache
            WHERE cache_key = ? AND (expires_at IS NULL OR expires_at > datetime('now'))
        """, (cache_key,))
        
        result = cursor.fetchone()
        
        if result:
            # (4) 캐시 히트: hit_count 증가
            cache_id = result[0]
            
            cursor.execute("""
                UPDATE llm_cache
                SET hit_count = hit_count + 1
                WHERE id = ?
            """, (cache_id,))
            
            conn.commit()
            
            # (5) 결과를 딕셔너리로 변환
            cache_data = {
                'id': result[0],
                'response': result[1],
                'model': result[2],
                'provider': result[3],
                'tokens': result[4],
                'cost': result[5],
                'hit_count': result[6] + 1,  # 업데이트된 값
                'created_at': result[7]
            }
            
            print(f"[캐시 히트] '{query[:30]}...' (히트: {cache_data['hit_count']}회)")
            conn.close()
            return cache_data
        else:
            # (6) 캐시 미스
            print(f"[캐시 미스] '{query[:30]}...' (새로 조회 필요)")
            conn.close()
            return None
    
    def clear_expired(self) -> int:
        """
        만료된 캐시를 삭제합니다
        
        Returns:
            삭제된 행의 수
        """
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # (1) expires_at이 지난 캐시 삭제
        cursor.execute("""
            DELETE FROM llm_cache
            WHERE expires_at IS NOT NULL AND expires_at <= datetime('now')
        """)
        
        # (2) 삭제된 행의 수
        deleted_count = cursor.rowcount
        
        conn.commit()
        conn.close()
        
        if deleted_count > 0:
            print(f"[정리] 만료된 캐시 {deleted_count}개 삭제")
        
        return deleted_count
    
    def get_stats(self) -> Dict[str, Any]:
        """
        캐시 통계를 반환합니다
        
        Returns:
            통계 딕셔너리
        """
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # (1) 전체 캐시 수
        cursor.execute("SELECT COUNT(*) FROM llm_cache")
        total_cache = cursor.fetchone()[0]
        
        # (2) 유효한 캐시 수 (만료 전)
        cursor.execute("""
            SELECT COUNT(*) FROM llm_cache
            WHERE expires_at IS NULL OR expires_at > datetime('now')
        """)
        valid_cache = cursor.fetchone()[0]
        
        # (3) 총 히트 수
        cursor.execute("SELECT SUM(hit_count) FROM llm_cache")
        total_hits = cursor.fetchone()[0] or 0
        
        # (4) 총 비용 절감
        cursor.execute("SELECT SUM(cost) FROM llm_cache")
        total_cost_saved = cursor.fetchone()[0] or 0.0
        
        conn.close()
        
        return {
            'total_cache': total_cache,
            'valid_cache': valid_cache,
            'total_hits': total_hits,
            'total_cost_saved': total_cost_saved
        }


# ========== 테스트 ==========
if __name__ == "__main__":
    print("=" * 60)
    print("SQLite 캐시 테스트")
    print("=" * 60 + "\n")
    
    # (1) 캐시 객체 생성
    cache = SimpleSQLiteCache(db_path="cache.db")
    
    # (2) 첫 번째 응답 저장
    cache.save_response(
        query="Python이란?",
        response="Python은 고급 프로그래밍 언어입니다.",
        model="gpt-4o-mini",
        provider="openai",
        tokens=50,
        cost=0.000075,
        ttl_days=7
    )
    
    # (3) 두 번째 응답 저장
    cache.save_response(
        query="AI란 무엇인가?",
        response="AI는 인공지능(Artificial Intelligence)을 의미합니다.",
        model="gpt-4o-mini",
        provider="openai",
        tokens=45,
        cost=0.000068,
        ttl_days=7
    )
    
    print()
    
    # (4) 캐시에서 응답 조회 (캐시 히트)
    result1 = cache.get_response("Python이란?")
    if result1:
        print(f"  응답: {result1['response']}\n")
    
    # (5) 다시 조회 (히트 카운트 증가)
    result2 = cache.get_response("Python이란?")
    if result2:
        print(f"  응답: {result2['response']}\n")
    
    # (6) 캐시에 없는 질문 (캐시 미스)
    result3 = cache.get_response("JavaScript란?")
    if not result3:
        print("  → 캐시에 없습니다. OpenAI로 조회해야 함\n")
    
    # (7) 통계 출력
    stats = cache.get_stats()
    print("=" * 60)
    print("캐시 통계")
    print("=" * 60)
    print(f"총 캐시: {stats['total_cache']}개")
    print(f"유효한 캐시: {stats['valid_cache']}개")
    print(f"총 히트: {stats['total_hits']}회")
    print(f"절감된 비용: ${stats['total_cost_saved']:.6f}")
    print("=" * 60)
