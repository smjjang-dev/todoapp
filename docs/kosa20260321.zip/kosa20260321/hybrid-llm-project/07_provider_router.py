# ============================================================
# 실습 7: Provider Router (provider_router.py)
# ============================================================
# [필수 설치]
#   pip install openai python-dotenv
#
# [사전 준비]
#   - .env 파일 설정
#   - Ollama 서버 실행
#   - unified_client.py와 같은 폴더
#
# [실행 방법]
#   python provider_router.py
#
# [예상 출력]
#   질문: "홍길동의 나이는?"
#   → PII 감지됨! Ollama로 처리
#   
#   질문: "Python이란?"
#   → PII 없음. OpenAI로 처리
#
# [기능]
#   - PII(개인정보) 자동 감지
#   - OpenAI/Ollama 자동 라우팅
#   - Fallback: Ollama 실패 시 OpenAI로 재시도
# ============================================================

import re
from unified_client import UnifiedLLMClient

class ProviderRouter:
    """
    PII 감지 기반 Provider Routing
    
    기능:
    1. PII 감지: 개인정보 포함 여부 판단
    2. Provider 선택: PII 있으면 Ollama, 없으면 OpenAI
    3. Fallback: Ollama 실패 시 OpenAI로 재시도
    """
    
    def __init__(self):
        """
        라우터를 초기화합니다
        """
        # (1) 통합 클라이언트 생성
        self.client = UnifiedLLMClient()
        
        # (2) PII 패턴 정의 (정규식)
        #     실무에서는 더 정교한 모델 (named entity recognition) 사용
        self.pii_patterns = {
            # 한국 주민등록번호 (XXXXXX-XXXXXXX)
            'korean_ssn': r'\d{6}-\d{7}',
            
            # 이메일 주소
            'email': r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}',
            
            # 휴대폰 번호 (010-1234-5678)
            'phone': r'\d{2,3}-\d{3,4}-\d{4}',
            
            # 신용카드 번호 (XXXX-XXXX-XXXX-XXXX)
            'credit_card': r'\d{4}[-\s]?\d{4}[-\s]?\d{4}[-\s]?\d{4}',
            
            # 이름 패턴 (한국 성씨 + 이름 + 조사)
            'korean_name': r'(?:김|이|박|최|정|강|조|윤|장|임|한|오|서|신|권|황|안|송|류|홍)[가-힣]{1,3}(?:은|는|이|가|을|를|에게|와|과|의)',
            
            # 계좌번호 패턴
            'account': r'\d{3,4}-\d{6,8}-\d{5}',
        }
    
    def detect_pii(self, text: str) -> tuple[bool, list[str]]:
        """
        텍스트에 PII가 포함되어 있는지 감지합니다
        
        Args:
            text: 검사할 텍스트
            
        Returns:
            (PII 있는지 여부, 감지된 PII 타입 리스트)
        """
        # (1) 감지된 PII 타입을 저장할 리스트
        detected_types = []
        
        # (2) 각 PII 패턴을 텍스트와 매칭
        for pii_type, pattern in self.pii_patterns.items():
            if re.search(pattern, text):
                # (3) PII 발견
                detected_types.append(pii_type)
        
        # (4) PII가 하나라도 있으면 True
        has_pii = len(detected_types) > 0
        
        return has_pii, detected_types
    
    def route_and_respond(
        self,
        query: str,
        temperature: float = 0.7,
        max_tokens: int = 500
    ) -> dict:
        """
        질문을 분석하고 적절한 프로바이더로 라우팅합니다
        
        Args:
            query: 사용자 질문
            temperature: 창의성
            max_tokens: 최대 응답 길이
            
        Returns:
            {
                'query': 원본 질문,
                'has_pii': PII 포함 여부,
                'pii_types': 감지된 PII 타입,
                'provider': 사용한 프로바이더,
                'model': 사용한 모델,
                'response': LLM 응답
            }
        """
        
        # (1) PII 감지
        has_pii, pii_types = self.detect_pii(query)
        
        # (2) PII에 따라 프로바이더 결정
        if has_pii:
            # (3) PII 있음 → Ollama 사용 (로컬, 비용 0)
            primary_model = "gemma3:4b"
            primary_provider = "ollama"
            fallback_model = "gpt-4o-mini"
            fallback_provider = "openai"
        else:
            # (4) PII 없음 → OpenAI 사용 (빠르고 정확)
            primary_model = "gpt-4o-mini"
            primary_provider = "openai"
            fallback_model = "gemma3:4b"
            fallback_provider = "ollama"
        
        # (5) 첫 번째 시도: 주 프로바이더로 호출
        try:
            response = self.client.chat(
                message=query,
                model=primary_model,
                temperature=temperature,
                max_tokens=max_tokens
            )
            
            # (6) 성공
            return {
                'query': query,
                'has_pii': has_pii,
                'pii_types': pii_types,
                'provider': primary_provider,
                'model': primary_model,
                'response': response,
                'fallback_used': False
            }
        
        except Exception as e:
            # (7) 주 프로바이더 실패 → Fallback으로 재시도
            print(f"[주 프로바이더 실패] {primary_provider}: {str(e)}")
            print(f"[Fallback 시도] {fallback_provider}로 전환...")
            
            try:
                response = self.client.chat(
                    message=query,
                    model=fallback_model,
                    temperature=temperature,
                    max_tokens=max_tokens
                )
                
                # (8) Fallback 성공
                return {
                    'query': query,
                    'has_pii': has_pii,
                    'pii_types': pii_types,
                    'provider': fallback_provider,
                    'model': fallback_model,
                    'response': response,
                    'fallback_used': True
                }
            
            except Exception as e2:
                # (9) Fallback도 실패
                return {
                    'query': query,
                    'has_pii': has_pii,
                    'pii_types': pii_types,
                    'provider': 'ERROR',
                    'model': 'N/A',
                    'response': f"양쪽 프로바이더 모두 실패: {str(e2)}",
                    'fallback_used': True
                }


# ========== 테스트 ==========
if __name__ == "__main__":
    print("=" * 60)
    print("Provider Router 테스트")
    print("=" * 60 + "\n")
    
    # (1) 라우터 생성
    router = ProviderRouter()
    
    # (2) 테스트 질문들
    test_queries = [
        # PII 없는 질문 (OpenAI로 처리)
        "Python이란 무엇인가요?",
        
        # 이메일 포함 (Ollama로 처리)
        "user@example.com의 계정 정보는?",
        
        # 이름 포함 (Ollama로 처리)
        "홍길동은 어디에 사나요?",
        
        # 휴대폰 번호 포함 (Ollama로 처리)
        "010-1234-5678의 주인은?",
    ]
    
    # (3) 각 질문을 라우팅
    for query in test_queries:
        print(f"[질문] {query}")
        
        # PII 먼저 감지
        has_pii, pii_types = router.detect_pii(query)
        print(f"  PII 감지: {has_pii}")
        if pii_types:
            print(f"  타입: {', '.join(pii_types)}")
        
        # 라우팅 및 응답
        result = router.route_and_respond(query, max_tokens=200)
        
        print(f"  프로바이더: {result['provider']}")
        print(f"  모델: {result['model']}")
        if result['fallback_used']:
            print(f"  [⚠️ Fallback 사용됨]")
        print(f"  응답: {result['response'][:100]}...")
        print()
