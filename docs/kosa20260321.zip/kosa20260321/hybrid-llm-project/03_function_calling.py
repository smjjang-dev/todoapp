# ============================================================
# 실습 3: Function Calling 활용 (function_calling.py)
# ============================================================
# [필수 설치]
#   pip install openai python-dotenv
#
# [실행 방법]
#   python function_calling.py
#
# [예상 출력]
#   "숫자 25와 4의 합은?"
#   → LLM이 add_numbers 함수 선택
#   → 함수 실행: 25 + 4 = 29
#   → 최종 응답: "숫자 25와 4의 합은 29입니다."
#
# [주의사항]
#   - 함수 정의(tools)가 정확해야 LLM이 올바르게 선택함
#   - tool_choice="auto": LLM이 자동으로 도구 선택
# ============================================================

from openai import OpenAI
from dotenv import load_dotenv
import json
import os

load_dotenv()
client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

# (1) 실제 함수들을 정의합니다 (LLM이 호출할 함수들)
#     이 함수들은 LLM의 지시에 따라 자동으로 실행됩니다

def add_numbers(a: int, b: int) -> int:
    """두 숫자를 더합니다"""
    return a + b

def multiply_numbers(a: int, b: int) -> int:
    """두 숫자를 곱합니다"""
    return a * b

def get_weather(location: str) -> str:
    """특정 지역의 날씨를 조회합니다 (데모용, 실제 API 아님)"""
    # 실제 구현에서는 날씨 API를 호출합니다
    weather_data = {
        "서울": "맑음, 20도",
        "부산": "흐림, 18도",
        "대구": "비, 15도"
    }
    return weather_data.get(location, "정보 없음")

# (2) OpenAI에 전달할 함수 정의 (JSON 스키마 형식)
#     LLM이 어떤 함수가 있는지, 언제 사용할지 판단하기 위한 메타데이터
tools = [
    {
        "type": "function",
        "function": {
            "name": "add_numbers",          # 함수 이름
            "description": "두 숫자를 더합니다",  # LLM이 읽을 설명
            "parameters": {                 # 함수의 파라미터 정의
                "type": "object",
                "properties": {
                    "a": {
                        "type": "integer",
                        "description": "첫 번째 숫자"
                    },
                    "b": {
                        "type": "integer",
                        "description": "두 번째 숫자"
                    }
                },
                "required": ["a", "b"]      # 필수 파라미터
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "multiply_numbers",
            "description": "두 숫자를 곱합니다",
            "parameters": {
                "type": "object",
                "properties": {
                    "a": {"type": "integer", "description": "첫 번째 숫자"},
                    "b": {"type": "integer", "description": "두 번째 숫자"}
                },
                "required": ["a", "b"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "get_weather",
            "description": "특정 지역의 날씨를 조회합니다",
            "parameters": {
                "type": "object",
                "properties": {
                    "location": {
                        "type": "string",
                        "description": "지역명 (예: 서울, 부산, 대구)"
                    }
                },
                "required": ["location"]
            }
        }
    }
]

# (3) Function Calling API를 호출합니다
#     tools 파라미터: LLM이 사용 가능한 함수 목록
#     tool_choice="auto": LLM이 자동으로 필요한 함수 선택
def process_user_input(user_message: str):
    """사용자 메시지를 처리하고, 필요하면 함수를 호출합니다"""
    
    # (3-1) 첫 번째 API 호출: 사용자 질문 받기
    response = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[
            {
                "role": "user",
                "content": user_message
            }
        ],
        tools=tools,                    # 사용 가능한 함수 목록 전달
        tool_choice="auto",             # LLM이 자동으로 함수 선택
        max_tokens=500
    )
    
    # (3-2) LLM의 응답을 확인합니다
    assistant_message = response.choices[0].message
    
    # (3-3) LLM이 함수 호출을 요청했는지 확인합니다
    #       tool_calls가 있으면 함수 실행 필요
    if assistant_message.tool_calls:
        print(f"사용자: {user_message}")
        
        # (3-4) 모든 tool_calls를 실행합니다
        tool_results = []
        for tool_call in assistant_message.tool_calls:
            tool_name = tool_call.function.name              # 함수 이름
            tool_input = json.loads(tool_call.function.arguments)  # 파라미터 파싱
            
            print(f"→ 함수 호출: {tool_name}({tool_input})")
            
            # (3-5) 파라미터에 맞는 함수를 실행합니다
            if tool_name == "add_numbers":
                result = add_numbers(tool_input["a"], tool_input["b"])
            elif tool_name == "multiply_numbers":
                result = multiply_numbers(tool_input["a"], tool_input["b"])
            elif tool_name == "get_weather":
                result = get_weather(tool_input["location"])
            else:
                result = "Unknown function"
            
            print(f"→ 결과: {result}")
            
            # 결과를 저장합니다 (LLM이 최종 답변 생성할 때 필요)
            tool_results.append({
                "tool_call_id": tool_call.id,
                "output": str(result)
            })
        
        # (3-6) 두 번째 API 호출: 함수 결과를 포함해서 최종 답변 받기
        #       LLM이 함수 결과를 바탕으로 자연스러운 응답 생성
        messages = [
            {"role": "user", "content": user_message},
            assistant_message,  # LLM의 첫 응답 (함수 호출 정보 포함)
        ]
        
        # 함수 결과를 메시지에 추가합니다
        for tool_result in tool_results:
            messages.append({
                "role": "tool",
                "tool_call_id": tool_result["tool_call_id"],
                "content": tool_result["output"]
            })
        
        # 최종 답변을 받습니다
        final_response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=messages,
            max_tokens=500
        )
        
        # 최종 응답 출력
        print(f"어시스턴트: {final_response.choices[0].message.content}\n")
    else:
        # (3-7) LLM이 함수를 호출하지 않은 경우 (일반 텍스트 응답)
        print(f"사용자: {user_message}")
        print(f"어시스턴트: {assistant_message.content}\n")

# (4) 테스트: 다양한 질문으로 Function Calling을 실행합니다
print("=" * 60)
print("Function Calling 데모")
print("=" * 60 + "\n")

# 테스트 케이스들
test_queries = [
    "25와 4의 합은?",              # add_numbers 호출 예상
    "10과 7을 곱하면?",             # multiply_numbers 호출 예상
    "서울의 날씨는?",               # get_weather 호출 예상
    "안녕하세요"                     # 함수 호출 없음 (일반 대화)
]

for query in test_queries:
    process_user_input(query)
