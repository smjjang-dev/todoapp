# ============================================================
# 실습 0: 개발환경 검증 스크립트 (00_verify_env.py)
# ============================================================
# [필수 설치] CMD에서 아래 명령어를 먼저 실행하세요:
#   pip install openai flask python-dotenv numpy requests
#
# [실행 방법] CMD에서:
#   python 00_verify_env.py
#
# [예상 출력]
#   [1] Python 버전: 3.13.x
#   [2] OpenAI 패키지: OK
#   ...
#   검증 완료
# ============================================================

import os
import sys
import sqlite3
from dotenv import load_dotenv

print("=" * 60)
print("개발환경 검증 시작")
print("=" * 60)

# (1) Python 버전 확인
print(f"\n[1] Python 버전: {sys.version}")
assert sys.version_info >= (3, 10), "Python 3.10 이상 필요"

# (2) 필수 패키지 확인
try:
    import openai
    print(f"[2] OpenAI 패키지: OK (v{openai.__version__})")
except ImportError:
    print("[2] OpenAI 패키지: MISSING - pip install openai")

try:
    import flask
    print(f"[3] Flask 패키지: OK")
except ImportError:
    print("[3] Flask 패키지: MISSING - pip install flask")

try:
    import numpy
    print(f"[4] NumPy 패키지: OK")
except ImportError:
    print("[4] NumPy 패키지: MISSING - pip install numpy")

# (3) SQLite 확인 (내장 모듈)
try:
    conn = sqlite3.connect(":memory:")
    cursor = conn.cursor()
    cursor.execute("SELECT sqlite_version()")
    version = cursor.fetchone()[0]
    conn.close()
    print(f"[5] SQLite: OK (v{version})")
except Exception as e:
    print(f"[5] SQLite: ERROR - {e}")

# (4) .env 파일 확인
load_dotenv()
api_key = os.getenv("OPENAI_API_KEY")
if api_key and api_key.startswith("sk-"):
    print("[6] OPENAI_API_KEY: OK (발견됨)")
else:
    print("[6] OPENAI_API_KEY: MISSING - .env 파일에 설정 필요")

# (5) Ollama 연결 확인
try:
    import requests
    response = requests.get("http://localhost:11434/api/tags", timeout=2)
    if response.status_code == 200:
        print("[7] Ollama 서버: OK (실행 중)")
    else:
        print("[7] Ollama 서버: NOT RESPONDING")
except:
    print("[7] Ollama 서버: NOT RUNNING - 별도 CMD에서 'ollama serve' 실행 필요")

print("\n" + "=" * 60)
print("검증 완료")
print("=" * 60)
