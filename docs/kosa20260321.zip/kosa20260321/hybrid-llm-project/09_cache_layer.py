# ============================================================
# 실습 9: SQLite 기반 Cache Layer (cache_layer.py)
# ============================================================
# [필수 설치]
#   pip install openai python-dotenv numpy
#   (sqlite3는 내장)
#
# [실행 방법]
#   python cache_layer.py
#
# [예상 출력]
#   Exact Match: "Python?" → 캐시 히트/미스
#   Semantic Match: "Python이란?" ≈ "Python?" → 의미 매칭
#
# [기능]
#   - Exact Match: SHA256 해시 기반 정확 매칭
#   - Semantic Match: 임베딩 벡터 기반 의미 매칭
#   - TTL 관리: 만료된 캐시 자동 제거
# ============================================================

import sqlite3
import hashlib
import json
import numpy as np
from datetime import datetime, timedelta
from typing import Optional, Dict, List, Any

class SQLiteCacheLayer:
    """
    SQLite 기반 이중 캐시 시스템
    
    1. Exact Match: SHA256 해시로 정확한 질문 매칭 (100% 신뢰)
    2. Semantic Match: 임베딩 벡터로 의미 유사도 매칭 (95% 신뢰)
    """
    
    def __init__(self, db_path: str = "hybrid_cache.db"):
        """
        캐시 레이어 초기화
        
        Args:
            db_path: SQLite 데이터베이스 경로
        """
        self.db_path = db_path
        self._initialize_db()
    
    def _initialize_db(self):
        """
        데이터베이스와 테이블 초기화
        """
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # (1) 캐시 테이블 생성
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS llm_cache (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                cache_key TEXT UNIQUE NOT NULL,
                query TEXT NOT NULL,
                response TEXT NOT NULL,
                model TEXT,
                provider TEXT,
                embedding TEXT,
                tokens INTEGER DEFAULT 0,
                cost REAL DEFAULT 0.0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                expires_at TIMESTAMP,
                hit_count INTEGER DEFAULT 0
            )
        """)
        
        # (2) 인덱스 생성
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_cache_key ON llm_cache(cache_key)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_expires_at ON llm_cache(expires_at)")
        
        conn.commit()
        conn.close()
        
        print(f"[초기화] 캐시 레이어 준비 완료")
    
    def _get_cache_key(self, query: str) -> str:
        """
        질문을 SHA256 해시로 변환
        
        Args:
            query: 질문
            
        Returns:
            SHA256 해시
        """
        normalized = query.strip().lower()
        return hashlib.sha256(normalized.encode('utf-8')).hexdigest()
    
    def _generate_embedding(self, text: str) -> List[float]:
        """
        간단한 임베딩 생성 (실무에서는 openai.Embedding API 사용)
        
        Args:
            text: 임베딩할 텍스트
            
        Returns:
            임베딩 벡터 (리스트)
        """
        # (1) 프로덕션: OpenAI Embedding API 사용
        #     response = client.embeddings.create(
        #         model="text-embedding-3-small",
        #         input=text
        #     )
        #     return response.data[0].embedding
        
        # (2) 데모: 간단한 해시 기반 임베딩
        #     (정확하지 않지만, 구조 이해용)
        import hashlib
        
        text_bytes = text.encode('utf-8')
        hash_bytes = hashlib.sha256(text_bytes).digest()
        
        # (3) 해시를 부동소수점으로 변환
        embedding = [float(b) / 255.0 for b in hash_bytes[:64]]
        
        return embedding
    
    def _cosine_similarity(self, vec1: List[float], vec2: List[float]) -> float:
        """
        두 벡터의 코사인 유사도 계산
        
        Args:
            vec1, vec2: 임베딩 벡터
            
        Returns:
            유사도 (0~1, 1이 가장 유사)
        """
        # (1) NumPy로 계산
        arr1 = np.array(vec1)
        arr2 = np.array(vec2)
        
        # (2) 코사인 유사도 = (A·B) / (||A|| * ||B||)
        dot_product = np.dot(arr1, arr2)
        norm1 = np.linalg.norm(arr1)
        norm2 = np.linalg.norm(arr2)
        
        if norm1 == 0 or norm2 == 0:
            return 0.0
        
        return float(dot_product / (norm1 * norm2))
    
    def save_response(
        self,
        query: str,
        response: str,
        model: str = "unknown",
        provider: str = "unknown",
        tokens: int = 0,
        cost: float = 0.0,
        ttl_days: int = 7
    ) -> int:
        """
        응답을 캐시에 저장합니다
        
        Args:
            query: 원본 질문
            response: LLM 응답
            model: 사용한 모델
            provider: 프로바이더
            tokens: 토큰 수
            cost: 비용
            ttl_days: 유효 기간
            
        Returns:
            캐시 ID
        """
        # (1) 캐시 키 생성
        cache_key = self._get_cache_key(query)
        
        # (2) 임베딩 생성
        embedding = self._generate_embedding(query)
        embedding_json = json.dumps(embedding)
        
        # (3) TTL 계산
        expires_at = datetime.now() + timedelta(days=ttl_days)
        
        # (4) 데이터베이스 저장
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        try:
            cursor.execute("""
                INSERT INTO llm_cache
                (cache_key, query, response, model, provider, embedding, 
                 tokens, cost, expires_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (cache_key, query, response, model, provider, embedding_json,
                  tokens, cost, expires_at))
            
            conn.commit()
            cache_id = cursor.lastrowid
            
            print(f"[저장] 캐시 #{cache_id}: '{query[:20]}...'")
            return cache_id
        
        except sqlite3.IntegrityError:
            print(f"[중복] 이미 캐시됨: '{query[:20]}...'")
            return -1
        
        finally:
            conn.close()
    
    def get_response_exact(self, query: str) -> Optional[Dict[str, Any]]:
        """
        정확 일치로 캐시를 조회합니다 (100% 정확도)
        
        Args:
            query: 조회 질문
            
        Returns:
            캐시 데이터 또는 None
        """
        # (1) 캐시 키 생성
        cache_key = self._get_cache_key(query)
        
        # (2) 데이터베이스 조회
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT id, response, model, provider, tokens, cost, hit_count
            FROM llm_cache
            WHERE cache_key = ? AND (expires_at IS NULL OR expires_at > datetime('now'))
        """, (cache_key,))
        
        result = cursor.fetchone()
        
        if result:
            # (3) 히트 카운트 증가
            cache_id = result[0]
            cursor.execute("UPDATE llm_cache SET hit_count = hit_count + 1 WHERE id = ?",
                          (cache_id,))
            conn.commit()
            
            print(f"[Exact Hit] '{query[:20]}...'")
            
            return {
                'id': result[0],
                'response': result[1],
                'model': result[2],
                'provider': result[3],
                'tokens': result[4],
                'cost': result[5],
                'hit_count': result[6] + 1,
                'match_type': 'exact'
            }
        
        conn.close()
        return None
    
    def get_response_semantic(self, query: str, threshold: float = 0.95) -> Optional[Dict[str, Any]]:
        """
        의미 유사도로 캐시를 조회합니다 (95% 신뢰도)
        
        Args:
            query: 조회 질문
            threshold: 유사도 임계값 (0~1)
            
        Returns:
            캐시 데이터 또는 None
        """
        # (1) 쿼리 임베딩 생성
        query_embedding = self._generate_embedding(query)
        
        # (2) 모든 유효한 캐시 조회
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT id, query, response, model, provider, embedding, tokens, cost, hit_count
            FROM llm_cache
            WHERE embedding IS NOT NULL AND (expires_at IS NULL OR expires_at > datetime('now'))
        """)
        
        results = cursor.fetchall()
        
        best_match = None
        best_similarity = 0
        
        # (3) 모든 캐시의 유사도 계산
        for result in results:
            cached_embedding = json.loads(result[5])
            
            # (4) 코사인 유사도 계산
            similarity = self._cosine_similarity(query_embedding, cached_embedding)
            
            # (5) 임계값 초과하고 가장 유사한 것 선택
            if similarity > threshold and similarity > best_similarity:
                best_similarity = similarity
                best_match = result
        
        if best_match:
            # (6) 히트 카운트 증가
            cache_id = best_match[0]
            cursor.execute("UPDATE llm_cache SET hit_count = hit_count + 1 WHERE id = ?",
                          (cache_id,))
            conn.commit()
            
            print(f"[Semantic Hit] '{query[:20]}...' (유사도: {best_similarity:.2%})")
            
            return {
                'id': best_match[0],
                'matched_query': best_match[1],
                'response': best_match[2],
                'model': best_match[3],
                'provider': best_match[4],
                'tokens': best_match[6],
                'cost': best_match[7],
                'hit_count': best_match[8] + 1,
                'match_type': 'semantic',
                'similarity': best_similarity
            }
        
        conn.close()
        return None
    
    def get_response(self, query: str) -> Optional[Dict[str, Any]]:
        """
        먼저 정확 매칭, 실패 시 의미 매칭으로 조회합니다
        
        Args:
            query: 질문
            
        Returns:
            캐시 데이터 또는 None
        """
        # (1) 먼저 정확 매칭 시도
        exact_result = self.get_response_exact(query)
        if exact_result:
            return exact_result
        
        # (2) 정확 매칭 실패 → 의미 매칭 시도
        semantic_result = self.get_response_semantic(query, threshold=0.92)
        if semantic_result:
            return semantic_result
        
        # (3) 모두 실패
        print(f"[Cache Miss] '{query[:20]}...'")
        return None
    
    def get_stats(self) -> Dict[str, Any]:
        """
        캐시 통계 조회
        
        Returns:
            통계 딕셔너리
        """
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute("SELECT COUNT(*) FROM llm_cache")
        total = cursor.fetchone()[0]
        
        cursor.execute("SELECT SUM(hit_count) FROM llm_cache")
        total_hits = cursor.fetchone()[0] or 0
        
        cursor.execute("SELECT SUM(cost) FROM llm_cache")
        total_savings = cursor.fetchone()[0] or 0.0
        
        cursor.execute("""
            SELECT COUNT(*) FROM llm_cache
            WHERE expires_at IS NULL OR expires_at > datetime('now')
        """)
        valid = cursor.fetchone()[0]
        
        conn.close()
        
        return {
            'total_cached': total,
            'valid_cached': valid,
            'total_hits': total_hits,
            'cost_savings': total_savings
        }


# ========== 테스트 ==========
if __name__ == "__main__":
    print("=" * 60)
    print("SQLite Cache Layer 테스트")
    print("=" * 60 + "\n")
    
    # (1) 캐시 레이어 생성
    cache = SQLiteCacheLayer(db_path="test_cache.db")
    
    # (2) 응답 저장
    cache.save_response(
        query="Python이란?",
        response="Python은 고급 프로그래밍 언어입니다.",
        model="gpt-4o-mini",
        provider="openai",
        tokens=50,
        cost=0.00015
    )
    
    cache.save_response(
        query="AI란 무엇인가?",
        response="AI는 인공지능의 약자입니다.",
        model="gpt-4o-mini",
        provider="openai",
        tokens=45,
        cost=0.00013
    )
    
    print()
    
    # (3) 정확 매칭 테스트
    result1 = cache.get_response_exact("Python이란?")
    if result1:
        print(f"응답: {result1['response']}\n")
    
    # (4) 의미 매칭 테스트 (유사한 질문)
    result2 = cache.get_response_semantic("Python에 대해서?", threshold=0.85)
    if result2:
        print(f"유사 질문: '{result2['matched_query']}'")
        print(f"응답: {result2['response']}\n")
    
    # (5) 캐시 미스 테스트
    result3 = cache.get_response("JavaScript란?")
    
    print()
    
    # (6) 통계
    stats = cache.get_stats()
    print("=" * 60)
    print(f"총 캐시: {stats['total_cached']}개")
    print(f"유효한 캐시: {stats['valid_cached']}개")
    print(f"총 히트: {stats['total_hits']}회")
    print(f"절감된 비용: ${stats['cost_savings']:.6f}")
    print("=" * 60)
