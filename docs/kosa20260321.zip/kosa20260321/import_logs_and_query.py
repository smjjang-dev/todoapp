import sqlite3
import json
import re
from pathlib import Path

# ==========================================================
# 설정값
# ==========================================================
# 로그 파일명과 DB 파일명을 한 곳에 모아두면 수정하기 쉽습니다.
LOG_FILE = 'logs.txt'
DB_FILE = 'logs.db'

# ==========================================================
# 로그 한 줄을 해석하기 위한 정규표현식
# ==========================================================
# 예시 로그 형식:
# 2025-05-23T08:42:04.745Z [ERROR] [user-api] trace_id=... user_id=... event_type=... method=... ip=... response_time=753ms status=400 metadata={...}
#
# 각 항목을 이름으로 뽑아내기 위해 (?P<이름>패턴) 형태를 사용합니다.
LOG_PATTERN = re.compile(
    r'^(?P<timestamp>\S+)\s+'
    r'\[(?P<level>\w+)\]\s+'
    r'\[(?P<service>[^\]]+)\]\s+'
    r'trace_id=(?P<trace_id>\S+)\s+'
    r'user_id=(?P<user_id>\S+)\s+'
    r'event_type=(?P<event_type>\S+)\s+'
    r'method=(?P<method>\S+)\s+'
    r'ip=(?P<ip>\S+)\s+'
    r'response_time=(?P<response_time>\d+)ms\s+'
    r'status=(?P<status>\d+)\s+'
    r'metadata=(?P<metadata>\{.*\})$'
)


def create_table(conn: sqlite3.Connection) -> None:
    """로그를 저장할 테이블을 생성합니다."""
    conn.execute(
        '''
        CREATE TABLE IF NOT EXISTS api_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp TEXT,
            level TEXT,
            service TEXT,
            trace_id TEXT,
            user_id TEXT,
            event_type TEXT,
            method TEXT,
            ip TEXT,
            response_time_ms INTEGER,
            status INTEGER,
            metadata_json TEXT,
            region TEXT,
            session_id TEXT,
            request_id TEXT
        )
        '''
    )
    conn.commit()


def clear_table(conn: sqlite3.Connection) -> None:
    """기존 데이터를 모두 비웁니다.

    스크립트를 여러 번 실행해도 중복으로 쌓이지 않게 하기 위해 사용합니다.
    """
    conn.execute('DELETE FROM api_logs')
    conn.commit()


def parse_log_line(line: str):
    """로그 한 줄을 파싱해서 딕셔너리로 반환합니다.

    형식이 맞지 않으면 None을 반환합니다.
    """
    match = LOG_PATTERN.match(line.strip())
    if not match:
        return None

    data = match.groupdict()

    # metadata는 JSON 문자열이므로 json.loads()로 딕셔너리로 변환합니다.
    metadata_dict = json.loads(data['metadata'])

    return {
        'timestamp': data['timestamp'],
        'level': data['level'],
        'service': data['service'],
        'trace_id': data['trace_id'],
        'user_id': data['user_id'],
        'event_type': data['event_type'],
        'method': data['method'],
        'ip': data['ip'],
        'response_time_ms': int(data['response_time']),
        'status': int(data['status']),
        'metadata_json': data['metadata'],
        'region': metadata_dict.get('region'),
        'session_id': metadata_dict.get('session_id'),
        'request_id': metadata_dict.get('request_id'),
    }


def insert_logs(conn: sqlite3.Connection, log_file: str) -> None:
    """로그 파일을 읽어서 SQLite DB에 저장합니다."""
    inserted_count = 0
    skipped_count = 0

    with open(log_file, 'r', encoding='utf-8') as f:
        for line_number, line in enumerate(f, start=1):
            line = line.strip()
            if not line:
                continue

            row = parse_log_line(line)
            if row is None:
                skipped_count += 1
                print(f'[경고] {line_number}번째 줄은 형식이 달라서 건너뜁니다.')
                continue

            conn.execute(
                '''
                INSERT INTO api_logs (
                    timestamp, level, service, trace_id, user_id,
                    event_type, method, ip, response_time_ms, status,
                    metadata_json, region, session_id, request_id
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ''',
                (
                    row['timestamp'],
                    row['level'],
                    row['service'],
                    row['trace_id'],
                    row['user_id'],
                    row['event_type'],
                    row['method'],
                    row['ip'],
                    row['response_time_ms'],
                    row['status'],
                    row['metadata_json'],
                    row['region'],
                    row['session_id'],
                    row['request_id'],
                )
            )
            inserted_count += 1

    conn.commit()
    print(f'총 {inserted_count}건 저장 완료')
    print(f'총 {skipped_count}건 건너뜀')


# ==========================================================
# 실행할 SQL
# ==========================================================
# 1) 전체 로그의 평균 응답시간
SQL_AVG_RESPONSE_TIME = '''
SELECT ROUND(AVG(response_time_ms), 2) AS avg_response_time_ms
FROM api_logs;
'''

# 2) 느린 API 상위 5개 (API를 method + event_type 조합으로 정의)
#    예: POST login, GET file_download, PATCH profile_update
SQL_TOP5_SLOW_API = '''
SELECT
    method || ' ' || event_type AS api_name,
    COUNT(*) AS request_count,
    ROUND(AVG(response_time_ms), 2) AS avg_response_time_ms,
    MAX(response_time_ms) AS max_response_time_ms
FROM api_logs
GROUP BY method, event_type
ORDER BY avg_response_time_ms DESC
LIMIT 5;
'''

# 참고용: 느린 "개별 요청" 상위 5건을 보고 싶을 때 사용할 SQL
SQL_TOP5_SLOW_REQUESTS = '''
SELECT
    method || ' ' || event_type AS api_name,
    response_time_ms,
    status,
    trace_id,
    timestamp
FROM api_logs
ORDER BY response_time_ms DESC
LIMIT 5;
'''


def print_query_result(conn: sqlite3.Connection) -> None:
    """SQL을 실행하고 결과를 보기 쉽게 출력합니다."""

    # 1. 평균 응답시간
    print('\n[1] 전체 평균 응답시간')
    print('-' * 50)
    cursor = conn.execute(SQL_AVG_RESPONSE_TIME)
    row = cursor.fetchone()
    print(f"평균 응답시간: {row[0]} ms")

    # 2. 느린 API 상위 5개
    print('\n[2] 평균 기준으로 느린 API 상위 5개')
    print('-' * 90)
    print(f"{'순위':<4} {'API':<25} {'요청수':>8} {'평균(ms)':>12} {'최대(ms)':>12}")
    print('-' * 90)

    cursor = conn.execute(SQL_TOP5_SLOW_API)
    for idx, row in enumerate(cursor.fetchall(), start=1):
        api_name, request_count, avg_ms, max_ms = row
        print(f"{idx:<4} {api_name:<25} {request_count:>8} {avg_ms:>12} {max_ms:>12}")

    # 3. 참고: 개별 요청 기준 상위 5건
    print('\n[3] 참고 - 개별 요청 기준으로 가장 느린 5건')
    print('-' * 110)
    print(f"{'순위':<4} {'API':<25} {'응답시간(ms)':>12} {'상태코드':>10} {'trace_id':<40}")
    print('-' * 110)

    cursor = conn.execute(SQL_TOP5_SLOW_REQUESTS)
    for idx, row in enumerate(cursor.fetchall(), start=1):
        api_name, response_time_ms, status, trace_id, timestamp = row
        print(f"{idx:<4} {api_name:<25} {response_time_ms:>12} {status:>10} {trace_id:<40}")


def main() -> None:
    """프로그램 시작점"""

    # 현재 폴더에 로그 파일이 있는지 확인합니다.
    if not Path(LOG_FILE).exists():
        print(f'[오류] {LOG_FILE} 파일을 찾을 수 없습니다.')
        print('파이썬 파일과 logs.txt를 같은 폴더에 두고 다시 실행하세요.')
        return

    # SQLite DB 연결 (파일이 없으면 자동 생성됨)
    conn = sqlite3.connect(DB_FILE)

    try:
        create_table(conn)
        clear_table(conn)
        insert_logs(conn, LOG_FILE)
        print_query_result(conn)
        print(f'\nSQLite DB 파일 생성 완료: {DB_FILE}')
    finally:
        conn.close()


if __name__ == '__main__':
    main()