# generate_logs.py
# ---------------------------------------------------------
# 테스트용 API 로그 100건을 생성하여 logs.txt 파일로 저장하는 예제
# 윈도우 환경에서 바로 실행 가능
# 추가 라이브러리 설치 필요 없음
# ---------------------------------------------------------

import uuid          # 고유한 ID(trace_id 등) 생성용
import random        # 랜덤 데이터 생성용
import json          # metadata를 JSON 문자열로 만들기 위해 사용
from datetime import datetime, timedelta  # 시간 계산용


# ---------------------------------------------------------
# 1. 로그 생성에 사용할 기본 데이터 정의
# ---------------------------------------------------------

# 로그 생성 시작 시간
# 예시 로그와 비슷하게 2025-05-23 08:40 기준으로 시작
base_time = datetime(2025, 5, 23, 8, 40, 0)

# API 이벤트 종류
event_types = [
    "file_upload",
    "file_download",
    "login",
    "logout",
    "profile_update",
    "password_change"
]

# 이벤트별 HTTP 메서드 매핑
# 예: file_upload는 PUT, login은 POST
methods = {
    "file_upload": "PUT",
    "file_download": "GET",
    "login": "POST",
    "logout": "POST",
    "profile_update": "PATCH",
    "password_change": "POST"
}

# 리전 목록
regions = [
    "ap-southeast-1",
    "ap-northeast-2",
    "us-east-1",
    "eu-west-1"
]

# 상태 코드 목록
status_codes = [200, 201, 204, 400, 401, 403, 404, 500]

# 상태 코드에 따른 로그 레벨 매핑
# 일반적으로 성공은 INFO, 인증/권한 문제는 WARN, 오류는 ERROR로 분류
log_levels = {
    200: "INFO",
    201: "INFO",
    204: "INFO",
    400: "ERROR",
    401: "WARN",
    403: "WARN",
    404: "ERROR",
    500: "ERROR"
}


# ---------------------------------------------------------
# 2. 로그 한 줄을 만드는 함수
# ---------------------------------------------------------
def make_one_log():
    """
    테스트용 로그 한 줄을 문자열로 만들어 반환한다.
    """

    # 시작 시간(base_time) 기준으로 0~500초 사이의 임의 시간 추가
    # milliseconds 단위까지 랜덤하게 만들기 위해 초 대신 밀리초 사용
    random_milliseconds = random.randint(0, 500000)
    log_time = base_time + timedelta(milliseconds=random_milliseconds)

    # ISO 형식 시간 문자열 생성
    # 예: 2025-05-23T08:40:32.635Z
    timestamp = log_time.isoformat(timespec="milliseconds") + "Z"

    # 이벤트 하나 랜덤 선택
    event_type = random.choice(event_types)

    # 이벤트에 맞는 HTTP 메서드 가져오기
    method = methods[event_type]

    # 상태 코드 랜덤 선택
    status = random.choice(status_codes)

    # 상태 코드에 따른 로그 레벨 결정
    level = log_levels[status]

    # trace_id 생성 (UUID 사용)
    trace_id = str(uuid.uuid4())

    # user_id 생성
    # 예: user_13457
    user_id = f"user_{random.randint(10000, 20000)}"

    # 사설 IP 형식으로 생성
    # 예: 10.0.0.120
    ip = f"10.0.{random.randint(0, 10)}.{random.randint(1, 254)}"

    # 응답 시간(ms) 생성
    # 예: 1409ms
    response_time = random.randint(50, 2500)

    # metadata 내부 정보 생성
    metadata = {
        "region": random.choice(regions),
        "session_id": f"sess_{uuid.uuid4().hex[:8]}",
        "request_id": f"req_{uuid.uuid4().hex[:12]}"
    }

    # metadata를 JSON 문자열로 변환
    # ensure_ascii=False 는 한글 등이 있을 때 깨지지 않게 해준다.
    metadata_str = json.dumps(metadata, ensure_ascii=False)

    # 최종 로그 문자열 조립
    log_line = (
        f"{timestamp} "
        f"[{level}] "
        f"[user-api] "
        f"trace_id={trace_id} "
        f"user_id={user_id} "
        f"event_type={event_type} "
        f"method={method} "
        f"ip={ip} "
        f"response_time={response_time}ms "
        f"status={status} "
        f"metadata={metadata_str}"
    )

    return log_line


# ---------------------------------------------------------
# 3. 여러 건의 로그를 파일로 저장하는 함수
# ---------------------------------------------------------
def save_logs_to_file(filename="logs.txt", count=100):
    """
    지정한 개수(count)만큼 로그를 생성하여 filename 파일로 저장한다.
    """

    # 생성한 로그를 저장할 리스트
    logs = []

    # count만큼 로그 생성
    for _ in range(count):
        log_line = make_one_log()
        logs.append(log_line)

    # 파일 쓰기
    # encoding="utf-8" 로 저장하여 문자 깨짐 방지
    with open(filename, "w", encoding="utf-8") as file:
        for log in logs:
            file.write(log + "\n")

    # 사용자에게 결과 안내
    print(f"로그 파일 생성 완료: {filename}")
    print(f"총 {count}건의 로그를 저장했습니다.\n")

    # 화면에 앞부분 5건만 미리 보여주기
    print("생성된 로그 예시(앞 5건):")
    for i in range(min(5, len(logs))):
        print(logs[i])


# ---------------------------------------------------------
# 4. 프로그램 시작 지점
# ---------------------------------------------------------
if __name__ == "__main__":
    # 기본값: logs.txt 파일에 100건 저장
    save_logs_to_file("logs.txt", 100)