# Hybrid LLM 서비스 구현 - 강의 교안 (보완본)

**과정명:** Hybrid LLM 서비스 구현 실전 완성반  
**기간:** 2일 / 총 12시간  
**환경:** Windows 11, Python 3.13, VS Code, OpenAI API Key, Ollama, SQLite  
**대상:** 3~5년 경력 실무자

---

## 핵심 컨셉: 3가지 Hybrid 전략

```
┌─────────────────────────────────────────────────────────┐
│         Hybrid LLM 서비스 3가지 핵심 전략               │
├─────────────────────────────────────────────────────────┤
│                                                         │
│ ⓐ Provider Hybrid                                       │
│    OpenAI ↔ Ollama (자동 라우팅)                        │
│    → 비용 최적화 + 개인정보 보호                         │
│                                                         │
│ ⓑ Model Tiering                                        │
│    gpt-4o-mini ↔ gpt-4o (자동 선택)                     │
│    → 복잡도에 따른 모델 자동 선택                        │
│                                                         │
│ ⓒ Cache Layer (SQLite 기반)                            │
│    Exact Match + Semantic Match                         │
│    → 중복 요청 제거 → 비용/속도 개선                     │
│                                                         │
└─────────────────────────────────────────────────────────┘
```

---

## 전체 커리큘럼 (시간표)

### Day 1: OpenAI, Ollama, SQLite 기초

| 시간 | 차시 | 주제 | 형식 | 실습파일 |
|------|------|------|------|---------|
| 10:00-10:50 | 1교시 | 지능형 서비스 최신 동향 | 이론 | - |
| 11:00-11:50 | 2교시 | LLM 서비스 구조와 특징 | 이론+실습 | hello_llm.py, chat_stream.py |
| 13:00-13:50 | 3교시 | OpenAI 심화 (Function Calling) | 이론+실습 | function_calling.py |
| 14:00-14:50 | 4교시 | Local LLM과 Ollama | 이론+실습 | ollama_basic.py |
| 15:00-15:50 | 5교시 | SQLite 기초와 LLM 캐시 설계 | 이론+실습 | sqlite_cache.py |
| 16:00-16:50 | 6교시 | 통합 LLM 클라이언트 | 실습 | unified_client.py |

### Day 2: Hybrid 전략, 라우팅, 조립, 배포

| 시간 | 차시 | 주제 | 형식 | 실습파일 |
|------|------|------|------|---------|
| 09:00-09:50 | 7교시 | Hybrid 전략 이론 | 이론 | - |
| 10:00-10:50 | 8교시 | Provider Router 구현 | 실습 | provider_router.py |
| 11:00-11:50 | 9교시 | Model Tiering Router 구현 | 실습 | model_tiering.py |
| 13:00-13:50 | 10교시 | SQLite 기반 Cache Layer | 실습 | cache_layer.py |
| 14:00-14:50 | 11교시 | Hybrid Engine 조립 | 실습 | hybrid_engine.py |
| 15:00-15:50 | 12교시 | Flask 웹앱 통합 + 대시보드 | 실습 | app.py, index.html |
| 16:00-16:50 | 마무리 | 최종 평가, Q&A | 평가 | - |

---

## 개발환경 사전 준비

### Step 1: Python 3.13 확인
```bash
python --version
python -m pip --version
```

### Step 2: 프로젝트 폴더 + venv
```bash
mkdir hybrid-llm-project
cd hybrid-llm-project
python -m venv venv
venv\Scripts\activate
```

### Step 3: 필수 패키지 설치 (NO diskcache)
```bash
pip install openai==1.52.0 flask==3.0.0 python-dotenv==1.0.0 numpy==1.24.3 requests==2.31.0
```
**주의:** sqlite3는 Python 내장 모듈이므로 설치 불필요

### Step 4: Ollama 설치
https://ollama.ai 에서 다운로드 후 설치

### Step 5: .env 파일 생성
```
OPENAI_API_KEY=sk-your-key-here
OLLAMA_BASE_URL=http://localhost:11434
```

### Step 6: verify_env.py (환경 검증)
```python
# ============================================================
# verify_env.py - 개발환경 검증 스크립트
# ============================================================
import os
import sys
import sqlite3
from dotenv import load_dotenv

print("=" * 60)
print("개발환경 검증 시작")
print("=" * 60)

# (1) Python 버전 확인
print(f"\n[1] Python 버전: {sys.version}")
assert sys.version_info >= (3, 10), "Python 3.10 이상 필요"

# (2) 필수 패키지 확인
try:
    import openai
    print(f"[2] OpenAI 패키지: OK (v{openai.__version__})")
except ImportError:
    print("[2] OpenAI 패키지: MISSING - pip install openai")

try:
    import flask
    print(f"[3] Flask 패키지: OK")
except ImportError:
    print("[3] Flask 패키지: MISSING - pip install flask")

try:
    import numpy
    print(f"[4] NumPy 패키지: OK")
except ImportError:
    print("[4] NumPy 패키지: MISSING - pip install numpy")

# (3) SQLite 확인 (내장 모듈)
try:
    conn = sqlite3.connect(":memory:")
    cursor = conn.cursor()
    cursor.execute("SELECT sqlite_version()")
    version = cursor.fetchone()[0]
    conn.close()
    print(f"[5] SQLite: OK (v{version})")
except Exception as e:
    print(f"[5] SQLite: ERROR - {e}")

# (4) .env 파일 확인
load_dotenv()
api_key = os.getenv("OPENAI_API_KEY")
if api_key and api_key.startswith("sk-"):
    print("[6] OPENAI_API_KEY: OK (발견됨)")
else:
    print("[6] OPENAI_API_KEY: MISSING - .env 파일에 설정 필요")

# (5) Ollama 연결 확인
try:
    import requests
    response = requests.get("http://localhost:11434/api/tags", timeout=2)
    if response.status_code == 200:
        print("[7] Ollama 서버: OK (실행 중)")
    else:
        print("[7] Ollama 서버: NOT RESPONDING")
except:
    print("[7] Ollama 서버: NOT RUNNING - 별도 CMD에서 'ollama serve' 실행 필요")

print("\n" + "=" * 60)
print("검증 완료")
print("=" * 60)
```

---

## 1일차 강의 자료

### [10:00-10:50] 1교시: 지능형 서비스 최신 동향

#### 1.1 AI/LLM 진화 과정

**개념:** Large Language Model(LLM)은 인간 언어를 이해하고 생성하는 신경망 기반 AI 모델입니다.

| 연도 | 모델 | 특징 | 영향 |
|------|------|------|------|
| 2017 | Transformer | Attention 메커니즘 | 현대 LLM의 기초 |
| 2018 | BERT | 양방향 학습 | 자연어 이해 혁신 |
| 2020 | GPT-3 | 1,750억 파라미터 | In-context learning 발견 |
| 2023.3 | GPT-4 | 멀티모달 (텍스트+이미지) | 전문 분야 활용 시작 |
| 2024 | GPT-4 Turbo | 128K 컨텍스트 | 장문서 처리 가능 |
| 2025 | GPT-4o Mini | 저비용 고속 | 엣지 디바이스 배포 |

**특징:**
- 토크나이제이션: 텍스트 → 수치 벡터
- 트랜스포머: Self-Attention → 단어 간 관계 학습
- In-Context Learning: 예시 제공 → 학습 없이 패턴 수행
- Token 기반 과금: 입력+출력 토큰 수로 비용 계산

**사례:**
- ChatGPT: 일반인용 대화형 AI (2,000만 사용자)
- 의료 AI: 의료영상 진단 (Radiology 정확도 95%+)
- 코딩 어시스턴트: GitHub Copilot (개발자 생산성 35% ↑)
- 고객상담봇: 카카오 고카봇 (일일 100만 사용자)

**고려사항:**
- 할루시네이션: LLM이 그럴듯한 거짓 정보 생성
- 토큰 계산: 1,000 토큰 ≈ 750 단어 (각 모델별 다름)
- 컨텍스트 길이 제한: GPT-4o는 128K (≈100,000단어)
- 비용: 입출력 토큰 가격이 다름 (GPT-4o-mini는 5배 저렴)

#### 1.2 Tokenization 심화

**개념:** 텍스트를 모델이 이해할 수 있는 토큰 단위로 분할하는 과정

```
입력: "안녕하세요, LLM 강의입니다!"

[BPE 토크나이저 적용]

출력 토큰: [50256, 48335, 44617, 47152, 34738, ...]
(각 숫자는 어휘 사전의 인덱스)

토큰 수: 6개
비용: 6 × $0.00005 (입력 기준 GPT-4o-mini) = $0.0003
```

**특징:**
- GPT 계열: BPE(Byte Pair Encoding) 사용
- Ollama (llama2): SentencePiece 사용
- 모델마다 토크나이저 다름 → 같은 텍스트도 토큰 수 다름
- 수학 기호, 코드: 토큰 낭비 (1단어 = 3~5 토큰)

**고려사항:**
- 토큰 수 계산: OpenAI tiktoken 라이브러리로 정확히 계산
- 컨텍스트 윈도우 초과 방지: 동적으로 입력 길이 조정
- 비용 최적화: 불필요한 텍스트 제거 (예: 마크다운 서식)

#### 1.3 2025-2026 LLM 트렌드

| 트렌드 | 설명 | 영향 |
|--------|------|------|
| Multimodal | 텍스트+이미지+영상 통합 처리 | 더 강력한 분석 가능 |
| RAG (검색증강생성) | 외부 데이터 + LLM | 최신 정보 활용 가능 |
| Fine-tuning as a Service | 클라우드 기반 커스텀 모델 | 업체별 특화 모델 구축 |
| Edge LLM | 디바이스 로컬 실행 (Ollama) | 비용↓ 개인정보 보호↑ |
| Agent 시스템 | LLM이 도구 자동 호출 | 자동화 수준 향상 |
| Hybrid 라우팅 | 비용/속도/품질 트레이드오프 | 이 강의의 핵심 |

#### 1.4 OpenAI 모델 비교 (2025년 기준)

```
┌──────────────────┬─────────────┬──────────┬──────────┬─────────┐
│ 모델             │ 입력/출력   │ 속도     │ 정확도   │ 용도    │
├──────────────────┼─────────────┼──────────┼──────────┼─────────┤
│ gpt-4o-mini      │ $0.15/$0.6  │ 매우 빠름 │ 우수     │ 간단한  │
│                  │ / 1M tokens │          │          │ 작업    │
├──────────────────┼─────────────┼──────────┼──────────┼─────────┤
│ gpt-4o           │ $5/$15      │ 보통     │ 최고     │ 복잡한  │
│                  │ / 1M tokens │          │          │ 작업    │
├──────────────────┼─────────────┼──────────┼──────────┼─────────┤
│ gpt-4-turbo      │ $10/$30     │ 느림     │ 최고     │ 전문성  │
│                  │ / 1M tokens │          │          │ 요청    │
└──────────────────┴─────────────┴──────────┴──────────┴─────────┘

** 비용 계산 예시:
   
입력: "안녕하세요" (한국어 5단어)
→ 약 15 토큰 (한국어는 토큰이 많음)
비용: 15 × $0.00015 (gpt-4o-mini 입력) = $0.00225

1,000개 요청 시:
gpt-4o-mini: $2.25 (매우 저렴)
gpt-4o: $75 (30배 비쌈)
```

#### 1.5 Ollama 모델 비교

```
┌───────────────┬────────────┬──────────┬────────┬──────────────┐
│ 모델          │ 크기       │ 메모리   │ 속도   │ 정확도       │
├───────────────┼────────────┼──────────┼────────┼──────────────┤
│ mistral:7b    │ 4.2 GB     │ 6 GB RAM │ 빠름   │ 중상         │
│ llama2:7b     │ 3.8 GB     │ 5 GB RAM │ 빠름   │ 중상         │
│ neural-chat   │ 4.1 GB     │ 6 GB RAM │ 매우   │ 중상         │
│               │            │          │ 빠름   │              │
│ vicuna:13b    │ 7.6 GB     │ 10 GB    │ 보통   │ 중상         │
│               │            │          │        │              │
│ orca-mini:3b  │ 1.9 GB     │ 3 GB RAM │ 매우   │ 낮음         │
│               │            │          │ 빠름   │              │
└───────────────┴────────────┴──────────┴────────┴──────────────┘

** 설치 및 실행:
ollama pull mistral:7b          # 다운로드
ollama serve                    # 11434 포트에서 실행
(별도 CMD에서)

ollama run mistral:7b           # 대화형 테스트
ollama ls                       # 설치된 모델 확인
```

#### 1.6 왜 Hybrid 접근이 필요한가?

**비용 시뮬레이션:**

시나리오: 매일 1,000개의 고객 질문 처리

```
[안티패턴] 모든 요청을 GPT-4o로 처리
───────────────────────────────────────
- 1,000 요청 × 평균 100 입력 토큰 × $0.005 (입력 가격) = $500/일
- 1,000 요청 × 평균 150 출력 토큰 × $0.015 (출력 가격) = $2,250/일
- 일일 비용: $2,750
- 월간 비용: $82,500 ❌

[Hybrid 패턴] 지능형 라우팅
───────────────────────────────────────
요청 분류:
  - 50%: 간단한 질문 → gpt-4o-mini 사용
  - 30%: 캐시 히트 (이전 질문과 동일) → DB에서 즉시 응답
  - 15%: 중간 복잡도 → gpt-4o 사용
  - 5%: 개인정보 포함 → Ollama (로컬, 비용 0)

비용 계산:
  - 500 × gpt-4o-mini (간단): $250
  - 150 × gpt-4o-mini (캐시, 0 비용): $0
  - 250 × gpt-4o (중간): $1,875
  - 100 × Ollama (개인정보, 0 비용): $0
  - 일일 비용: $2,125 (23% 절감)
  - 월간 비용: $63,750 (23% 절감)

추가 이득:
  - 개인정보 보호: Ollama를 통해 민감 정보 OpenAI 전송 X
  - 응답 속도: 캐시 히트 시 < 10ms (GPT-4o는 1~5초)
  - 신뢰도: 캐시된 답변은 일관성 100%
```

#### 1.7 까칠한 수강생 Q&A

**Q1: "GPT-4o-mini로 충분하지 않을까요? 왜 복잡하게 Hybrid를?"**

A: 좋은 질문입니다. gpt-4o-mini의 정확도는 매우 높지만, 3가지 한계가 있습니다:
   1. 복잡한 분석 작업: 금융 보고서 분석, 법률 검토 → gpt-4o 필요 (10배 더 정확)
   2. 개인정보: PII 포함 질문 → gpt-4o-mini도 OpenAI 서버로 전송 (개인정보보호 문제)
   3. 비용 최적화: 캐시 활용 못하면 매일 수백만 원 낭비
   
   → 따라서 Hybrid는 "필수"입니다.

**Q2: "Ollama는 얼마나 느린가요?"**

A: 매우 좋은 질문입니다. 벤치마크 결과:
   ```
   응답 시간:
   - GPT-4o: 1~5초 (네트워크 포함)
   - gpt-4o-mini: 0.5~2초
   - Ollama (mistral:7b): 2~10초 (CPU) / 0.5~2초 (GPU)
   ```
   
   CPU에서는 느리지만, GPU가 있으면 (GTX 3060 이상) gpt-4o-mini와 비슷합니다.
   따라서 "간단한 질문"만 Ollama로 라우팅하면 문제 없습니다.

**Q3: "SQLite 캐시는 정확할까요? 다른 사람의 답변을 줄 수도?"**

A: 매우 중요한 질문입니다. 우리의 캐시 방식:
   ```
   완전 동일 질문만 캐시 히트:
   - Exact Match: SHA256 해시로 정확히 일치하는 질문만
   - 예: "Python 리스트 정렬?" ≠ "Python 리스트를 어떻게 정렬해?"
   - → 약 30%만 캐시 히트 (여전히 가치 있음)
   
   Semantic Match (심화 내용):
   - 임베딩 벡터로 "의미가 유사한" 질문도 매칭
   - 예: "Python 배열 순서? " ≈ "Python 리스트 정렬?"
   - → 조금 더 위험하지만, cosine similarity > 0.95만 매칭
   - → 약 45%까지 캐시 히트 가능
   ```
   
   **결론:** Exact Match는 100% 안전합니다.

**Q4: "실무에서 이미 비슷한 시스템 있지 않을까?"**

A: 좋은 지적입니다. 기존 솔루션:
   - LangChain: 복잡도 높음, 과하다
   - LlamaIndex: RAG에 특화, Hybrid 라우팅은 없음
   - 직접 구축: 이 강의의 목표 (쉽고, 맞춤화 가능)
   
   우리가 만드는 이유:
   1. 간단하고 이해하기 쉬움
   2. 자신의 요구사항에 맞게 커스터마이징 가능
   3. 실제로 실무에서 어떻게 작동하는지 배움

**Q5: "비용 절감이 정말 23% 맞나요? 그게 중요할까요?"**

A: 계산을 다시 확인하면, 23%는 보수적 추정입니다. 실제로는:
   - 캐시 히트율이 50% 이상인 조직: 40~50% 절감
   - Ollama 활용이 많은 조직: 60% 이상 절감
   
   월간 $82,500 → $40,000으로 줄면, 연간 $510,000 절감입니다.
   이는 1명 연봉 수준입니다. 매우 중요합니다.

---

### [11:00-11:50] 2교시: LLM 서비스 구조와 특징

#### 2.1 4가지 LLM 서비스 패턴

```
┌─────────────────────────────────────────────────────────┐
│ 패턴1: Direct API                                      │
├─────────────────────────────────────────────────────────┤
│ 사용자 질문 → LLM → 응답                                 │
│ 장점: 간단, 빠름                                         │
│ 단점: 외부 정보 미반영, 비용 높음                        │
│ 사용: ChatGPT, 일반 Q&A                                 │
└─────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────┐
│ 패턴2: RAG (Retrieval-Augmented Generation)             │
├─────────────────────────────────────────────────────────┤
│ 사용자 질문 → 검색 (DB) → LLM → 응답                     │
│ 장점: 최신 정보 사용, 맥락 풍부                           │
│ 단점: 검색 성능에 좌우                                   │
│ 사용: 문서 기반 QA, 회사 정책 챗봇                       │
└─────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────┐
│ 패턴3: Agent                                            │
├─────────────────────────────────────────────────────────┤
│ 사용자 질문 → LLM (도구 선택) → 도구 실행 → LLM → 응답   │
│ 장점: 자동화 수준 높음, 유연함                           │
│ 단점: 복잡도 높음, 디버깅 어려움                         │
│ 사용: 자동화 봇, 복합 작업                               │
└─────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────┐
│ 패턴4: Hybrid (이 강의의 초점)                           │
├─────────────────────────────────────────────────────────┤
│ 질문 분류 → 캐시 확인 → 라우팅 (OpenAI/Ollama) → 응답    │
│ 장점: 비용 낮음, 개인정보 보호, 응답 빠름               │
│ 단점: 구현 복잡도 중간                                   │
│ 사용: 엔터프라이즈급 챗봇, 고비용 서비스                  │
└─────────────────────────────────────────────────────────┘
```

#### 2.2 OpenAI API 메시지 구조

**기본 구조:**

```python
# 사용자 정의 메시지
{
    "role": "user",           # "user", "assistant", "system" 중 하나
    "content": "안녕하세요"    # 텍스트 또는 content array
}

# LLM의 응답
{
    "role": "assistant",
    "content": "안녕하세요! 무엇을 도와드릴까요?"
}

# 시스템 지시
{
    "role": "system",         # 첫 메시지로 사용
    "content": "당신은 친절한 한국어 어시스턴트입니다."
}
```

**메시지 흐름:**

```
[대화 히스토리 (컨텍스트)]

1. system: "한국어 어시스턴트"
2. user: "Python이란?"
3. assistant: "Python은 프로그래밍..."
4. user: "장점은?" (이전 메시지들이 컨텍스트)
5. assistant: "1. 간단함, 2. 라이브러리..."

→ API 호출 시 모든 메시지를 함께 전송
→ API가 "대화 흐름" 이해
```

#### 2.3 OpenAI API 핵심 파라미터

```python
client.chat.completions.create(
    model="gpt-4o-mini",              # 사용할 모델
    messages=[...],                   # 메시지 리스트
    
    # ===== 출력 제어 =====
    temperature=0.7,                  # 창의성 (0=결정적, 1=창의적)
    max_tokens=1000,                  # 최대 출력 토큰 수
    top_p=0.9,                        # 누적 확률 기반 필터링
    
    # ===== 고급 기능 =====
    tools=[...],                      # Function Calling (실습 3)
    tool_choice="auto",               # 도구 선택 방식
    
    # ===== 응답 방식 =====
    stream=False,                     # True면 스트리밍 모드
    response_format={"type": "json"}  # JSON 강제 출력
)
```

**파라미터 해설:**

| 파라미터 | 범위 | 의미 | 예시 |
|---------|------|------|------|
| temperature | 0~2 | 높을수록 창의적 (랜덤) | 소설쓰기: 1.5, 팩트: 0.3 |
| max_tokens | 1~4096 | 최대 답변 길이 | 짧은 답: 100, 긴 글: 2000 |
| top_p | 0~1 | 다양성 필터 | 0.9: 상위 90% 확률 토큰만 |
| frequency_penalty | -2~2 | 반복 억제 | 0.5: 반복 줄임 |
| presence_penalty | -2~2 | 새로운 주제 유도 | 0.5: 새로운 표현 유도 |

**예시:**

```python
# 팩트 기반 답변 (정확성 최우선)
temp_0_3 = {
    "temperature": 0.3,        # 낮음 = 결정적
    "top_p": 0.8,
    "max_tokens": 500
}

# 창의적 글쓰기 (다양성 최우선)
temp_high = {
    "temperature": 1.2,        # 높음 = 창의적
    "top_p": 1.0,
    "max_tokens": 2000
}

# 대화형 봇 (균형)
temp_balanced = {
    "temperature": 0.7,        # 중간
    "top_p": 0.9,
    "frequency_penalty": 0.5   # 반복 줄임
}
```

---

#### [실습 1] hello_llm.py - OpenAI API 첫 호출



```python
# ============================================================
# 실습 1: OpenAI API 첫 번째 호출 (hello_llm.py)
# ============================================================
# [필수 설치] CMD에서 아래 명령어를 먼저 실행하세요:
#   pip install openai python-dotenv
# 
# [사전 준비]
#   - .env 파일에 OPENAI_API_KEY=sk-... 설정
#
# [실행 방법] CMD에서:
#   python hello_llm.py
#
# [예상 출력]
#   모델: gpt-4o-mini
#   입력 토큰: ~50
#   출력 토큰: ~100
#   비용: $0.00075
#   응답: "Python은 프로그래밍 언어입니다..."
#
# [주의사항]
#   - API 키는 절대 코드에 직접 입력하지 않기 (.env 사용)
#   - 첫 API 호출은 네트워크 지연 가능 (1~3초)
# ============================================================

# (1) 필요한 라이브러리를 불러옵니다
from openai import OpenAI              # OpenAI API 호출용 핵심 라이브러리
from dotenv import load_dotenv         # .env 파일에서 환경변수 읽기
import os                              # 운영체제 환경변수 접근

# (2) .env 파일에서 API 키를 자동으로 읽어옵니다
#     .env 파일이 현재 폴더에 있어야 합니다
load_dotenv()

# (3) OpenAI 클라이언트 객체를 생성합니다
#     api_key는 .env 파일의 OPENAI_API_KEY 값을 사용합니다
#     만약 None이면 환경변수 자동 검색
client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

# (4) OpenAI API에 요청을 보냅니다
#     chat.completions.create() : 채팅 완성 API 호출
#     - model: 사용할 AI 모델 선택
#     - messages: 대화 내용 (list of dicts)
#     - temperature: 창의성 정도 (0=정확, 1=창의적)
#     - max_tokens: 최대 응답 길이 (token 단위)
response = client.chat.completions.create(
    model="gpt-4o-mini",               # gpt-4o-mini: 가장 저렴하고 빠름
    messages=[                         # 메시지 배열
        {
            "role": "user",            # role은 3가지: "user", "assistant", "system"
            "content": "Python이란 무엇인가요? 5줄로 요약해주세요."
        }
    ],
    temperature=0.7,                   # 0.7: 적당한 창의성 (0~2 범위)
    max_tokens=200                     # 최대 200 token까지만 응답 (비용 제어)
)

# (5) API 응답에서 필요한 정보를 추출합니다

# 모델명 출력
print("=" * 60)
print(f"모델: {response.model}")        # API가 실제 사용한 모델

# 토큰 정보 추출 (API 비용 계산에 필수)
# response.usage는 OpenAI가 계산해서 반환한 토큰 통계
input_tokens = response.usage.prompt_tokens        # 입력 토큰 수
output_tokens = response.usage.completion_tokens   # 출력 토큰 수
total_tokens = response.usage.total_tokens         # 총 토큰 수

print(f"입력 토큰: {input_tokens}")
print(f"출력 토큰: {output_tokens}")
print(f"총 토큰: {total_tokens}")

# (6) 비용을 계산합니다 (gpt-4o-mini 기준, 2025년)
#     gpt-4o-mini 요금:
#     - 입력: 1M 토큰당 $0.15 = 1 토큰당 $0.00015
#     - 출력: 1M 토큰당 $0.6 = 1 토큰당 $0.0006
INPUT_COST_PER_TOKEN = 0.15 / 1_000_000      # $0.00015 per token
OUTPUT_COST_PER_TOKEN = 0.6 / 1_000_000      # $0.0006 per token

input_cost = input_tokens * INPUT_COST_PER_TOKEN   # 입력 비용
output_cost = output_tokens * OUTPUT_COST_PER_TOKEN # 출력 비용
total_cost = input_cost + output_cost              # 총 비용

print(f"입력 비용: ${input_cost:.6f}")
print(f"출력 비용: ${output_cost:.6f}")
print(f"총 비용: ${total_cost:.6f}")

# (7) 응답 내용을 출력합니다
#     response.choices[0]은 첫 번째 응답
#     .message.content는 실제 텍스트 내용
assistant_message = response.choices[0].message.content
print(f"\n응답:\n{assistant_message}")
print("=" * 60)
```

#### [실습 2] chat_stream.py - 스트리밍 대화

```python
# ============================================================
# 실습 2: 스트리밍 대화 (chat_stream.py)
# ============================================================
# [필수 설치]
#   pip install openai python-dotenv
#
# [실행 방법]
#   python chat_stream.py
#
# [예상 출력]
#   사용자: Python 배우는 가장 좋은 방법은?
#   어시스턴트: Python을 배우기 위해... (실시간으로 글자씩 출력)
#
# [주의사항]
#   - stream=True: 응답을 한 번에 받지 않고, 청크 단위로 받음
#   - 사용자 입력이 여러 번 가능 (exit 입력 시 종료)
# ============================================================

from openai import OpenAI
from dotenv import load_dotenv
import os

load_dotenv()
client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

# (1) 대화 히스토리를 저장할 리스트를 생성합니다
#     멀티턴 대화를 위해 이전 메시지들을 계속 유지해야 합니다
conversation_history = [
    {
        "role": "system",
        # system 메시지: AI의 성격/역할을 정의합니다
        # 이 메시지는 숨겨져 있고, 사용자는 보지 못합니다
        "content": "당신은 친절한 Python 튜터입니다. 초보자 수준으로 설명해주세요."
    }
]

print("=" * 60)
print("Python 튜터 챗봇 (exit 입력 시 종료)")
print("=" * 60)

while True:
    # (2) 사용자 입력을 받습니다
    user_input = input("\n사용자: ").strip()
    
    # (3) 'exit' 입력 시 대화 종료
    if user_input.lower() == "exit":
        print("안녕히 가세요!")
        break
    
    # (4) 사용자 메시지를 대화 히스토리에 추가합니다
    #     대화 히스토리는 계속 쌓여서 컨텍스트 역할을 합니다
    conversation_history.append({
        "role": "user",
        "content": user_input
    })
    
    # (5) 스트리밍 API를 호출합니다
    #     stream=True: 응답을 청크 단위로 받음 (실시간 처리 가능)
    #     messages=conversation_history: 모든 이전 대화를 포함
    stream = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=conversation_history,    # 전체 대화 히스토리 전송
        temperature=0.7,
        max_tokens=500,
        stream=True                       # ★ 이 값이 True면 스트리밍 시작
    )
    
    # (6) 스트리밍된 청크들을 처리합니다
    #     stream은 이터러블(반복 가능)이므로 for 루프로 처리
    print("어시스턴트: ", end="", flush=True)  # 프롬프트 출력
    
    # 전체 응답을 저장하기 위한 변수
    full_response = ""
    
    # 청크 단위로 응답을 받으면서 즉시 출력합니다
    for chunk in stream:
        # chunk는 StreamingChatCompletionChunk 객체
        # chunk.choices[0].delta.content에 텍스트가 있음
        if chunk.choices[0].delta.content is not None:
            # delta.content는 이 청크의 텍스트 조각
            text = chunk.choices[0].delta.content
            # end="", flush=True: 개행 없이, 즉시 출력
            print(text, end="", flush=True)
            # 전체 응답 저장 (나중에 히스토리에 추가)
            full_response += text
    
    # (7) 줄바꿈 출력
    print()
    
    # (8) 어시스턴트 응답을 대화 히스토리에 추가합니다
    #     이렇게 하면 다음 요청에서 이전 대답이 컨텍스트로 작용합니다
    conversation_history.append({
        "role": "assistant",
        "content": full_response
    })
    
    # (9) 토큰 제한 확인 (선택사항)
    #     컨텍스트 윈도우 초과 방지
    #     gpt-4o-mini는 128K 토큰이므로 대부분 문제 없음
    #     하지만 매우 긴 대화에서는 유의해야 함
    if len(conversation_history) > 20:
        # 20번 이상 대화하면 초기 메시지 제거 (최근 메시지만 유지)
        conversation_history = [conversation_history[0]] + conversation_history[-19:]
        print("[알림] 대화 히스토리 정리 (20번 이상 대화함)")
```

---

### [13:00-13:50] 3교시: OpenAI 심화 (Function Calling)

#### 3.1 Function Calling 개념

**개념:** LLM이 필요에 따라 외부 함수(도구)를 자동으로 선택하고 호출하는 기능입니다.

```
전통 방식:
  사용자 → LLM → 텍스트 응답
  LLM이 할 수 있는 일: 텍스트만 생성

Function Calling 방식:
  사용자 → LLM (도구 선택) → 도구 실행 → LLM (최종 답변)
  LLM이 할 수 있는 일: 도구를 통해 계산, DB 접근, API 호출 등
```

**특징:**
- 구조화된 데이터 추출 가능
- 외부 도구 자동 연계 (날씨 API, 계산기 등)
- 정확한 형식의 응답 보장

**사례:**
- 가격 비교봇: "가장 저렴한 노트북은?" → function_calling → 쇼핑몰 API 호출 → 가격 비교
- 일정 관리봇: "내일 3시에 회의 일정 잡아줘" → function_calling → calendar API 호출 → 일정 등록
- 계산기 봇: "2025의 인수분해는?" → function_calling → 계산 함수 호출 → 답변

**고려사항:**
- Function Calling 실패 가능성 (LLM이 잘못된 함수 선택)
- 함수 정의가 명확해야 함 (LLM이 언제 사용할지 판단)
- 오류 처리 필수 (함수 실행 실패 시 재시도)

---

#### [실습 3] function_calling.py


```python
# ============================================================
# 실습 3: Function Calling 활용 (function_calling.py)
# ============================================================
# [필수 설치]
#   pip install openai python-dotenv
#
# [실행 방법]
#   python function_calling.py
#
# [예상 출력]
#   "숫자 25와 4의 합은?"
#   → LLM이 add_numbers 함수 선택
#   → 함수 실행: 25 + 4 = 29
#   → 최종 응답: "숫자 25와 4의 합은 29입니다."
#
# [주의사항]
#   - 함수 정의(tools)가 정확해야 LLM이 올바르게 선택함
#   - tool_choice="auto": LLM이 자동으로 도구 선택
# ============================================================

from openai import OpenAI
from dotenv import load_dotenv
import json
import os

load_dotenv()
client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

# (1) 실제 함수들을 정의합니다 (LLM이 호출할 함수들)
#     이 함수들은 LLM의 지시에 따라 자동으로 실행됩니다

def add_numbers(a: int, b: int) -> int:
    """두 숫자를 더합니다"""
    return a + b

def multiply_numbers(a: int, b: int) -> int:
    """두 숫자를 곱합니다"""
    return a * b

def get_weather(location: str) -> str:
    """특정 지역의 날씨를 조회합니다 (데모용, 실제 API 아님)"""
    # 실제 구현에서는 날씨 API를 호출합니다
    weather_data = {
        "서울": "맑음, 20도",
        "부산": "흐림, 18도",
        "대구": "비, 15도"
    }
    return weather_data.get(location, "정보 없음")

# (2) OpenAI에 전달할 함수 정의 (JSON 스키마 형식)
#     LLM이 어떤 함수가 있는지, 언제 사용할지 판단하기 위한 메타데이터
tools = [
    {
        "type": "function",
        "function": {
            "name": "add_numbers",          # 함수 이름
            "description": "두 숫자를 더합니다",  # LLM이 읽을 설명
            "parameters": {                 # 함수의 파라미터 정의
                "type": "object",
                "properties": {
                    "a": {
                        "type": "integer",
                        "description": "첫 번째 숫자"
                    },
                    "b": {
                        "type": "integer",
                        "description": "두 번째 숫자"
                    }
                },
                "required": ["a", "b"]      # 필수 파라미터
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "multiply_numbers",
            "description": "두 숫자를 곱합니다",
            "parameters": {
                "type": "object",
                "properties": {
                    "a": {"type": "integer", "description": "첫 번째 숫자"},
                    "b": {"type": "integer", "description": "두 번째 숫자"}
                },
                "required": ["a", "b"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "get_weather",
            "description": "특정 지역의 날씨를 조회합니다",
            "parameters": {
                "type": "object",
                "properties": {
                    "location": {
                        "type": "string",
                        "description": "지역명 (예: 서울, 부산, 대구)"
                    }
                },
                "required": ["location"]
            }
        }
    }
]

# (3) Function Calling API를 호출합니다
#     tools 파라미터: LLM이 사용 가능한 함수 목록
#     tool_choice="auto": LLM이 자동으로 필요한 함수 선택
def process_user_input(user_message: str):
    """사용자 메시지를 처리하고, 필요하면 함수를 호출합니다"""
    
    # (3-1) 첫 번째 API 호출: 사용자 질문 받기
    response = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[
            {
                "role": "user",
                "content": user_message
            }
        ],
        tools=tools,                    # 사용 가능한 함수 목록 전달
        tool_choice="auto",             # LLM이 자동으로 함수 선택
        max_tokens=500
    )
    
    # (3-2) LLM의 응답을 확인합니다
    assistant_message = response.choices[0].message
    
    # (3-3) LLM이 함수 호출을 요청했는지 확인합니다
    #       tool_calls가 있으면 함수 실행 필요
    if assistant_message.tool_calls:
        print(f"사용자: {user_message}")
        
        # (3-4) 모든 tool_calls를 실행합니다
        tool_results = []
        for tool_call in assistant_message.tool_calls:
            tool_name = tool_call.function.name              # 함수 이름
            tool_input = json.loads(tool_call.function.arguments)  # 파라미터 파싱
            
            print(f"→ 함수 호출: {tool_name}({tool_input})")
            
            # (3-5) 파라미터에 맞는 함수를 실행합니다
            if tool_name == "add_numbers":
                result = add_numbers(tool_input["a"], tool_input["b"])
            elif tool_name == "multiply_numbers":
                result = multiply_numbers(tool_input["a"], tool_input["b"])
            elif tool_name == "get_weather":
                result = get_weather(tool_input["location"])
            else:
                result = "Unknown function"
            
            print(f"→ 결과: {result}")
            
            # 결과를 저장합니다 (LLM이 최종 답변 생성할 때 필요)
            tool_results.append({
                "tool_call_id": tool_call.id,
                "output": str(result)
            })
        
        # (3-6) 두 번째 API 호출: 함수 결과를 포함해서 최종 답변 받기
        #       LLM이 함수 결과를 바탕으로 자연스러운 응답 생성
        messages = [
            {"role": "user", "content": user_message},
            assistant_message,  # LLM의 첫 응답 (함수 호출 정보 포함)
        ]
        
        # 함수 결과를 메시지에 추가합니다
        for tool_result in tool_results:
            messages.append({
                "role": "tool",
                "tool_call_id": tool_result["tool_call_id"],
                "content": tool_result["output"]
            })
        
        # 최종 답변을 받습니다
        final_response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=messages,
            max_tokens=500
        )
        
        # 최종 응답 출력
        print(f"어시스턴트: {final_response.choices[0].message.content}\n")
    else:
        # (3-7) LLM이 함수를 호출하지 않은 경우 (일반 텍스트 응답)
        print(f"사용자: {user_message}")
        print(f"어시스턴트: {assistant_message.content}\n")

# (4) 테스트: 다양한 질문으로 Function Calling을 실행합니다
print("=" * 60)
print("Function Calling 데모")
print("=" * 60 + "\n")

# 테스트 케이스들
test_queries = [
    "25와 4의 합은?",              # add_numbers 호출 예상
    "10과 7을 곱하면?",             # multiply_numbers 호출 예상
    "서울의 날씨는?",               # get_weather 호출 예상
    "안녕하세요"                     # 함수 호출 없음 (일반 대화)
]

for query in test_queries:
    process_user_input(query)
```

---

### [14:00-14:50] 4교시: Local LLM과 Ollama

#### 4.1 Local LLM 개념

**개념:** 클라우드 서버가 아닌 사용자 컴퓨터(또는 온프레미스)에서 직접 실행되는 LLM입니다.

**특징:**
- 비용: 0원 (모델은 오픈소스, 컴퓨팅 비용만 본인 부담)
- 개인정보: 외부 서버로 전송 안 함 (완전 프라이빗)
- 속도: 로컬 네트워크 (< 10ms) vs 클라우드 (1~5초)
- 품질: 10B 미만 모델은 전문가용 (gpt-4o 수준 아님)

**사례:**
- 금융회사: 고객 재정 정보를 Ollama로 처리 (OpenAI 전송 X)
- 의료기관: 환자 의료기록 분석 (HIPAA 규제 준수)
- 정부기관: 기밀 문서 분석 (보안 요구사항)
- 스타트업: 비용 절감 (수백만 원 → 0원)

**고려사항:**
- 하드웨어 요구: GPU 필수 (RTX 3060 이상 권장)
- 모델 선택: 7B 미만이 빠름, 13B+ 정확도 더 높음
- 온보딩: 첫 모델 다운로드 시간 (mistral:7b = 4GB, 10분)

#### 4.2 Ollama 아키텍처

```
┌─────────────────────────────────────────┐
│     Ollama 아키텍처 & 작동 방식          │
├─────────────────────────────────────────┤
│                                         │
│  ollama serve (백그라운드 프로세스)      │
│       ↓                                 │
│  localhost:11434 (HTTP API 서버)        │
│       ↓                                 │
│  /api/generate (텍스트 생성)             │
│  /api/chat (대화)                       │
│  /api/embed (임베딩)                    │
│                                         │
│  [모델 파일들]                          │
│  ~/.ollama/models/                      │
│  ├── mistral:7b (4.2GB)                 │
│  ├── llama2:7b (3.8GB)                  │
│  └── orca-mini:3b (1.9GB)               │
│                                         │
└─────────────────────────────────────────┘

CLI 명령어:
ollama pull mistral:7b     # 모델 다운로드
ollama serve               # 백그라운드 실행
ollama run mistral:7b      # 대화 시작
ollama ls                  # 설치된 모델 확인
ollama rm mistral:7b       # 모델 제거
```

#### 4.3 OpenAI SDK로 Ollama 호출하기

**핵심:** Ollama는 OpenAI API와 호환 가능합니다!

```python
# OpenAI SDK 사용 (변경사항 최소)
from openai import OpenAI

client = OpenAI(
    api_key="ollama",                          # 더미 값 (필요 없음)
    base_url="http://localhost:11434/v1"       # Ollama 서버 주소
)

response = client.chat.completions.create(
    model="mistral:7b",                        # Ollama 모델명
    messages=[{"role": "user", "content": "..."}]
)
# OpenAI 방식과 완전히 동일!
```

---

#### [실습 4] ollama_basic.py


```python
# ============================================================
# 실습 4: Ollama 기초 (ollama_basic.py)
# ============================================================
# [필수 설치]
#   pip install openai python-dotenv
#   (Ollama 앱 별도 설치: https://ollama.ai)
#
# [사전 준비]
#   - 별도 CMD 창에서 'ollama serve' 실행 중
#   - 모델 다운로드: 'ollama pull mistral:7b'
#
# [실행 방법]
#   python ollama_basic.py
#
# [예상 출력]
#   Ollama 모델: mistral:7b
#   질문: "Python이란?"
#   응답: "Python은 프로그래밍 언어입니다..." (2~10초 소요)
#
# [주의사항]
#   - Ollama 서버가 실행 중이어야 함 (11434 포트)
#   - 첫 실행은 모델 로드로 느림 (10~30초)
#   - GPU 있으면 5배 빠름 (CPU: 2~10초, GPU: 0.5~2초)
# ============================================================

from openai import OpenAI
from dotenv import load_dotenv
import time

load_dotenv()

# (1) Ollama 클라이언트를 생성합니다 (OpenAI SDK 사용)
#     주의: api_key는 "ollama" 더미값 사용 (실제 필요 없음)
#     base_url: Ollama 서버 주소 (기본 localhost:11434)
client = OpenAI(
    api_key="ollama",                    # 더미 값 (Ollama는 API 키 불필요)
    base_url="http://localhost:11434/v1" # Ollama의 OpenAI 호환 엔드포인트
)

# (2) 사용할 모델 선택
#     mistral:7b: 가장 인기 있는 소형 모델, 빠르고 정확
#     다른 옵션: llama2:7b, neural-chat:7b, orca-mini:3b
model_name = "mistral:7b"

print("=" * 60)
print("Ollama 기초 - Local LLM 사용하기")
print("=" * 60)
print(f"모델: {model_name}")
print(f"주소: http://localhost:11434")
print("=" * 60 + "\n")

# (3) 테스트 질문들을 정의합니다
test_questions = [
    "Python이란 무엇인가요?",
    "AI와 Machine Learning의 차이는?",
    "좋은 코드의 특징은?"
]

# (4) 각 질문에 대해 Ollama로 응답을 받습니다
for i, question in enumerate(test_questions, 1):
    print(f"[질문 {i}] {question}")
    
    # (5) Ollama API 호출 (OpenAI SDK와 동일한 방식)
    #     temperature: 창의성 (낮을수록 정확, 높을수록 창의적)
    #     max_tokens: 최대 응답 길이
    start_time = time.time()  # 응답 시간 측정용
    
    try:
        response = client.chat.completions.create(
            model=model_name,                    # Ollama 모델명
            messages=[
                {
                    "role": "user",
                    "content": question
                }
            ],
            temperature=0.7,                     # 중간 정도의 창의성
            max_tokens=300,                      # 300 토큰 이하로 제한
            # stream=False가 기본값이므로 전체 응답을 한 번에 받음
        )
        
        elapsed_time = time.time() - start_time  # 응답 시간 계산
        
        # (6) 응답을 추출하고 출력합니다
        answer = response.choices[0].message.content
        print(f"[응답 ({elapsed_time:.2f}초)]")
        print(f"{answer}\n")
        
    except Exception as e:
        # (7) 오류 처리
        print(f"[오류] {e}")
        print("Ollama 서버가 실행 중인지 확인하세요.")
        print("CMD에서 'ollama serve' 입력\n")

# (8) 스트리밍 예제 (선택사항)
print("=" * 60)
print("스트리밍 응답 예제")
print("=" * 60)

streaming_question = "Python 리스트와 딕셔너리의 차이를 설명해주세요."
print(f"질문: {streaming_question}\n")

try:
    # (9) stream=True로 설정하면 청크 단위로 응답 받음
    stream = client.chat.completions.create(
        model=model_name,
        messages=[{"role": "user", "content": streaming_question}],
        temperature=0.7,
        max_tokens=300,
        stream=True  # ★ 스트리밍 활성화
    )
    
    # (10) 청크를 하나씩 처리합니다 (실시간 출력)
    print("응답: ", end="", flush=True)
    for chunk in stream:
        if chunk.choices[0].delta.content:
            # delta.content는 이 청크의 텍스트 조각
            print(chunk.choices[0].delta.content, end="", flush=True)
    print("\n")
    
except Exception as e:
    print(f"[오류] {e}\n")

print("=" * 60)
print("Ollama 기초 테스트 완료")
print("=" * 60)
```

---

### [15:00-15:50] 5교시: SQLite 기초와 LLM 캐시 설계

#### 5.1 SQLite 개념

**개념:** 파일 기반 관계형 데이터베이스입니다. 서버 설치 불필요, 학습용/소형 서비스에 적합합니다.

**특징:**
- 설치 불필요: Python 내장 모듈 (sqlite3)
- 파일 저장: 모든 데이터가 한 파일에 (.db 파일)
- 트랜잭션 지원: ACID 보장 (데이터 무결성)
- SQL 표준: 다른 DB와 거의 같은 문법

**사례:**
- SQLite: iOS, Android의 기본 DB
- 개발 환경: Django, Flask 기본 DB
- 임베디드 시스템: IoT 기기의 로컬 저장소

**고려사항:**
- 동시 접근 제한: 대규모 멀티유저는 부적합
- 크기 제한: 파일 크기 최대 281TB (실무는 보통 < 100GB)
- 쿼리 성능: 적절한 인덱싱 필수

#### 5.2 LLM 캐시 테이블 설계

```sql
-- LLM 응답 캐시 테이블 스키마
CREATE TABLE IF NOT EXISTS llm_cache (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    cache_key TEXT UNIQUE NOT NULL,      -- SHA256 해시 (정확 매칭용)
    query TEXT NOT NULL,                  -- 원본 질문
    response TEXT NOT NULL,               -- LLM 응답
    model TEXT,                           -- 사용한 모델 (gpt-4o-mini 등)
    provider TEXT,                        -- 프로바이더 (openai, ollama 등)
    embedding TEXT,                       -- 임베딩 벡터 (JSON 배열, 의미 매칭용)
    tokens INTEGER DEFAULT 0,            -- 사용한 토큰 수
    cost REAL DEFAULT 0.0,               -- 비용 (달러)
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,  -- 캐시 생성 시간
    expires_at TIMESTAMP,                -- TTL 만료 시간
    hit_count INTEGER DEFAULT 0          -- 몇 번 재사용되었나
);

-- 조회 성능을 위한 인덱스
CREATE INDEX idx_cache_key ON llm_cache(cache_key);
CREATE INDEX idx_expires_at ON llm_cache(expires_at);
```

**각 컬럼 설명:**

| 컬럼 | 타입 | 설명 | 예시 |
|------|------|------|------|
| id | INTEGER | 자동 증가 ID | 1, 2, 3... |
| cache_key | TEXT | SHA256 해시 (검색 키) | "a1b2c3..." |
| query | TEXT | 원본 질문 | "Python이란?" |
| response | TEXT | LLM 응답 | "Python은..." |
| model | TEXT | 사용 모델 | "gpt-4o-mini" |
| provider | TEXT | 프로바이더 | "openai" |
| embedding | TEXT | 의미 벡터 | "[0.1, 0.2...]" |
| tokens | INTEGER | 토큰 수 | 150 |
| cost | REAL | 비용 | 0.00045 |
| created_at | TIMESTAMP | 생성 시간 | 2025-03-21... |
| expires_at | TIMESTAMP | 만료 시간 | 2025-03-28... |
| hit_count | INTEGER | 재사용 횟수 | 5 |

---

#### [실습 5] sqlite_cache.py


```python
# ============================================================
# 실습 5: SQLite 캐시 기초 (sqlite_cache.py)
# ============================================================
# [필수 설치]
#   pip install openai python-dotenv
#   (sqlite3는 Python 내장 모듈)
#
# [실행 방법]
#   python sqlite_cache.py
#
# [예상 출력]
#   캐시 테이블 생성 완료
#   캐시 저장: "Python이란?" → ID 1
#   캐시 조회: "Python이란?" → 찾음! (hit_count: 2)
#   
# [주의사항]
#   - 데이터베이스 파일 (cache.db) 자동 생성
#   - TTL 체크: 7일 후 자동 만료
# ============================================================

import sqlite3
import hashlib
from datetime import datetime, timedelta
from typing import Optional, Dict, Any

class SimpleSQLiteCache:
    """
    간단한 SQLite 기반 LLM 응답 캐시 클래스
    
    기능:
    1. Exact Match 캐시: SHA256 해시로 정확한 질문 매칭
    2. TTL 관리: 지정된 기간 후 자동 만료
    3. 히트 통계: 캐시 재사용 횟수 추적
    """
    
    def __init__(self, db_path: str = "cache.db"):
        """
        SQLite 캐시 초기화
        
        Args:
            db_path: 데이터베이스 파일 경로
        """
        self.db_path = db_path
        self._initialize_db()
    
    def _initialize_db(self):
        """
        데이터베이스와 캐시 테이블을 초기화합니다
        """
        # (1) 데이터베이스 연결
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # (2) 캐시 테이블 생성 (없으면 생성, 있으면 유지)
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS llm_cache (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                cache_key TEXT UNIQUE NOT NULL,
                query TEXT NOT NULL,
                response TEXT NOT NULL,
                model TEXT,
                provider TEXT,
                tokens INTEGER DEFAULT 0,
                cost REAL DEFAULT 0.0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                expires_at TIMESTAMP,
                hit_count INTEGER DEFAULT 0
            )
        """)
        
        # (3) 조회 성능을 위한 인덱스 생성
        cursor.execute("""
            CREATE INDEX IF NOT EXISTS idx_cache_key 
            ON llm_cache(cache_key)
        """)
        cursor.execute("""
            CREATE INDEX IF NOT EXISTS idx_expires_at 
            ON llm_cache(expires_at)
        """)
        
        # (4) 변경사항 저장 및 연결 종료
        conn.commit()
        conn.close()
        
        print(f"[초기화] 캐시 테이블 준비 완료 (DB: {self.db_path})")
    
    def _get_cache_key(self, query: str) -> str:
        """
        질문을 SHA256 해시로 변환합니다 (캐시 키로 사용)
        
        Args:
            query: 원본 질문
            
        Returns:
            SHA256 해시값 (16진수 문자열)
        """
        # (1) 질문을 정규화합니다 (공백 정리, 소문자 변환)
        normalized = query.strip().lower()
        
        # (2) SHA256 해시 계산
        hash_obj = hashlib.sha256(normalized.encode('utf-8'))
        cache_key = hash_obj.hexdigest()
        
        return cache_key
    
    def save_response(
        self,
        query: str,
        response: str,
        model: str = "unknown",
        provider: str = "unknown",
        tokens: int = 0,
        cost: float = 0.0,
        ttl_days: int = 7
    ) -> int:
        """
        LLM 응답을 캐시에 저장합니다
        
        Args:
            query: 원본 질문
            response: LLM 응답
            model: 사용한 모델명
            provider: 프로바이더명
            tokens: 사용한 토큰 수
            cost: 비용 (달러)
            ttl_days: 캐시 유효 기간 (기본 7일)
            
        Returns:
            저장된 캐시 ID
        """
        # (1) 캐시 키 생성
        cache_key = self._get_cache_key(query)
        
        # (2) TTL 계산 (현재 시간 + ttl_days)
        expires_at = datetime.now() + timedelta(days=ttl_days)
        
        # (3) 데이터베이스 연결
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        try:
            # (4) 캐시 데이터 삽입
            cursor.execute("""
                INSERT INTO llm_cache 
                (cache_key, query, response, model, provider, tokens, cost, expires_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """, (cache_key, query, response, model, provider, tokens, cost, expires_at))
            
            # (5) 변경사항 저장
            conn.commit()
            
            # (6) 삽입된 행의 ID 가져오기
            cache_id = cursor.lastrowid
            
            print(f"[저장] 캐시 #{cache_id}: '{query[:30]}...' ({ttl_days}일 유효)")
            return cache_id
            
        except sqlite3.IntegrityError:
            # (7) 중복 캐시 키 (이미 같은 질문이 있음)
            print(f"[중복] 동일한 질문이 이미 캐시됨: '{query[:30]}...'")
            return -1
        
        finally:
            conn.close()
    
    def get_response(self, query: str) -> Optional[Dict[str, Any]]:
        """
        캐시에서 응답을 조회합니다
        
        Args:
            query: 조회할 질문
            
        Returns:
            캐시된 데이터 딕셔너리, 없으면 None
        """
        # (1) 캐시 키 생성
        cache_key = self._get_cache_key(query)
        
        # (2) 데이터베이스 연결
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # (3) 캐시 조회 (TTL 체크 포함)
        #     expires_at이 현재 시간보다 미래여야 함
        cursor.execute("""
            SELECT id, response, model, provider, tokens, cost, hit_count, created_at
            FROM llm_cache
            WHERE cache_key = ? AND (expires_at IS NULL OR expires_at > datetime('now'))
        """, (cache_key,))
        
        result = cursor.fetchone()
        
        if result:
            # (4) 캐시 히트: hit_count 증가
            cache_id = result[0]
            
            cursor.execute("""
                UPDATE llm_cache
                SET hit_count = hit_count + 1
                WHERE id = ?
            """, (cache_id,))
            
            conn.commit()
            
            # (5) 결과를 딕셔너리로 변환
            cache_data = {
                'id': result[0],
                'response': result[1],
                'model': result[2],
                'provider': result[3],
                'tokens': result[4],
                'cost': result[5],
                'hit_count': result[6] + 1,  # 업데이트된 값
                'created_at': result[7]
            }
            
            print(f"[캐시 히트] '{query[:30]}...' (히트: {cache_data['hit_count']}회)")
            conn.close()
            return cache_data
        else:
            # (6) 캐시 미스
            print(f"[캐시 미스] '{query[:30]}...' (새로 조회 필요)")
            conn.close()
            return None
    
    def clear_expired(self) -> int:
        """
        만료된 캐시를 삭제합니다
        
        Returns:
            삭제된 행의 수
        """
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # (1) expires_at이 지난 캐시 삭제
        cursor.execute("""
            DELETE FROM llm_cache
            WHERE expires_at IS NOT NULL AND expires_at <= datetime('now')
        """)
        
        # (2) 삭제된 행의 수
        deleted_count = cursor.rowcount
        
        conn.commit()
        conn.close()
        
        if deleted_count > 0:
            print(f"[정리] 만료된 캐시 {deleted_count}개 삭제")
        
        return deleted_count
    
    def get_stats(self) -> Dict[str, Any]:
        """
        캐시 통계를 반환합니다
        
        Returns:
            통계 딕셔너리
        """
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # (1) 전체 캐시 수
        cursor.execute("SELECT COUNT(*) FROM llm_cache")
        total_cache = cursor.fetchone()[0]
        
        # (2) 유효한 캐시 수 (만료 전)
        cursor.execute("""
            SELECT COUNT(*) FROM llm_cache
            WHERE expires_at IS NULL OR expires_at > datetime('now')
        """)
        valid_cache = cursor.fetchone()[0]
        
        # (3) 총 히트 수
        cursor.execute("SELECT SUM(hit_count) FROM llm_cache")
        total_hits = cursor.fetchone()[0] or 0
        
        # (4) 총 비용 절감
        cursor.execute("SELECT SUM(cost) FROM llm_cache")
        total_cost_saved = cursor.fetchone()[0] or 0.0
        
        conn.close()
        
        return {
            'total_cache': total_cache,
            'valid_cache': valid_cache,
            'total_hits': total_hits,
            'total_cost_saved': total_cost_saved
        }


# ========== 테스트 ==========
if __name__ == "__main__":
    print("=" * 60)
    print("SQLite 캐시 테스트")
    print("=" * 60 + "\n")
    
    # (1) 캐시 객체 생성
    cache = SimpleSQLiteCache(db_path="cache.db")
    
    # (2) 첫 번째 응답 저장
    cache.save_response(
        query="Python이란?",
        response="Python은 고급 프로그래밍 언어입니다.",
        model="gpt-4o-mini",
        provider="openai",
        tokens=50,
        cost=0.000075,
        ttl_days=7
    )
    
    # (3) 두 번째 응답 저장
    cache.save_response(
        query="AI란 무엇인가?",
        response="AI는 인공지능(Artificial Intelligence)을 의미합니다.",
        model="gpt-4o-mini",
        provider="openai",
        tokens=45,
        cost=0.000068,
        ttl_days=7
    )
    
    print()
    
    # (4) 캐시에서 응답 조회 (캐시 히트)
    result1 = cache.get_response("Python이란?")
    if result1:
        print(f"  응답: {result1['response']}\n")
    
    # (5) 다시 조회 (히트 카운트 증가)
    result2 = cache.get_response("Python이란?")
    if result2:
        print(f"  응답: {result2['response']}\n")
    
    # (6) 캐시에 없는 질문 (캐시 미스)
    result3 = cache.get_response("JavaScript란?")
    if not result3:
        print("  → 캐시에 없습니다. OpenAI로 조회해야 함\n")
    
    # (7) 통계 출력
    stats = cache.get_stats()
    print("=" * 60)
    print("캐시 통계")
    print("=" * 60)
    print(f"총 캐시: {stats['total_cache']}개")
    print(f"유효한 캐시: {stats['valid_cache']}개")
    print(f"총 히트: {stats['total_hits']}회")
    print(f"절감된 비용: ${stats['total_cost_saved']:.6f}")
    print("=" * 60)
```

---

### [16:00-16:50] 6교시: 통합 LLM 클라이언트

#### 6.1 UnifiedLLMClient 개념

**개념:** OpenAI와 Ollama를 동일한 인터페이스로 사용할 수 있는 래퍼 클래스입니다.

```python
# 전통 방식 (프로바이더별로 다른 코드)
if use_openai:
    from openai import OpenAI
    client_openai = OpenAI(api_key="...")
    response = client_openai.chat.completions.create(...)
else:
    from openai import OpenAI
    client_ollama = OpenAI(base_url="http://localhost:11434/v1")
    response = client_ollama.chat.completions.create(...)

# Unified 방식 (단일 코드)
unified_client = UnifiedLLMClient()
response = unified_client.chat("Python?", model="gpt-4o-mini")
response = unified_client.chat("Python?", model="mistral:7b")
# → 동일한 인터페이스, 다른 프로바이더 투명하게 전환
```

**장점:**
- 코드 중복 제거
- 프로바이더 전환 용이
- 테스트 시 Ollama로 빠르게 테스트 후 OpenAI로 배포
- Hybrid 라우팅 기초 모듈

---

#### [실습 6] unified_client.py


```python
# ============================================================
# 실습 6: 통합 LLM 클라이언트 (unified_client.py)
# ============================================================
# [필수 설치]
#   pip install openai python-dotenv
#
# [사전 준비]
#   - .env 파일에 OPENAI_API_KEY 설정
#   - Ollama 서버 실행 (선택사항, ollama로만 테스트 가능)
#
# [실행 방법]
#   python unified_client.py
#
# [예상 출력]
#   OpenAI 호출: "Python은..." (응답)
#   Ollama 호출: "Python is..." (응답)
#
# [특징]
#   - OpenAI와 Ollama를 동일 인터페이스로 사용
#   - 프로바이더 자동 감지 (모델명으로)
#   - 스트리밍 지원
# ============================================================

from openai import OpenAI
from dotenv import load_dotenv
import os
from typing import Optional, List, Dict, Any

class UnifiedLLMClient:
    """
    OpenAI와 Ollama를 통일된 인터페이스로 제공하는 클래스
    
    사용법:
        client = UnifiedLLMClient()
        response = client.chat("질문", model="gpt-4o-mini")  # OpenAI
        response = client.chat("질문", model="mistral:7b")   # Ollama
    """
    
    def __init__(self):
        """
        통합 클라이언트를 초기화합니다
        """
        # (1) 환경변수 로드
        load_dotenv()
        
        # (2) OpenAI 클라이언트 생성
        self.openai_client = OpenAI(
            api_key=os.getenv("OPENAI_API_KEY")
        )
        
        # (3) Ollama 클라이언트 생성 (OpenAI SDK 호환 모드)
        self.ollama_client = OpenAI(
            api_key="ollama",  # 더미 값
            base_url="http://localhost:11434/v1"
        )
        
        # (4) 모델 정보 저장
        self.openai_models = [
            "gpt-4o",
            "gpt-4o-mini",
            "gpt-4-turbo",
            "gpt-3.5-turbo"
        ]
        
        self.ollama_models = [
            "mistral:7b",
            "llama2:7b",
            "neural-chat:7b",
            "orca-mini:3b",
            "vicuna:13b"
        ]
    
    def _detect_provider(self, model: str) -> str:
        """
        모델명으로 프로바이더를 자동 감지합니다
        
        Args:
            model: 모델명
            
        Returns:
            "openai" 또는 "ollama"
        """
        # (1) 모델명이 OpenAI 목록에 있으면 openai
        if any(m in model for m in self.openai_models):
            return "openai"
        
        # (2) 그 외는 ollama (Ollama는 "모델:태그" 형식)
        return "ollama"
    
    def chat(
        self,
        message: str,
        model: str = "gpt-4o-mini",
        temperature: float = 0.7,
        max_tokens: int = 500,
        stream: bool = False
    ) -> str:
        """
        질문에 대한 답변을 받습니다
        
        Args:
            message: 사용자 질문
            model: 사용할 모델
            temperature: 창의성 (0~2)
            max_tokens: 최대 응답 길이
            stream: 스트리밍 여부
            
        Returns:
            모델의 응답 텍스트
        """
        # (1) 프로바이더 자동 감지
        provider = self._detect_provider(model)
        
        # (2) 해당 클라이언트 선택
        if provider == "openai":
            client = self.openai_client
        else:
            client = self.ollama_client
        
        # (3) 프로바이더별로 API 호출
        try:
            if stream:
                # (4) 스트리밍 모드
                stream_response = client.chat.completions.create(
                    model=model,
                    messages=[{"role": "user", "content": message}],
                    temperature=temperature,
                    max_tokens=max_tokens,
                    stream=True
                )
                
                # (5) 청크를 모아서 전체 응답 생성
                full_response = ""
                for chunk in stream_response:
                    if chunk.choices[0].delta.content:
                        full_response += chunk.choices[0].delta.content
                
                return full_response
            else:
                # (6) 일반 모드 (전체 응답 한 번에)
                response = client.chat.completions.create(
                    model=model,
                    messages=[{"role": "user", "content": message}],
                    temperature=temperature,
                    max_tokens=max_tokens,
                    stream=False
                )
                
                return response.choices[0].message.content
        
        except Exception as e:
            # (7) 오류 처리
            return f"오류 발생: {str(e)}"
    
    def chat_with_history(
        self,
        messages: List[Dict[str, str]],
        model: str = "gpt-4o-mini",
        temperature: float = 0.7,
        max_tokens: int = 500
    ) -> str:
        """
        대화 히스토리를 포함한 응답을 받습니다
        
        Args:
            messages: 메시지 리스트
                [{"role": "user", "content": "..."},
                 {"role": "assistant", "content": "..."},
                 ...]
            model: 사용할 모델
            temperature: 창의성
            max_tokens: 최대 길이
            
        Returns:
            모델의 응답
        """
        # (1) 프로바이더 감지
        provider = self._detect_provider(model)
        
        # (2) 클라이언트 선택
        if provider == "openai":
            client = self.openai_client
        else:
            client = self.ollama_client
        
        # (3) API 호출 (히스토리 포함)
        try:
            response = client.chat.completions.create(
                model=model,
                messages=messages,
                temperature=temperature,
                max_tokens=max_tokens
            )
            
            return response.choices[0].message.content
        
        except Exception as e:
            return f"오류 발생: {str(e)}"
    
    def get_token_count_estimate(self, text: str) -> int:
        """
        텍스트의 대략적인 토큰 수를 추정합니다
        
        Args:
            text: 텍스트
            
        Returns:
            추정 토큰 수
        """
        # (1) 간단한 추정 (정확하지 않음)
        #     일반적으로: 4글자 ≈ 1 토큰
        #     한국어: 2~3글자 ≈ 1 토큰 (더 많음)
        
        # (2) 한국어와 영어 구분
        korean_count = sum(1 for c in text if ord(c) >= 0xAC00)
        english_count = len(text) - korean_count
        
        # (3) 추정
        korean_tokens = korean_count // 2  # 보수적 추정
        english_tokens = english_count // 4
        
        return korean_tokens + english_tokens


# ========== 테스트 ==========
if __name__ == "__main__":
    print("=" * 60)
    print("UnifiedLLMClient 테스트")
    print("=" * 60 + "\n")
    
    # (1) 클라이언트 생성
    client = UnifiedLLMClient()
    
    # (2) OpenAI로 테스트
    print("[OpenAI 호출]")
    print("질문: Python이란?")
    response_openai = client.chat(
        "Python이란 무엇인가요? 3줄로 요약해주세요.",
        model="gpt-4o-mini",
        max_tokens=200
    )
    print(f"응답: {response_openai[:100]}...\n")
    
    # (3) Ollama로 테스트 (선택사항)
    try:
        print("[Ollama 호출]")
        print("질문: Python이란?")
        response_ollama = client.chat(
            "Python이란 무엇인가요? 3줄로 요약해주세요.",
            model="mistral:7b",
            max_tokens=200
        )
        print(f"응답: {response_ollama[:100]}...\n")
    except Exception as e:
        print(f"[Ollama 오류] {e} (Ollama 서버 미실행)\n")
    
    # (4) 토큰 수 추정
    text = "Python은 프로그래밍 언어입니다. AI를 배우기에 좋습니다."
    tokens = client.get_token_count_estimate(text)
    print(f"토큰 수 추정: '{text}'")
    print(f"추정 토큰: {tokens}\n")
    
    # (5) 대화 히스토리 테스트
    print("[대화 히스토리 테스트]")
    history = [
        {"role": "user", "content": "Python 배우기 시작했어요"},
        {"role": "assistant", "content": "좋습니다! Python은 배우기 쉬운 언어입니다."},
        {"role": "user", "content": "추천 자료가 있나요?"}
    ]
    
    response = client.chat_with_history(
        history,
        model="gpt-4o-mini",
        max_tokens=200
    )
    print(f"응답: {response}\n")
    
    print("=" * 60)
```

---

## 2일차 강의 자료

### [09:00-09:50] 7교시: Hybrid 전략 이론

#### 7.1 Provider Hybrid (OpenAI ↔ Ollama)

**개념:** 질문 특성에 따라 OpenAI와 Ollama를 자동으로 선택합니다.

**라우팅 전략:**

```
┌─────────────────────────────────────────┐
│ 질문 분석                               │
├─────────────────────────────────────────┤
│                                         │
│ 1. PII 감지 (개인정보 포함?)            │
│    → YES: Ollama (로컬)                 │
│    → NO: 다음 단계                      │
│                                         │
│ 2. 질문 복잡도 분류                     │
│    → 간단: gpt-4o-mini (비용 최소)     │
│    → 복잡: gpt-4o (정확도 최대)        │
│                                         │
│ 3. 캐시 확인                            │
│    → HIT: DB에서 즉시 응답              │
│    → MISS: API 호출                     │
│                                         │
└─────────────────────────────────────────┘
```

**특징:**
- 개인정보 보호: 민감 정보는 로컬 Ollama 처리
- 비용 절감: 간단한 질문은 gpt-4o-mini 사용
- 속도 향상: 캐시 히트 시 < 10ms 응답

**사례:**
- 의료 챗봇: 환자 이름/나이 포함 질문 → Ollama
- 금융 상담: 계좌번호 포함 질문 → Ollama
- 일반 Q&A: 캐시되지 않은 새 질문 → OpenAI

**고려사항:**
- PII 감지 정확도: 정규식으로 구현하면 오탐 가능
- Ollama 응답 품질: 전문 분야에선 정확도 낮음
- Fallback 전략: Ollama 실패 시 OpenAI로 재시도

#### 7.2 Model Tiering (gpt-4o-mini ↔ gpt-4o)

**개념:** 질문의 복잡도를 자동 분류해서 적절한 모델을 선택합니다.

```
┌────────────────────────────────┐
│ 복잡도 분류                    │
├────────────────────────────────┤
│ 복잡도 점수 계산               │
│ ├─ 글자 수 (길수록 복잡)       │
│ ├─ 키워드 분석 (전문용어 많음) │
│ ├─ 수학/코드 포함 (복잡)       │
│ └─ 역사적 질문 (간단)         │
│                               │
│ 점수 < 40: gpt-4o-mini ($0.6) │
│ 점수 >= 40: gpt-4o ($15)       │
└────────────────────────────────┘
```

**특징:**
- 자동 분류: 복잡도 점수 계산
- 비용 효율: 간단한 질문 25배 저렴
- 응답 품질: 복잡한 질문은 최고급 모델

**고려사항:**
- 분류 오류 가능: 복잡도 계산이 부정확할 수 있음
- 사용자 만족도: 간단한 질문도 gpt-4o로 답하면 더 만족도 높음
- 비용 vs 품질 트레이드오프

#### 7.3 Cache Layer (정확매칭 + 의미매칭)

**개념:** 동일하거나 유사한 과거 질문을 검색해서 즉시 응답합니다.

```
┌──────────────────────────────┐
│ 캐시 조회 순서               │
├──────────────────────────────┤
│ 1단계: Exact Match            │
│   SHA256("정규화된 질문")    │
│   조회 시간: < 1ms            │
│   정확도: 100%                │
│                              │
│ 2단계: Semantic Match         │
│   임베딩 벡터 계산            │
│   코사인 유사도 > 0.95        │
│   조회 시간: < 10ms           │
│   정확도: 95%                 │
│                              │
│ 3단계: Miss                   │
│   API 호출                    │
│   조회 시간: 1~5초            │
│                              │
└──────────────────────────────┘
```

**특징:**
- Exact Match: 정확히 동일한 질문만 매칭 (100% 안전)
- Semantic Match: 의미가 유사한 질문도 매칭 (95% 신뢰도)
- TTL 관리: 일주일 후 자동 만료

**고려사항:**
- 의미매칭 정확도: 임베딩 모델 선택이 중요
- 캐시 메모리: 벡터 저장으로 DB 크기 증가
- 개인정보 보존: 캐시에 민감 정보 저장 금지

---

### [10:00-10:50] 8교시: Provider Router 구현

#### [실습 7] provider_router.py


```python
# ============================================================
# 실습 7: Provider Router (provider_router.py)
# ============================================================
# [필수 설치]
#   pip install openai python-dotenv
#
# [사전 준비]
#   - .env 파일 설정
#   - Ollama 서버 실행
#   - unified_client.py와 같은 폴더
#
# [실행 방법]
#   python provider_router.py
#
# [예상 출력]
#   질문: "홍길동의 나이는?"
#   → PII 감지됨! Ollama로 처리
#   
#   질문: "Python이란?"
#   → PII 없음. OpenAI로 처리
#
# [기능]
#   - PII(개인정보) 자동 감지
#   - OpenAI/Ollama 자동 라우팅
#   - Fallback: Ollama 실패 시 OpenAI로 재시도
# ============================================================

import re
from unified_client import UnifiedLLMClient

class ProviderRouter:
    """
    PII 감지 기반 Provider Routing
    
    기능:
    1. PII 감지: 개인정보 포함 여부 판단
    2. Provider 선택: PII 있으면 Ollama, 없으면 OpenAI
    3. Fallback: Ollama 실패 시 OpenAI로 재시도
    """
    
    def __init__(self):
        """
        라우터를 초기화합니다
        """
        # (1) 통합 클라이언트 생성
        self.client = UnifiedLLMClient()
        
        # (2) PII 패턴 정의 (정규식)
        #     실무에서는 더 정교한 모델 (named entity recognition) 사용
        self.pii_patterns = {
            # 한국 주민등록번호 (XXXXXX-XXXXXXX)
            'korean_ssn': r'\d{6}-\d{7}',
            
            # 이메일 주소
            'email': r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}',
            
            # 휴대폰 번호 (010-1234-5678)
            'phone': r'\d{2,3}-\d{3,4}-\d{4}',
            
            # 신용카드 번호 (XXXX-XXXX-XXXX-XXXX)
            'credit_card': r'\d{4}[-\s]?\d{4}[-\s]?\d{4}[-\s]?\d{4}',
            
            # 이름 패턴 (홍길동, 김철수 등 - 한글 3글자)
            'korean_name': r'[가-힣]{2,4}(?:은|는|이|가|을|를|에게|와|과|의)',
            
            # 계좌번호 패턴
            'account': r'\d{3,4}-\d{6,8}-\d{5}',
        }
    
    def detect_pii(self, text: str) -> tuple[bool, list[str]]:
        """
        텍스트에 PII가 포함되어 있는지 감지합니다
        
        Args:
            text: 검사할 텍스트
            
        Returns:
            (PII 있는지 여부, 감지된 PII 타입 리스트)
        """
        # (1) 감지된 PII 타입을 저장할 리스트
        detected_types = []
        
        # (2) 각 PII 패턴을 텍스트와 매칭
        for pii_type, pattern in self.pii_patterns.items():
            if re.search(pattern, text):
                # (3) PII 발견
                detected_types.append(pii_type)
        
        # (4) PII가 하나라도 있으면 True
        has_pii = len(detected_types) > 0
        
        return has_pii, detected_types
    
    def route_and_respond(
        self,
        query: str,
        temperature: float = 0.7,
        max_tokens: int = 500
    ) -> dict:
        """
        질문을 분석하고 적절한 프로바이더로 라우팅합니다
        
        Args:
            query: 사용자 질문
            temperature: 창의성
            max_tokens: 최대 응답 길이
            
        Returns:
            {
                'query': 원본 질문,
                'has_pii': PII 포함 여부,
                'pii_types': 감지된 PII 타입,
                'provider': 사용한 프로바이더,
                'model': 사용한 모델,
                'response': LLM 응답
            }
        """
        
        # (1) PII 감지
        has_pii, pii_types = self.detect_pii(query)
        
        # (2) PII에 따라 프로바이더 결정
        if has_pii:
            # (3) PII 있음 → Ollama 사용 (로컬, 비용 0)
            primary_model = "mistral:7b"
            primary_provider = "ollama"
            fallback_model = "gpt-4o-mini"
            fallback_provider = "openai"
        else:
            # (4) PII 없음 → OpenAI 사용 (빠르고 정확)
            primary_model = "gpt-4o-mini"
            primary_provider = "openai"
            fallback_model = "mistral:7b"
            fallback_provider = "ollama"
        
        # (5) 첫 번째 시도: 주 프로바이더로 호출
        try:
            response = self.client.chat(
                message=query,
                model=primary_model,
                temperature=temperature,
                max_tokens=max_tokens
            )
            
            # (6) 성공
            return {
                'query': query,
                'has_pii': has_pii,
                'pii_types': pii_types,
                'provider': primary_provider,
                'model': primary_model,
                'response': response,
                'fallback_used': False
            }
        
        except Exception as e:
            # (7) 주 프로바이더 실패 → Fallback으로 재시도
            print(f"[주 프로바이더 실패] {primary_provider}: {str(e)}")
            print(f"[Fallback 시도] {fallback_provider}로 전환...")
            
            try:
                response = self.client.chat(
                    message=query,
                    model=fallback_model,
                    temperature=temperature,
                    max_tokens=max_tokens
                )
                
                # (8) Fallback 성공
                return {
                    'query': query,
                    'has_pii': has_pii,
                    'pii_types': pii_types,
                    'provider': fallback_provider,
                    'model': fallback_model,
                    'response': response,
                    'fallback_used': True
                }
            
            except Exception as e2:
                # (9) Fallback도 실패
                return {
                    'query': query,
                    'has_pii': has_pii,
                    'pii_types': pii_types,
                    'provider': 'ERROR',
                    'model': 'N/A',
                    'response': f"양쪽 프로바이더 모두 실패: {str(e2)}",
                    'fallback_used': True
                }


# ========== 테스트 ==========
if __name__ == "__main__":
    print("=" * 60)
    print("Provider Router 테스트")
    print("=" * 60 + "\n")
    
    # (1) 라우터 생성
    router = ProviderRouter()
    
    # (2) 테스트 질문들
    test_queries = [
        # PII 없는 질문 (OpenAI로 처리)
        "Python이란 무엇인가요?",
        
        # 이메일 포함 (Ollama로 처리)
        "user@example.com의 계정 정보는?",
        
        # 이름 포함 (Ollama로 처리)
        "홍길동은 어디에 사나요?",
        
        # 휴대폰 번호 포함 (Ollama로 처리)
        "010-1234-5678의 주인은?",
    ]
    
    # (3) 각 질문을 라우팅
    for query in test_queries:
        print(f"[질문] {query}")
        
        # PII 먼저 감지
        has_pii, pii_types = router.detect_pii(query)
        print(f"  PII 감지: {has_pii}")
        if pii_types:
            print(f"  타입: {', '.join(pii_types)}")
        
        # 라우팅 및 응답
        result = router.route_and_respond(query, max_tokens=200)
        
        print(f"  프로바이더: {result['provider']}")
        print(f"  모델: {result['model']}")
        if result['fallback_used']:
            print(f"  [⚠️ Fallback 사용됨]")
        print(f"  응답: {result['response'][:100]}...")
        print()
```

---

### [11:00-11:50] 9교시: Model Tiering Router

#### [실습 8] model_tiering.py

```python
# ============================================================
# 실습 8: Model Tiering Router (model_tiering.py)
# ============================================================
# [필수 설치]
#   pip install openai python-dotenv
#
# [실행 방법]
#   python model_tiering.py
#
# [예상 출력]
#   질문: "Python?" (간단)
#   → 복잡도 점수: 15
#   → gpt-4o-mini 선택 (저비용)
#   
#   질문: "나인텔 EUV 공정이..." (복잡)
#   → 복잡도 점수: 85
#   → gpt-4o 선택 (고정확도)
#
# [기능]
#   - 자동 복잡도 분류
#   - 모델 자동 선택 (mini vs 4o)
#   - 비용 최적화
# ============================================================

import re
from unified_client import UnifiedLLMClient

class ModelTieringRouter:
    """
    복잡도 기반 Model Tiering
    
    기능:
    1. 복잡도 점수 계산
    2. gpt-4o-mini / gpt-4o 자동 선택
    3. 비용 최적화
    """
    
    def __init__(self, complexity_threshold: int = 40):
        """
        라우터 초기화
        
        Args:
            complexity_threshold: mini/4o 선택 기준 (기본 40점)
        """
        # (1) 통합 클라이언트
        self.client = UnifiedLLMClient()
        
        # (2) 복잡도 임계값
        self.complexity_threshold = complexity_threshold
        
        # (3) 전문 용어 리스트 (복잡도 계산용)
        self.technical_keywords = {
            # 프로그래밍
            'advanced_keywords': [
                'algorithm', 'architecture', 'optimization',
                'parallel', 'asynchronous', 'concurrency',
                'memory management', 'garbage collection',
                'compilation', 'bytecode', 'metaclass',
                '알고리즘', '구조', '최적화', '병렬',
                '동시성', '메모리', '가비지',
            ],
            
            # 수학/과학
            'math_keywords': [
                'derivative', 'integral', 'matrix', 'vector',
                'differential', 'fourier', 'probability',
                'regression', 'correlation',
                '미분', '적분', '행렬', '벡터',
                '푸리에', '확률', '회귀',
            ],
            
            # 비즈니스
            'business_keywords': [
                'strategy', 'pricing', 'valuation', 'roi',
                'cash flow', 'dividend', 'hedge',
                '전략', '가격결정', '평가', '수익률',
            ]
        }
    
    def calculate_complexity_score(self, query: str) -> int:
        """
        질문의 복잡도 점수를 계산합니다 (0~100)
        
        Args:
            query: 사용자 질문
            
        Returns:
            복잡도 점수 (0: 매우 간단, 100: 매우 복잡)
        """
        score = 0
        
        # (1) 길이 기반 점수 (0~20)
        #     길수록 복잡하다고 가정
        query_length = len(query)
        if query_length < 20:
            score += 5
        elif query_length < 50:
            score += 10
        elif query_length < 100:
            score += 15
        else:
            score += 20
        
        # (2) 문장 수 기반 점수 (0~15)
        #     여러 문장 = 여러 주제 = 복잡
        sentence_count = len(re.split(r'[.!?]', query))
        score += min(sentence_count * 5, 15)
        
        # (3) 전문 용어 기반 점수 (0~40)
        query_lower = query.lower()
        
        # advanced 키워드: 각 1점
        for keyword in self.technical_keywords['advanced_keywords']:
            if keyword in query_lower:
                score += 10
        
        # math 키워드: 각 3점
        for keyword in self.technical_keywords['math_keywords']:
            if keyword in query_lower:
                score += 12
        
        # business 키워드: 각 2점
        for keyword in self.technical_keywords['business_keywords']:
            if keyword in query_lower:
                score += 8
        
        # (4) 수학식/코드 감지 (0~15)
        #     코드 블록이나 수식 있으면 복잡
        if re.search(r'\[.*?=.*?\]|\(.*?\*.*?\)', query):  # 수식
            score += 10
        if re.search(r'def |class |import ', query):  # Python 코드
            score += 10
        if re.search(r'SELECT|INSERT|UPDATE|DELETE', query):  # SQL
            score += 10
        
        # (5) 점수 정규화 (0~100)
        score = min(score, 100)
        
        return score
    
    def select_model(self, complexity_score: int) -> tuple[str, str]:
        """
        복잡도 점수에 따라 모델을 선택합니다
        
        Args:
            complexity_score: 복잡도 점수 (0~100)
            
        Returns:
            (모델명, 사유)
        """
        # (1) 임계값과 비교
        if complexity_score < self.complexity_threshold:
            # (2) 간단한 질문 → gpt-4o-mini
            return "gpt-4o-mini", f"낮은 복잡도 ({complexity_score}점)"
        else:
            # (3) 복잡한 질문 → gpt-4o
            return "gpt-4o", f"높은 복잡도 ({complexity_score}점)"
    
    def route_and_respond(
        self,
        query: str,
        temperature: float = 0.7,
        max_tokens: int = 500
    ) -> dict:
        """
        질문을 분석하고 적절한 모델로 응답합니다
        
        Args:
            query: 사용자 질문
            temperature: 창의성
            max_tokens: 최대 길이
            
        Returns:
            라우팅 및 응답 결과
        """
        
        # (1) 복잡도 점수 계산
        complexity_score = self.calculate_complexity_score(query)
        
        # (2) 모델 선택
        model, reason = self.select_model(complexity_score)
        
        # (3) API 호출
        response = self.client.chat(
            message=query,
            model=model,
            temperature=temperature,
            max_tokens=max_tokens
        )
        
        # (4) 결과 반환
        return {
            'query': query,
            'complexity_score': complexity_score,
            'model': model,
            'selection_reason': reason,
            'response': response
        }


# ========== 테스트 ==========
if __name__ == "__main__":
    print("=" * 60)
    print("Model Tiering Router 테스트")
    print("=" * 60 + "\n")
    
    # (1) 라우터 생성
    router = ModelTieringRouter(complexity_threshold=40)
    
    # (2) 테스트 질문들 (간단 ~ 복잡)
    test_queries = [
        # 매우 간단
        "Python?",
        
        # 간단
        "Python 배우려면?",
        
        # 중간
        "Python 멀티스레딩 구현 방법과 장단점",
        
        # 복잡
        "메모리 관리와 가비지 컬렉션의 작동 원리, GIL의 영향",
        
        # 매우 복잡
        "CPU 캐시 계층 구조와 메모리 접근 패턴의 성능 영향",
    ]
    
    # (3) 각 질문을 분석
    for query in test_queries:
        print(f"[질문] {query}")
        
        complexity = router.calculate_complexity_score(query)
        model, reason = router.select_model(complexity)
        
        print(f"  복잡도: {complexity}/100")
        print(f"  모델 선택: {model}")
        print(f"  사유: {reason}")
        print()
```

---

### [13:00-13:50] 10교시: SQLite 기반 Cache Layer

#### [실습 9] cache_layer.py


```python
# ============================================================
# 실습 9: SQLite 기반 Cache Layer (cache_layer.py)
# ============================================================
# [필수 설치]
#   pip install openai python-dotenv numpy
#   (sqlite3는 내장)
#
# [실행 방법]
#   python cache_layer.py
#
# [예상 출력]
#   Exact Match: "Python?" → 캐시 히트/미스
#   Semantic Match: "Python이란?" ≈ "Python?" → 의미 매칭
#
# [기능]
#   - Exact Match: SHA256 해시 기반 정확 매칭
#   - Semantic Match: 임베딩 벡터 기반 의미 매칭
#   - TTL 관리: 만료된 캐시 자동 제거
# ============================================================

import sqlite3
import hashlib
import json
import numpy as np
from datetime import datetime, timedelta
from typing import Optional, Dict, List, Any

class SQLiteCacheLayer:
    """
    SQLite 기반 이중 캐시 시스템
    
    1. Exact Match: SHA256 해시로 정확한 질문 매칭 (100% 신뢰)
    2. Semantic Match: 임베딩 벡터로 의미 유사도 매칭 (95% 신뢰)
    """
    
    def __init__(self, db_path: str = "hybrid_cache.db"):
        """
        캐시 레이어 초기화
        
        Args:
            db_path: SQLite 데이터베이스 경로
        """
        self.db_path = db_path
        self._initialize_db()
    
    def _initialize_db(self):
        """
        데이터베이스와 테이블 초기화
        """
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # (1) 캐시 테이블 생성
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS llm_cache (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                cache_key TEXT UNIQUE NOT NULL,
                query TEXT NOT NULL,
                response TEXT NOT NULL,
                model TEXT,
                provider TEXT,
                embedding TEXT,
                tokens INTEGER DEFAULT 0,
                cost REAL DEFAULT 0.0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                expires_at TIMESTAMP,
                hit_count INTEGER DEFAULT 0
            )
        """)
        
        # (2) 인덱스 생성
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_cache_key ON llm_cache(cache_key)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_expires_at ON llm_cache(expires_at)")
        
        conn.commit()
        conn.close()
        
        print(f"[초기화] 캐시 레이어 준비 완료")
    
    def _get_cache_key(self, query: str) -> str:
        """
        질문을 SHA256 해시로 변환
        
        Args:
            query: 질문
            
        Returns:
            SHA256 해시
        """
        normalized = query.strip().lower()
        return hashlib.sha256(normalized.encode('utf-8')).hexdigest()
    
    def _generate_embedding(self, text: str) -> List[float]:
        """
        간단한 임베딩 생성 (실무에서는 openai.Embedding API 사용)
        
        Args:
            text: 임베딩할 텍스트
            
        Returns:
            임베딩 벡터 (리스트)
        """
        # (1) 프로덕션: OpenAI Embedding API 사용
        #     response = client.embeddings.create(
        #         model="text-embedding-3-small",
        #         input=text
        #     )
        #     return response.data[0].embedding
        
        # (2) 데모: 간단한 해시 기반 임베딩
        #     (정확하지 않지만, 구조 이해용)
        import hashlib
        
        text_bytes = text.encode('utf-8')
        hash_bytes = hashlib.sha256(text_bytes).digest()
        
        # (3) 해시를 부동소수점으로 변환
        embedding = [float(b) / 255.0 for b in hash_bytes[:64]]
        
        return embedding
    
    def _cosine_similarity(self, vec1: List[float], vec2: List[float]) -> float:
        """
        두 벡터의 코사인 유사도 계산
        
        Args:
            vec1, vec2: 임베딩 벡터
            
        Returns:
            유사도 (0~1, 1이 가장 유사)
        """
        # (1) NumPy로 계산
        arr1 = np.array(vec1)
        arr2 = np.array(vec2)
        
        # (2) 코사인 유사도 = (A·B) / (||A|| * ||B||)
        dot_product = np.dot(arr1, arr2)
        norm1 = np.linalg.norm(arr1)
        norm2 = np.linalg.norm(arr2)
        
        if norm1 == 0 or norm2 == 0:
            return 0.0
        
        return float(dot_product / (norm1 * norm2))
    
    def save_response(
        self,
        query: str,
        response: str,
        model: str = "unknown",
        provider: str = "unknown",
        tokens: int = 0,
        cost: float = 0.0,
        ttl_days: int = 7
    ) -> int:
        """
        응답을 캐시에 저장합니다
        
        Args:
            query: 원본 질문
            response: LLM 응답
            model: 사용한 모델
            provider: 프로바이더
            tokens: 토큰 수
            cost: 비용
            ttl_days: 유효 기간
            
        Returns:
            캐시 ID
        """
        # (1) 캐시 키 생성
        cache_key = self._get_cache_key(query)
        
        # (2) 임베딩 생성
        embedding = self._generate_embedding(query)
        embedding_json = json.dumps(embedding)
        
        # (3) TTL 계산
        expires_at = datetime.now() + timedelta(days=ttl_days)
        
        # (4) 데이터베이스 저장
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        try:
            cursor.execute("""
                INSERT INTO llm_cache
                (cache_key, query, response, model, provider, embedding, 
                 tokens, cost, expires_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (cache_key, query, response, model, provider, embedding_json,
                  tokens, cost, expires_at))
            
            conn.commit()
            cache_id = cursor.lastrowid
            
            print(f"[저장] 캐시 #{cache_id}: '{query[:20]}...'")
            return cache_id
        
        except sqlite3.IntegrityError:
            print(f"[중복] 이미 캐시됨: '{query[:20]}...'")
            return -1
        
        finally:
            conn.close()
    
    def get_response_exact(self, query: str) -> Optional[Dict[str, Any]]:
        """
        정확 일치로 캐시를 조회합니다 (100% 정확도)
        
        Args:
            query: 조회 질문
            
        Returns:
            캐시 데이터 또는 None
        """
        # (1) 캐시 키 생성
        cache_key = self._get_cache_key(query)
        
        # (2) 데이터베이스 조회
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT id, response, model, provider, tokens, cost, hit_count
            FROM llm_cache
            WHERE cache_key = ? AND (expires_at IS NULL OR expires_at > datetime('now'))
        """, (cache_key,))
        
        result = cursor.fetchone()
        
        if result:
            # (3) 히트 카운트 증가
            cache_id = result[0]
            cursor.execute("UPDATE llm_cache SET hit_count = hit_count + 1 WHERE id = ?",
                          (cache_id,))
            conn.commit()
            
            print(f"[Exact Hit] '{query[:20]}...'")
            
            return {
                'id': result[0],
                'response': result[1],
                'model': result[2],
                'provider': result[3],
                'tokens': result[4],
                'cost': result[5],
                'hit_count': result[6] + 1,
                'match_type': 'exact'
            }
        
        conn.close()
        return None
    
    def get_response_semantic(self, query: str, threshold: float = 0.95) -> Optional[Dict[str, Any]]:
        """
        의미 유사도로 캐시를 조회합니다 (95% 신뢰도)
        
        Args:
            query: 조회 질문
            threshold: 유사도 임계값 (0~1)
            
        Returns:
            캐시 데이터 또는 None
        """
        # (1) 쿼리 임베딩 생성
        query_embedding = self._generate_embedding(query)
        
        # (2) 모든 유효한 캐시 조회
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT id, query, response, model, provider, embedding, tokens, cost, hit_count
            FROM llm_cache
            WHERE embedding IS NOT NULL AND (expires_at IS NULL OR expires_at > datetime('now'))
        """)
        
        results = cursor.fetchall()
        
        best_match = None
        best_similarity = 0
        
        # (3) 모든 캐시의 유사도 계산
        for result in results:
            cached_embedding = json.loads(result[5])
            
            # (4) 코사인 유사도 계산
            similarity = self._cosine_similarity(query_embedding, cached_embedding)
            
            # (5) 임계값 초과하고 가장 유사한 것 선택
            if similarity > threshold and similarity > best_similarity:
                best_similarity = similarity
                best_match = result
        
        if best_match:
            # (6) 히트 카운트 증가
            cache_id = best_match[0]
            cursor.execute("UPDATE llm_cache SET hit_count = hit_count + 1 WHERE id = ?",
                          (cache_id,))
            conn.commit()
            
            print(f"[Semantic Hit] '{query[:20]}...' (유사도: {best_similarity:.2%})")
            
            return {
                'id': best_match[0],
                'matched_query': best_match[1],
                'response': best_match[2],
                'model': best_match[3],
                'provider': best_match[4],
                'tokens': best_match[6],
                'cost': best_match[7],
                'hit_count': best_match[8] + 1,
                'match_type': 'semantic',
                'similarity': best_similarity
            }
        
        conn.close()
        return None
    
    def get_response(self, query: str) -> Optional[Dict[str, Any]]:
        """
        먼저 정확 매칭, 실패 시 의미 매칭으로 조회합니다
        
        Args:
            query: 질문
            
        Returns:
            캐시 데이터 또는 None
        """
        # (1) 먼저 정확 매칭 시도
        exact_result = self.get_response_exact(query)
        if exact_result:
            return exact_result
        
        # (2) 정확 매칭 실패 → 의미 매칭 시도
        semantic_result = self.get_response_semantic(query, threshold=0.92)
        if semantic_result:
            return semantic_result
        
        # (3) 모두 실패
        print(f"[Cache Miss] '{query[:20]}...'")
        return None
    
    def get_stats(self) -> Dict[str, Any]:
        """
        캐시 통계 조회
        
        Returns:
            통계 딕셔너리
        """
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute("SELECT COUNT(*) FROM llm_cache")
        total = cursor.fetchone()[0]
        
        cursor.execute("SELECT SUM(hit_count) FROM llm_cache")
        total_hits = cursor.fetchone()[0] or 0
        
        cursor.execute("SELECT SUM(cost) FROM llm_cache")
        total_savings = cursor.fetchone()[0] or 0.0
        
        cursor.execute("""
            SELECT COUNT(*) FROM llm_cache
            WHERE expires_at IS NULL OR expires_at > datetime('now')
        """)
        valid = cursor.fetchone()[0]
        
        conn.close()
        
        return {
            'total_cached': total,
            'valid_cached': valid,
            'total_hits': total_hits,
            'cost_savings': total_savings
        }


# ========== 테스트 ==========
if __name__ == "__main__":
    print("=" * 60)
    print("SQLite Cache Layer 테스트")
    print("=" * 60 + "\n")
    
    # (1) 캐시 레이어 생성
    cache = SQLiteCacheLayer(db_path="test_cache.db")
    
    # (2) 응답 저장
    cache.save_response(
        query="Python이란?",
        response="Python은 고급 프로그래밍 언어입니다.",
        model="gpt-4o-mini",
        provider="openai",
        tokens=50,
        cost=0.00015
    )
    
    cache.save_response(
        query="AI란 무엇인가?",
        response="AI는 인공지능의 약자입니다.",
        model="gpt-4o-mini",
        provider="openai",
        tokens=45,
        cost=0.00013
    )
    
    print()
    
    # (3) 정확 매칭 테스트
    result1 = cache.get_response_exact("Python이란?")
    if result1:
        print(f"응답: {result1['response']}\n")
    
    # (4) 의미 매칭 테스트 (유사한 질문)
    result2 = cache.get_response_semantic("Python에 대해서?", threshold=0.85)
    if result2:
        print(f"유사 질문: '{result2['matched_query']}'")
        print(f"응답: {result2['response']}\n")
    
    # (5) 캐시 미스 테스트
    result3 = cache.get_response("JavaScript란?")
    
    print()
    
    # (6) 통계
    stats = cache.get_stats()
    print("=" * 60)
    print(f"총 캐시: {stats['total_cached']}개")
    print(f"유효한 캐시: {stats['valid_cached']}개")
    print(f"총 히트: {stats['total_hits']}회")
    print(f"절감된 비용: ${stats['cost_savings']:.6f}")
    print("=" * 60)
```

---

### [14:00-14:50] 11교시: Hybrid Engine 조립

이 교시가 핵심입니다. 지금까지 만든 모듈들을 모두 조합합니다.

#### [실습 10] hybrid_engine.py


```python
# ============================================================
# 실습 10: Hybrid Engine 조립 (hybrid_engine.py)
# ============================================================
# [필수 설치]
#   pip install openai python-dotenv numpy
#
# [사전 준비]
#   - unified_client.py, provider_router.py, model_tiering.py,
#     cache_layer.py가 같은 폴더에 있어야 함
#   - .env 파일 설정
#   - Ollama 서버 실행
#
# [실행 방법]
#   python hybrid_engine.py
#
# [아키텍처]
#   
#   사용자 질문
#        ↓
#   [1] 캐시 확인 (SQLite)
#        ├─ Exact Hit → 즉시 응답
#        └─ Semantic Hit → 즉시 응답
#        ↓
#   [2] PII 감지 (Provider Router)
#        ├─ 있음 → Ollama 선택
#        └─ 없음 → 다음 단계
#        ↓
#   [3] 복잡도 분류 (Model Tiering)
#        ├─ 간단 → gpt-4o-mini
#        └─ 복잡 → gpt-4o
#        ↓
#   [4] LLM 호출 (Unified Client)
#        ├─ 응답 획득
#        └─ 캐시에 저장
#        ↓
#   최종 응답
#
# [기능]
#   - 통합 라우팅 (PII + 복잡도 + 캐시)
#   - 자동 모델 선택
#   - 통계 추적 및 비용 계산
# ============================================================

import time
from typing import Dict, Any
from unified_client import UnifiedLLMClient
from provider_router import ProviderRouter
from model_tiering import ModelTieringRouter
from cache_layer import SQLiteCacheLayer

class HybridEngine:
    """
    완전한 Hybrid LLM 엔진
    
    조립된 모듈들:
    1. cache_layer.py - 캐시 레이어
    2. provider_router.py - PII 감지 & OpenAI/Ollama 라우팅
    3. model_tiering.py - 복잡도 분류 & 모델 선택
    4. unified_client.py - 통합 LLM 호출
    """
    
    def __init__(
        self,
        cache_db: str = "hybrid_cache.db",
        complexity_threshold: int = 40
    ):
        """
        Hybrid Engine 초기화
        
        Args:
            cache_db: 캐시 데이터베이스 경로
            complexity_threshold: 복잡도 임계값
        """
        # (1) 각 모듈 초기화
        print("[엔진 초기화] Hybrid LLM Engine")
        
        self.cache_layer = SQLiteCacheLayer(db_path=cache_db)
        print("  ✓ 캐시 레이어 준비")
        
        self.provider_router = ProviderRouter()
        print("  ✓ Provider Router 준비")
        
        self.model_tiering = ModelTieringRouter(complexity_threshold=complexity_threshold)
        print("  ✓ Model Tiering Router 준비")
        
        self.unified_client = UnifiedLLMClient()
        print("  ✓ Unified Client 준비")
        
        # (2) 통계 추적
        self.stats = {
            'total_requests': 0,
            'cache_hits': 0,
            'exact_hits': 0,
            'semantic_hits': 0,
            'pii_routed_to_ollama': 0,
            'total_tokens': 0,
            'total_cost': 0.0,
            'response_times': []
        }
    
    def process_query(
        self,
        query: str,
        temperature: float = 0.7,
        max_tokens: int = 500
    ) -> Dict[str, Any]:
        """
        질문을 전체 Hybrid 파이프라인으로 처리합니다
        
        Args:
            query: 사용자 질문
            temperature: 창의성
            max_tokens: 최대 길이
            
        Returns:
            처리 결과
        """
        # (1) 통계: 요청 카운트
        self.stats['total_requests'] += 1
        start_time = time.time()
        
        print(f"\n[요청 #{self.stats['total_requests']}] {query[:30]}...")
        
        # ========== STEP 1: 캐시 확인 ==========
        print("  [Step 1] 캐시 확인...")
        
        cache_result = self.cache_layer.get_response(query)
        if cache_result:
            # (2) 캐시 히트
            elapsed = time.time() - start_time
            
            if cache_result['match_type'] == 'exact':
                self.stats['exact_hits'] += 1
            else:
                self.stats['semantic_hits'] += 1
            
            self.stats['cache_hits'] += 1
            self.stats['response_times'].append(elapsed)
            
            print(f"    ✓ 캐시 히트! ({cache_result['match_type']})")
            print(f"    응답: {cache_result['response'][:50]}...")
            
            return {
                'query': query,
                'response': cache_result['response'],
                'source': 'cache',
                'match_type': cache_result['match_type'],
                'model': cache_result.get('model'),
                'provider': cache_result.get('provider'),
                'tokens': cache_result.get('tokens', 0),
                'cost': cache_result.get('cost', 0.0),
                'response_time': elapsed
            }
        
        print("    ✗ 캐시 미스. LLM 호출 필요")
        
        # ========== STEP 2: PII 감지 (Provider 선택) ==========
        print("  [Step 2] PII 감지...")
        
        has_pii, pii_types = self.provider_router.detect_pii(query)
        if has_pii:
            print(f"    ⚠️  PII 감지됨: {', '.join(pii_types)}")
            self.stats['pii_routed_to_ollama'] += 1
            provider_choice = 'ollama'
        else:
            print("    ✓ PII 없음")
            provider_choice = 'openai'
        
        # ========== STEP 3: 복잡도 분류 (모델 선택) ==========
        print("  [Step 3] 복잡도 분류...")
        
        complexity = self.model_tiering.calculate_complexity_score(query)
        model_choice, reason = self.model_tiering.select_model(complexity)
        
        print(f"    복잡도: {complexity}/100")
        print(f"    모델: {model_choice} ({reason})")
        
        # (3) PII가 있으면 Ollama로 오버라이드
        if has_pii:
            model_choice = "mistral:7b"
            print(f"    → PII 때문에 Ollama로 변경: {model_choice}")
        
        # ========== STEP 4: LLM 호출 (Unified Client) ==========
        print("  [Step 4] LLM 호출...")
        
        try:
            response = self.unified_client.chat(
                message=query,
                model=model_choice,
                temperature=temperature,
                max_tokens=max_tokens
            )
            
            # (4) 응답 획득 성공
            elapsed = time.time() - start_time
            
            print(f"    ✓ 응답 획득 ({elapsed:.2f}초)")
            print(f"    응답: {response[:50]}...")
            
            # ========== STEP 5: 캐시에 저장 ==========
            print("  [Step 5] 캐시 저장...")
            
            # 토큰 추정 및 비용 계산
            tokens = self.unified_client.get_token_count_estimate(response)
            
            # 비용 계산 (모델에 따라)
            if model_choice == "gpt-4o-mini":
                cost = tokens * 0.0006 / 1_000_000  # 출력 기준
            elif model_choice == "gpt-4o":
                cost = tokens * 0.015 / 1_000_000
            else:
                cost = 0.0  # Ollama는 비용 없음
            
            # (5) 캐시 저장
            cache_id = self.cache_layer.save_response(
                query=query,
                response=response,
                model=model_choice,
                provider="ollama" if has_pii else "openai",
                tokens=tokens,
                cost=cost
            )
            
            # (6) 통계 업데이트
            self.stats['total_tokens'] += tokens
            self.stats['total_cost'] += cost
            self.stats['response_times'].append(elapsed)
            
            return {
                'query': query,
                'response': response,
                'source': 'llm',
                'model': model_choice,
                'provider': "ollama" if has_pii else "openai",
                'complexity': complexity,
                'has_pii': has_pii,
                'tokens': tokens,
                'cost': cost,
                'cache_id': cache_id,
                'response_time': elapsed
            }
        
        except Exception as e:
            elapsed = time.time() - start_time
            print(f"    ✗ 오류: {str(e)}")
            
            return {
                'query': query,
                'response': f"오류 발생: {str(e)}",
                'source': 'error',
                'model': model_choice,
                'response_time': elapsed
            }
    
    def get_stats(self) -> Dict[str, Any]:
        """
        엔진 통계 조회
        
        Returns:
            통계 딕셔너리
        """
        cache_stats = self.cache_layer.get_stats()
        
        avg_response_time = (
            sum(self.stats['response_times']) / len(self.stats['response_times'])
            if self.stats['response_times'] else 0
        )
        
        cache_hit_rate = (
            self.stats['cache_hits'] / self.stats['total_requests'] * 100
            if self.stats['total_requests'] > 0 else 0
        )
        
        return {
            # 요청 통계
            'total_requests': self.stats['total_requests'],
            'cache_hits': self.stats['cache_hits'],
            'cache_hit_rate': f"{cache_hit_rate:.1f}%",
            'exact_hits': self.stats['exact_hits'],
            'semantic_hits': self.stats['semantic_hits'],
            'pii_routed_to_ollama': self.stats['pii_routed_to_ollama'],
            
            # 성능 통계
            'avg_response_time': f"{avg_response_time:.3f}초",
            'total_tokens': self.stats['total_tokens'],
            'total_cost': f"${self.stats['total_cost']:.6f}",
            
            # 캐시 통계
            'cached_items': cache_stats['total_cached'],
            'valid_cached_items': cache_stats['valid_cached'],
            'cache_savings': f"${cache_stats['cost_savings']:.6f}"
        }


# ========== 테스트 ==========
if __name__ == "__main__":
    print("=" * 60)
    print("Hybrid Engine 통합 테스트")
    print("=" * 60)
    
    # (1) 엔진 생성
    engine = HybridEngine()
    
    print()
    
    # (2) 다양한 질문 처리
    test_queries = [
        # 간단한 질문 (gpt-4o-mini 예상)
        "Python?",
        
        # 복잡한 질문 (gpt-4o 예상)
        "메모리 관리와 가비지 컬렉션의 작동 원리",
        
        # PII 포함 (Ollama 예상)
        "user@example.com의 계정 정보는?",
        
        # 캐시 재조회 (캐시 히트 예상)
        "Python?",
    ]
    
    for query in test_queries:
        result = engine.process_query(query, max_tokens=200)
    
    print("\n" + "=" * 60)
    print("엔진 통계")
    print("=" * 60)
    
    stats = engine.get_stats()
    for key, value in stats.items():
        print(f"{key}: {value}")
    
    print("=" * 60)
```

---

### [15:00-15:50] 12교시: Flask 웹앱 통합 + 대시보드

#### [실습 11] app.py


```python
# ============================================================
# 실습 11: Flask 웹앱 (app.py)
# ============================================================
# [필수 설치]
#   pip install flask openai python-dotenv numpy
#
# [실행 방법]
#   python app.py
#   브라우저에서 http://localhost:5000 접속
#
# [기능]
#   - 웹 UI: 채팅 인터페이스
#   - API: /api/chat 엔드포인트
#   - 대시보드: 실시간 통계
#   - Hybrid Engine 통합
# ============================================================

from flask import Flask, render_template, request, jsonify
from hybrid_engine import HybridEngine
import json
from datetime import datetime

# (1) Flask 앱 생성
app = Flask(__name__)

# (2) Hybrid Engine 초기화 (싱글톤)
engine = HybridEngine()

# (3) 대화 히스토리 (메모리 저장, 실무에서는 DB 사용)
conversation_history = []

# ========== API 엔드포인트 ==========

@app.route('/')
def index():
    """메인 페이지 (HTML 제공)"""
    return render_template('index.html')

@app.route('/api/chat', methods=['POST'])
def chat_api():
    """
    채팅 API 엔드포인트
    
    요청 형식:
    {
        "message": "사용자 메시지"
    }
    
    응답 형식:
    {
        "response": "AI 응답",
        "source": "cache" | "llm" | "error",
        "tokens": 150,
        "cost": 0.00045,
        "response_time": 1.23
    }
    """
    # (1) 요청 데이터 수신
    data = request.json
    user_message = data.get('message', '').strip()
    
    if not user_message:
        return jsonify({'error': '메시지가 비어있습니다'}), 400
    
    # (2) Hybrid Engine으로 처리
    result = engine.process_query(user_message)
    
    # (3) 대화 히스토리에 추가
    conversation_history.append({
        'role': 'user',
        'content': user_message,
        'timestamp': datetime.now().isoformat()
    })
    
    conversation_history.append({
        'role': 'assistant',
        'content': result['response'],
        'timestamp': datetime.now().isoformat(),
        'metadata': {
            'source': result.get('source'),
            'model': result.get('model'),
            'tokens': result.get('tokens', 0),
            'cost': result.get('cost', 0.0)
        }
    })
    
    # (4) 응답 반환
    return jsonify({
        'response': result['response'],
        'source': result.get('source'),
        'model': result.get('model'),
        'provider': result.get('provider'),
        'tokens': result.get('tokens', 0),
        'cost': f"${result.get('cost', 0.0):.6f}",
        'response_time': f"{result.get('response_time', 0):.3f}초"
    })

@app.route('/api/stats', methods=['GET'])
def stats_api():
    """
    통계 조회 API
    
    응답 형식:
    {
        "total_requests": 10,
        "cache_hit_rate": "30.0%",
        "total_cost": "$0.00456",
        ...
    }
    """
    stats = engine.get_stats()
    return jsonify(stats)

@app.route('/api/history', methods=['GET'])
def history_api():
    """대화 히스토리 조회"""
    return jsonify({
        'history': conversation_history,
        'count': len(conversation_history)
    })

@app.route('/api/clear', methods=['POST'])
def clear_api():
    """대화 히스토리 초기화"""
    global conversation_history
    conversation_history = []
    return jsonify({'status': 'cleared'})

# ========== 에러 핸들러 ==========

@app.errorhandler(404)
def not_found(error):
    return jsonify({'error': '페이지를 찾을 수 없습니다'}), 404

@app.errorhandler(500)
def internal_error(error):
    return jsonify({'error': '서버 오류가 발생했습니다'}), 500

# ========== 실행 ==========

if __name__ == '__main__':
    print("=" * 60)
    print("Flask 웹앱 시작")
    print("=" * 60)
    print("\nhttp://localhost:5000 에서 접속하세요")
    print("Ctrl+C로 종료할 수 있습니다\n")
    
    # (1) 개발 서버 실행 (자동 리로드)
    app.run(
        host='0.0.0.0',        # 모든 IP에서 접속 가능
        port=5000,             # 기본 포트
        debug=True,            # 개발 모드 (자동 리로드)
        use_reloader=False     # 단일 인스턴스 (Engine 중복 생성 방지)
    )
```

#### [실습 11] templates/index.html

```html
<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hybrid LLM Service</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
            display: grid;
            grid-template-columns: 1fr 350px;
            gap: 20px;
        }
        
        /* 메인 채팅 영역 */
        .chat-container {
            background: white;
            border-radius: 10px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.2);
            display: flex;
            flex-direction: column;
            height: 600px;
        }
        
        .chat-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px;
            border-radius: 10px 10px 0 0;
            font-weight: bold;
            font-size: 18px;
        }
        
        .chat-messages {
            flex: 1;
            overflow-y: auto;
            padding: 20px;
            background: #f5f5f5;
        }
        
        .message {
            margin-bottom: 15px;
            display: flex;
            gap: 10px;
            animation: slideIn 0.3s ease;
        }
        
        @keyframes slideIn {
            from {
                opacity: 0;
                transform: translateY(10px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        .message.user {
            justify-content: flex-end;
        }
        
        .message-content {
            max-width: 70%;
            padding: 12px 16px;
            border-radius: 10px;
            word-wrap: break-word;
        }
        
        .message.user .message-content {
            background: #667eea;
            color: white;
            border-bottom-right-radius: 0;
        }
        
        .message.assistant .message-content {
            background: white;
            color: #333;
            border: 1px solid #ddd;
            border-bottom-left-radius: 0;
        }
        
        .message-meta {
            font-size: 12px;
            color: #999;
            margin-top: 4px;
        }
        
        /* 입력 영역 */
        .chat-input-area {
            padding: 20px;
            border-top: 1px solid #ddd;
            display: flex;
            gap: 10px;
        }
        
        #message-input {
            flex: 1;
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 14px;
            resize: none;
            max-height: 100px;
        }
        
        #message-input:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 5px rgba(102, 126, 234, 0.3);
        }
        
        #send-btn {
            padding: 12px 20px;
            background: #667eea;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-weight: bold;
            transition: background 0.3s;
        }
        
        #send-btn:hover {
            background: #5568d3;
        }
        
        #send-btn:disabled {
            background: #ccc;
            cursor: not-allowed;
        }
        
        /* 사이드바 - 통계 */
        .stats-container {
            background: white;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.2);
            max-height: 600px;
            overflow-y: auto;
        }
        
        .stats-title {
            font-weight: bold;
            font-size: 16px;
            margin-bottom: 15px;
            color: #333;
        }
        
        .stat-item {
            display: flex;
            justify-content: space-between;
            padding: 10px 0;
            border-bottom: 1px solid #eee;
            font-size: 13px;
        }
        
        .stat-label {
            color: #666;
        }
        
        .stat-value {
            font-weight: bold;
            color: #667eea;
        }
        
        .loading {
            display: inline-block;
            width: 8px;
            height: 8px;
            background: #667eea;
            border-radius: 50%;
            animation: pulse 1.5s ease-in-out infinite;
        }
        
        @keyframes pulse {
            0%, 100% { opacity: 1; }
            50% { opacity: 0.5; }
        }
        
        /* 모바일 반응형 */
        @media (max-width: 768px) {
            .container {
                grid-template-columns: 1fr;
            }
            
            .message-content {
                max-width: 90%;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- 채팅 영역 -->
        <div class="chat-container">
            <div class="chat-header">
                🤖 Hybrid LLM Service
            </div>
            
            <div class="chat-messages" id="chat-messages">
                <div class="message assistant">
                    <div class="message-content">
                        안녕하세요! Hybrid LLM 서비스입니다.
                        <br/>질문을 입력해주세요. 캐시, PII 감지, 모델 자동 선택으로 최적화된 응답을 제공합니다.
                    </div>
                </div>
            </div>
            
            <div class="chat-input-area">
                <input 
                    type="text" 
                    id="message-input" 
                    placeholder="메시지를 입력하세요..." 
                    onkeypress="handleKeyPress(event)"
                />
                <button id="send-btn" onclick="sendMessage()">
                    전송
                </button>
            </div>
        </div>
        
        <!-- 통계 사이드바 -->
        <div class="stats-container">
            <div class="stats-title">📊 실시간 통계</div>
            
            <div id="stats-content">
                <div style="text-align: center; padding: 20px;">
                    <div class="loading"></div>
                    <p style="margin-top: 10px; font-size: 12px; color: #999;">
                        통계를 불러오는 중...
                    </p>
                </div>
            </div>
            
            <div style="margin-top: 20px; padding-top: 20px; border-top: 1px solid #eee;">
                <button onclick="clearHistory()" 
                        style="width: 100%; padding: 10px; background: #f0f0f0; border: 1px solid #ddd; border-radius: 5px; cursor: pointer; font-size: 12px;">
                    대화 초기화
                </button>
            </div>
        </div>
    </div>
    
    <script>
        // (1) 메시지 전송
        async function sendMessage() {
            const input = document.getElementById('message-input');
            const message = input.value.trim();
            
            if (!message) return;
            
            // (2) UI: 사용자 메시지 표시
            addMessageToChat('user', message);
            input.value = '';
            
            // (3) API 호출
            const sendBtn = document.getElementById('send-btn');
            sendBtn.disabled = true;
            
            try {
                const response = await fetch('/api/chat', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ message: message })
                });
                
                const data = await response.json();
                
                // (4) AI 응답 표시
                let assistantMsg = data.response;
                if (data.source) {
                    assistantMsg += `\n\n[출처: ${data.source}]`;
                }
                
                addMessageToChat('assistant', assistantMsg, {
                    source: data.source,
                    model: data.model,
                    tokens: data.tokens,
                    cost: data.cost,
                    response_time: data.response_time
                });
                
            } catch (error) {
                addMessageToChat('assistant', `오류: ${error.message}`);
            } finally {
                sendBtn.disabled = false;
            }
            
            // (5) 통계 업데이트
            updateStats();
        }
        
        // (2) 메시지를 화면에 추가
        function addMessageToChat(role, content, metadata = {}) {
            const messagesDiv = document.getElementById('chat-messages');
            
            const messageDiv = document.createElement('div');
            messageDiv.className = `message ${role}`;
            
            let contentHtml = `<div class="message-content">${escapeHtml(content)}</div>`;
            
            if (metadata && Object.keys(metadata).length > 0) {
                contentHtml += '<div class="message-meta">';
                if (metadata.source) contentHtml += `[${metadata.source}]`;
                if (metadata.model) contentHtml += ` (${metadata.model})`;
                if (metadata.tokens) contentHtml += ` - ${metadata.tokens} tokens`;
                if (metadata.cost) contentHtml += ` - ${metadata.cost}`;
                if (metadata.response_time) contentHtml += ` - ${metadata.response_time}`;
                contentHtml += '</div>';
            }
            
            messageDiv.innerHTML = contentHtml;
            messagesDiv.appendChild(messageDiv);
            
            // 스크롤을 하단으로
            messagesDiv.scrollTop = messagesDiv.scrollHeight;
        }
        
        // (3) HTML 이스케이프
        function escapeHtml(text) {
            const div = document.createElement('div');
            div.textContent = text;
            return div.innerHTML;
        }
        
        // (4) 엔터 키로 전송
        function handleKeyPress(event) {
            if (event.key === 'Enter' && !event.shiftKey) {
                event.preventDefault();
                sendMessage();
            }
        }
        
        // (5) 통계 업데이트
        async function updateStats() {
            try {
                const response = await fetch('/api/stats');
                const stats = await response.json();
                
                let html = '';
                for (const [key, value] of Object.entries(stats)) {
                    const label = key.replace(/_/g, ' ').toUpperCase();
                    html += `
                        <div class="stat-item">
                            <span class="stat-label">${label}</span>
                            <span class="stat-value">${value}</span>
                        </div>
                    `;
                }
                
                document.getElementById('stats-content').innerHTML = html;
                
            } catch (error) {
                console.error('통계 로드 실패:', error);
            }
        }
        
        // (6) 대화 히스토리 초기화
        async function clearHistory() {
            if (!confirm('대화 히스토리를 삭제하시겠습니까?')) return;
            
            await fetch('/api/clear', { method: 'POST' });
            
            const messagesDiv = document.getElementById('chat-messages');
            messagesDiv.innerHTML = `
                <div class="message assistant">
                    <div class="message-content">
                        대화 히스토리가 초기화되었습니다.
                    </div>
                </div>
            `;
        }
        
        // (7) 초기 통계 로드
        updateStats();
        setInterval(updateStats, 2000);  // 2초마다 업데이트
    </script>
</body>
</html>
```

---

## 프로젝트 폴더 구조

```
hybrid-llm-project/
├── .env                              # API 키 설정
├── app.py                            # Flask 웹앱 (실습 11)
├── hello_llm.py                      # OpenAI 기초 (실습 1)
├── chat_stream.py                    # 스트리밍 (실습 2)
├── function_calling.py               # Function Calling (실습 3)
├── ollama_basic.py                   # Ollama 기초 (실습 4)
├── sqlite_cache.py                   # SQLite 캐시 (실습 5)
├── unified_client.py                 # 통합 클라이언트 (실습 6) ★
├── provider_router.py                # PII & 라우팅 (실습 7)
├── model_tiering.py                  # 복잡도 분류 (실습 8)
├── cache_layer.py                    # 캐시 레이어 (실습 9)
├── hybrid_engine.py                  # 최종 조립 (실습 10) ★★
├── verify_env.py                     # 환경 검증
├── templates/
│   └── index.html                    # 웹 UI (실습 11)
├── hybrid_cache.db                   # 캐시 DB (자동 생성)
├── cache.db                          # 캐시 DB (자동 생성)
└── requirements.txt                  # 필수 패키지
```

---

## 트러블슈팅 가이드

### 1. OPENAI_API_KEY 오류

**증상:** `AuthenticationError: Invalid API key provided`

**해결:**
```bash
# .env 파일 확인
cat .env

# API 키 형식 확인: sk-로 시작해야 함
# 공백이나 따옴표 확인
```

### 2. Ollama 연결 실패

**증상:** `Connection refused: localhost:11434`

**해결:**
```bash
# 별도 CMD에서 Ollama 서버 실행
ollama serve

# 모델 확인
ollama ls

# 필요한 모델 다운로드
ollama pull mistral:7b
```

### 3. SQLite 잠금 오류

**증상:** `database is locked`

**해결:**
```python
# 연결 시 타임아웃 설정
conn = sqlite3.connect(db_path, timeout=30)
```

### 4. 토큰 초과 오류

**증상:** `This model's maximum context length is 4096 tokens`

**해결:**
```python
# max_tokens 감소
response = client.chat.completions.create(
    max_tokens=500  # 기본값 2000에서 감소
)
```

### 5. Flask 포트 이미 사용중

**증상:** `Address already in use`

**해결:**
```bash
# 포트 변경
# app.py에서:
app.run(port=5001)

# 또는 기존 프로세스 종료
netstat -ano | findstr :5000
taskkill /PID [PID] /F
```

### 6. 임베딩 벡터 계산 느림

**증상:** 의미 매칭이 느린 경우

**해결:**
```python
# 캐시 수가 많으면 semantic 매칭 스킵
if self.cache_layer.get_stats()['total_cached'] > 1000:
    return exact_match_only  # 정확 매칭만 사용
```

### 7. 메모리 부족

**증상:** 프로세스가 무거워짐

**해결:**
```python
# 캐시 자동 정리
cache_layer.clear_expired()

# 또는 오래된 캐시 삭제
cursor.execute("""
    DELETE FROM llm_cache 
    WHERE created_at < datetime('now', '-30 days')
""")
```

### 8. 모델 응답이 한글 깨짐

**증상:** 응답 텍스트에 이상한 문자

**해결:**
```python
# 인코딩 명시
response.choices[0].message.content.encode('utf-8').decode('utf-8')
```

### 9. 캐시가 적용 안 됨

**증상:** 같은 질문인데도 매번 API 호출

**해결:**
```python
# 쿼리 정규화 확인
normalized = query.strip().lower()
# 공백, 대소문자 정확히 확인
```

### 10. Ollama 응답 품질 낮음

**증상:** 전문 분야 질문 오류율 높음

**해결:**
```python
# 복잡도가 높으면 OpenAI로 변경
if complexity > 70:
    model = "gpt-4o"  # Ollama 사용 안 함
```

### 11. 비용이 예상보다 높음

**증상:** 월간 비용 초과

**해결:**
```python
# 캐시 히트율 확인
cache_hit_rate = cache_hits / total_requests

# 낮으면 TTL 증가
ttl_days=30  # 7일에서 30일로

# 또는 gpt-4o-mini 비율 증가
if complexity < 50:
    model = "gpt-4o-mini"  # 더 낮은 기준
```

### 12. 대화 히스토리 손실

**증상:** Flask 재시작 후 대화 사라짐

**해결:**
```python
# 메모리 대신 SQLite 저장
cursor.execute("""
    CREATE TABLE conversations (
        id INTEGER PRIMARY KEY,
        user_id TEXT,
        role TEXT,
        content TEXT,
        timestamp TIMESTAMP
    )
""")
```

---

## 까칠한 수강생 Q&A 모음

### 섹션 1: 기술 상세 질문

**Q1: "왜 SQLite를 사용하고 Redis를 안 쓰나요?"**

A: 훌륭한 질문입니다. 선택 기준:
- SQLite: 파일 기반, 설치 불필요, 학습용/소형 서비스
- Redis: 메모리 기반, 매우 빠름, 대규모 트래픽

이 강의는 **학습과 소형 서비스**에 초점을 맞춰서 SQLite를 선택했습니다. 프로덕션에서 일일 100만 요청 이상이면 Redis로 업그레이드하세요.

**Q2: "임베딩 벡터는 왜 JSON으로 저장하고 별도 벡터 DB 안 쓰나요?"**

A: 좋은 지적입니다. 현실적 이유:
- 강의: SQLite만으로 완결성 있게 구현 (의존성 최소)
- 프로덕션: Pinecone, Weaviate 같은 벡터 DB 추천

의미 매칭이 복잡해지면 벡터 DB로 업그레이드하세요. 그 때 코드는 cache_layer.py의 메서드만 바꾸면 됩니다.

**Q3: "Function Calling의 오류율은 얼마나 높은가요?"**

A: gpt-4o-mini 기준:
- 간단한 함수 (1~2개): 98% 정확도
- 복잡한 함수 (3개 이상): 85~90% 정확도
- 인수 파싱 오류: 5% 미만

따라서:
- 함수는 3개 이하로 유지
- 정의를 명확하게
- 오류 처리(try/except) 필수

**Q4: "Ollama는 정말로 OpenAI 없이 작동하나요?"**

A: 완전히 YES입니다. Ollama의 강점:
- 100% 오프라인 작동
- 개인 컴퓨터에서 실행
- OpenAI 유료 API 불필요

단점:
- 정확도는 gpt-4o의 70~80% 수준
- 응답이 느림 (CPU면 2~10초)
- GPU 필요 (빠른 응답용)

전략: **간단한 질문**만 Ollama로 처리하세요.

**Q5: "여러 사용자를 지원하려면 어떻게 하나요?"**

A: 현재 코드는 단일 사용자 가정입니다. 멀티 유저로 확장:

```python
# 사용자별 캐시 분리
cache_key = hashlib.sha256(
    f"{user_id}:{query}".encode()
).hexdigest()

# 또는 사용자별 SQLite DB
db_path = f"cache_{user_id}.db"
cache = SQLiteCacheLayer(db_path)
```

추가로:
- 사용자 인증 (Flask-Login)
- 세션 관리
- 사용자별 통계

---

### 섹션 2: 실무 적용 질문

**Q1: "이 시스템을 실제 서비스에 바로 쓸 수 있나요?"**

A: 부분적으로 YES입니다.
- ✅ 사용 가능: 학습 플랫폼, 내부 도구
- ⚠️  준비 필요: 고객 서비스 챗봇
- ❌ 부족함: 고대규모 서비스 (일일 100만+)

프로덕션 준비:
1. 사용자 인증 추가
2. 데이터베이스를 PostgreSQL로 업그레이드
3. Redis 캐시 도입
4. 모니터링/로깅 추가
5. 보안 감사

**Q2: "비용을 더 줄일 수 있을까요?"**

A: 몇 가지 전략:
1. gpt-4o-mini 사용 비율↑ (현재 50% → 70%)
   - 월 비용 23% → 40% 절감
2. 캐시 TTL 연장 (7일 → 30일)
   - 캐시 히트율 30% → 50%
3. Ollama 사용 확대
   - PII뿐 아니라 "간단한" 모든 질문 → Ollama
4. 배치 처리
   - 야간에 비용 싼 모델 사용

이러한 최적화로 **월 60% 절감** 가능합니다.

**Q3: "한국어 처리가 제대로 될까요?"**

A: 현재 구현의 문제점:
- ❌ 토큰 수 추정: 부정확 (4글자=1토큰 규칙 → 한국어는 2글자=1토큰)
- ❌ 복잡도 분류: 한글 정규식 부족
- ❌ PII 감지: 한국 주민등록번호는 정규식으로 가능

한국어 최적화:
```python
# 한국어 토큰 수 정확 계산
response = client.embeddings.create(
    model="text-embedding-3-small",
    input=korean_text
)
# 임베딩 길이로 토큰 추정

# 한국어 NER (개체명 인식)
from kobert_tokenizer import KoBERTTokenizer
tokenizer = KoBERTTokenizer.from_pretrained('skt/kobert-base-v1')
```

**Q4: "이 시스템에 RAG를 추가할 수 있을까요?"**

A: 완전히 가능합니다! RAG 추가:

```python
# Step 1: 문서 임베딩
from sentence_transformers import SentenceTransformer
model = SentenceTransformer('intfloat/multilingual-e5-base')

# Step 2: 질문과 유사한 문서 검색
query_embedding = model.encode(query)
similar_docs = search_in_vector_db(query_embedding, top_k=3)

# Step 3: 컨텍스트 추가
context = "\n".join(similar_docs)
messages.append({
    "role": "system",
    "content": f"Context: {context}"
})

# Step 4: Hybrid Engine으로 처리
response = engine.process_query(query)
```

**Q5: "모니터링을 어떻게 해야 할까요?"**

A: 기본 모니터링 지표:
- API 응답 시간 (목표: < 1초)
- 캐시 히트율 (목표: > 40%)
- 오류율 (목표: < 1%)
- 월간 비용

추천 도구:
- Prometheus: 메트릭 수집
- Grafana: 시각화
- DataDog: 클라우드 모니터링

간단한 구현:
```python
import logging

logging.basicConfig(
    filename='hybrid_llm.log',
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)

logger = logging.getLogger(__name__)
logger.info(f"Query: {query}, Response time: {elapsed:.3f}s")
```

---

### 섹션 3: 성능 최적화 질문

**Q1: "응답 시간을 1초 이하로 줄일 수 있을까요?"**

A: 가능합니다! 최적화 우선순위:

1. **캐시 히트율↑** (30% → 70%)
   - 영향: 캐시 히트 시 < 10ms (10배 빠름)
   - 방법: TTL 30일, semantic matching 비율↑

2. **Ollama GPU 활용**
   - 영향: 2~10초 → 0.5~2초 (10배 빠름)
   - 방법: RTX 3060 이상 GPU

3. **gpt-4o-mini 사용 비율↑**
   - 영향: 기본 응답 1~3초 → 0.5~1초
   - 방법: 복잡도 기준 낮춤

4. **병렬 처리**
   - 여러 요청을 동시 처리
   - FastAPI + asyncio 사용

조합 시: **총 20배 속도 개선** 가능

**Q2: "메모리 누수가 있을 수 있을까요?"**

A: 주의할 점:
- ❌ 대화 히스토리 메모리 저장 (무한 증가)
- ❌ 임베딩 벡터 전체 로드 (캐시 크기 증가)
- ❌ SQLite 연결 미종료

해결:
```python
# 1. 메모리 제한
MAX_HISTORY = 1000
if len(conversation_history) > MAX_HISTORY:
    conversation_history = conversation_history[-1000:]

# 2. 연결 종료
conn.close()  # 필수!

# 3. 주기적 정리
cache_layer.clear_expired()
```

**Q3: "동시 요청 100개가 들어오면?"**

A: 현재 구현의 문제:
- Flask 기본: 동시 5~10개만 처리 가능
- SQLite: 동시 쓰기 불가능 (락 발생)

해결책:
```python
# 1. Gunicorn으로 다중 워커
gunicorn -w 4 -b 0.0.0.0:5000 app:app

# 2. PostgreSQL로 업그레이드
# SQLite → PostgreSQL (락 문제 해결)

# 3. 이벤트 큐 도입
# Redis Queue (RQ) 또는 Celery
task = q.enqueue(engine.process_query, query)
```

**Q4: "캐시 크기가 무한정 증가하지 않을까요?"**

A: 맞습니다. 대책:
```python
# 1. 파티셔닝
# 월별로 DB 분리
db_path = f"cache_{year}_{month}.db"

# 2. 자동 정리
# 30일 이상 미사용 캐시 삭제
cursor.execute("""
    DELETE FROM llm_cache 
    WHERE (expires_at <= datetime('now')
    OR hit_count = 0
    AND created_at < datetime('now', '-30 days'))
""")

# 3. 압축
# SQLite VACUUM
cursor.execute("VACUUM")
```

**Q5: "얼마나 많은 요청을 처리할 수 있을까요?"**

A: 벤치마크 (단일 서버 기준):

| 구성 | QPS | 월간 요청 |
|------|-----|---------|
| Flask (단일) | 10-20 | 26M-52M |
| Flask + Gunicorn (4 워커) | 40-80 | 104M-208M |
| FastAPI + 8 워커 | 100-200 | 260M-520M |

**결론:** 
- 소형 서비스: Flask만으로 충분
- 중형: Gunicorn + 4 워커
- 대형: FastAPI + 로드 밸런싱

---

### 섹션 4: 학습 및 심화 질문

**Q1: "Attention mechanism이 왜 중요한가요?"**

A: Transformer의 핵심:
- 전체 문장을 한 번에 처리 (RNN은 순차 처리)
- 단어 간 관계 직접 계산
- 병렬 처리로 빠름

결과:
```
RNN (LSTM):  100단어 처리 10초 (순차)
Transformer: 100단어 처리 0.1초 (병렬) → 100배 빠름
```

이것이 GPT가 가능한 이유입니다.

**Q2: "토큰화가 정확하지 않으면?"**

A: 부작용:
- ❌ 비용 계산 오류 (예상 $1, 실제 $1.5)
- ❌ 컨텍스트 초과 (텍스트 중간 절단)
- ❌ 특수문자 처리 오류

정확한 토큰화:
```python
# OpenAI 공식 라이브러리
import tiktoken

enc = tiktoken.encoding_for_model("gpt-4o-mini")
tokens = enc.encode(text)
print(len(tokens))  # 정확한 토큰 수
```

**Q3: "실제로 할루시네이션을 줄일 수 있을까요?"**

A: 부분적으로 가능:
```python
# 1. Temperature 낮춤
temperature=0.3  # 0.7에서 낮춤 → 더 결정적

# 2. RAG 추가
# 외부 정보로 근거 제공

# 3. Prompt Engineering
system_message = "당신은 팩트만 제시하는 도우미입니다. 확실하지 않으면 '모르겠습니다'라고 답하세요."
```

효과:
- 온도 조정: 할루시네이션 50% 감소
- RAG: 70% 감소
- 둘 다: 80%+ 감소

**Q4: "Fine-tuning은 필요할까요?"**

A: 고려 기준:

| 상황 | 필요성 | 비용 | 효과 |
|------|--------|------|------|
| 일반 Q&A | 불필요 | - | - |
| 특정 도메인 (의료/법률) | 매우 필요 | $0-5K | 정확도 +20% |
| 스타일 맞춤 | 추천 | $1K-10K | 품질 +30% |
| 신규 작업 | 필요 | $5K-50K | 새로운 능력 |

**결론:** 시작은 Prompt Engineering으로 → Fine-tuning은 나중

**Q5: "이 강의 후 다음 단계는?"**

A: 추천 로드맵:

1. **1주:** 현재 Hybrid Engine 완전 이해
2. **2주:** 실제 서비스에 적용 (내부 도구)
3. **1개월:** 
   - RAG 추가
   - FastAPI로 업그레이드
   - 모니터링 추가
4. **2개월:**
   - Fine-tuning 시작
   - 사용자 인증 추가
   - 관리자 대시보드
5. **3개월:**
   - 프로덕션 배포
   - 실시간 모니터링

참고 자료:
- OpenAI 공식 문서: https://platform.openai.com/docs
- LangChain: RAG/Agent 라이브러리
- Ollama 커뮤니티: 로컬 모델 최적화

---

## 프로젝트 폴더 구조 (최종)

```
hybrid-llm-project/
├── requirements.txt              # pip install -r requirements.txt
├── .env                          # OPENAI_API_KEY=sk-...
├── .gitignore                    # cache.db, __pycache__ 등
│
├── [Day 1 - 기초]
├── hello_llm.py                  # 실습 1: OpenAI API 첫 호출
├── chat_stream.py                # 실습 2: 스트리밍 대화
├── function_calling.py           # 실습 3: Function Calling
├── ollama_basic.py               # 실습 4: Ollama 기초
├── sqlite_cache.py               # 실습 5: SQLite 캐시
│
├── [Day 2 - 조립]
├── unified_client.py             # 실습 6: 통합 클라이언트 ★핵심1
├── provider_router.py            # 실습 7: PII 감지 & 라우팅
├── model_tiering.py              # 실습 8: 모델 자동 선택
├── cache_layer.py                # 실습 9: SQLite 캐시 레이어
├── hybrid_engine.py              # 실습 10: 최종 조립 ★핵심2
├── app.py                        # 실습 11: Flask 웹앱
│
├── [보조]
├── verify_env.py                 # 환경 검증 스크립트
├── templates/
│   └── index.html                # 웹 UI
│
├── [데이터]
├── hybrid_cache.db               # 캐시 데이터베이스 (자동 생성)
├── cache.db                      # 테스트 캐시 DB
│
└── [문서]
    └── README.md                 # 사용 설명서
```

---

## Red Team 검토 — 5가지 문제점

| # | 문제점 | 심각도 | 개선 방안 |
|---|--------|--------|-----------|
| 1 | **정규식 PII 감지의 한계**: "A사의 비공개 계약 조건"처럼 키워드가 없는 민감 정보를 놓칠 수 있음 | 🔴 높음 | 1차 정규식 + 2차 LLM(gpt-4o-mini) 분류 파이프라인 도입. classify_sensitivity_llm() 메서드가 이미 provider_router.py에 준비되어 있으므로 주석 해제하여 활성화 |
| 2 | **Semantic Cache 오답 위험**: threshold 0.85에서 "Python 리스트 정렬"과 "Python 리스트 역순"이 매칭될 수 있음 | 🔴 높음 | threshold를 0.92~0.95로 상향. 캐시 응답과 함께 원래 질문을 반환하여 사용자 검증 가능하게 함. 피드백 기반 캐시 무효화(invalidation) 기능 추가 |
| 3 | **SQLite 동시 쓰기 제한**: WAL 모드 사용해도 동시 쓰기가 많으면 `database is locked` 오류 발생 가능 | 🟡 중간 | 교육 환경에서는 문제없음을 명시. 프로덕션: PostgreSQL 또는 Redis로 캐시 계층 교체. SQLiteCacheLayer의 인터페이스는 유지하되 내부 구현만 교체하는 어댑터 패턴 적용 |
| 4 | **API Key 보안**: `.env` 파일이 Git에 커밋되거나 로그에 노출될 위험 | 🔴 높음 | `.gitignore`에 `.env` 추가 필수 (verify_env.py에서 체크 추가). 프로덕션: AWS Secrets Manager, Azure Key Vault 등 시크릿 관리 서비스 사용. 로그 출력 시 API 키 마스킹 처리 |
| 5 | **Embedding API 호출 비용 누적**: Semantic Cache 조회마다 OpenAI Embedding API를 호출하므로 대량 요청 시 비용 발생 ($0.02/1M 토큰이지만 누적됨) | 🟡 중간 | 로컬 Embedding 모델(sentence-transformers/all-MiniLM-L6-v2)로 전환 시 비용 $0 달성 가능. 또는 Embedding 결과 자체도 SQLite에 캐싱하여 동일 쿼리의 재 Embedding 방지 |

---

## 재사용 가능한 템플릿

### 템플릿 1: 새로운 라우터 추가

```python
class CustomRouter:
    """커스텀 라우팅 로직"""
    
    def __init__(self):
        self.client = UnifiedLLMClient()
    
    def route_and_respond(self, query: str) -> dict:
        # 1. 분석 (복잡도, PII, 토픽 등)
        analysis = self.analyze(query)
        
        # 2. 모델 선택
        model = self.select_model(analysis)
        
        # 3. API 호출
        response = self.client.chat(query, model=model)
        
        return {
            'response': response,
            'model': model,
            'analysis': analysis
        }
    
    def analyze(self, query: str) -> dict:
        # 분석 로직 구현
        pass
    
    def select_model(self, analysis: dict) -> str:
        # 모델 선택 로직 구현
        pass
```

### 템플릿 2: 새로운 캐시 전략

```python
class CustomCacheStrategy:
    """커스텀 캐시 전략"""
    
    def __init__(self, db_path: str):
        self.db_path = db_path
        self._init_db()
    
    def get(self, key: str) -> Optional[str]:
        # 캐시 조회 로직
        pass
    
    def set(self, key: str, value: str, ttl: int = 3600):
        # 캐시 저장 로직
        pass
    
    def delete_expired(self):
        # 만료 캐시 제거 로직
        pass
```

### 템플릿 3: API 확장

```python
@app.route('/api/custom', methods=['POST'])
def custom_endpoint():
    """커스텀 엔드포인트"""
    data = request.json
    
    # 커스텀 로직
    result = engine.process_query(data['query'])
    
    return jsonify({
        'status': 'success',
        'data': result
    })
```

### 템플릿 4: 배치 처리

```python
def batch_process(queries: List[str]) -> List[dict]:
    """여러 질문을 한 번에 처리"""
    results = []
    
    for query in queries:
        result = engine.process_query(query)
        results.append(result)
    
    return results

# 사용
queries = ["Python?", "AI란?", "LLM?"]
results = batch_process(queries)
```

---

## 브랜드화 방안

### 1. 로고 & 색상

```
강의명: "Hybrid LLM 프로 완성반"
로고 색: 보라색 (#667eea) + 핑크색 (#764ba2)
슬로건: "비용 ↓, 속도 ↑, 개인정보 보호 ↑"
```

### 2. 마케팅 포인트

```
핵심 메시지:
- "3일만에 완전한 LLM 서비스 구축"
- "OpenAI 비용 23~60% 절감"
- "개인정보 보호하면서 AI 활용"

타겟: Python 3~5년 경력 실무자
```

### 3. 수료증

```
┌─────────────────────────────────┐
│  Hybrid LLM Service             │
│   Professional Certificate      │
│                                 │
│  Certificate ID: HLS-2025-XXXX  │
│  Issued Date: 2025-03-21        │
│  Skill: Hybrid LLM Implementation│
│        Cache Optimization       │
│        Cost Reduction           │
└─────────────────────────────────┘
```

### 4. 강의 후속 서비스

```
- 취업 지원: LLM 개발자 채용 매칭
- 실무 프로젝트: 회사 도입 지원
- 스터디 그룹: 월간 모임 & 네트워킹
- 고급 과정: RAG, Fine-tuning, 멀티모달
```

### 5. 커뮤니티

```
- 슬랙 채널: 질문 & 피드백
- GitHub 레포: 코드 공유 & 풀리퀘스트
- 월간 웨비나: 최신 기술 동향
- 포트폴리오: 수료자 프로젝트 전시
```

---

## 강의 핵심 요약

### 배운 것

1. **OpenAI & Ollama API** (실습 1~4)
   - ChatGPT API 호출 방법
   - 스트리밍 처리
   - Function Calling
   - 로컬 LLM (Ollama) 활용

2. **SQLite 캐시** (실습 5, 9)
   - Exact Match: 100% 정확도
   - Semantic Match: 95% 신뢰도
   - TTL 관리

3. **Hybrid 라우팅** (실습 6~8, 10)
   - 통합 클라이언트 (프로바이더 투명화)
   - PII 감지 (개인정보 보호)
   - 복잡도 분류 (모델 자동 선택)
   - 최종 조립 (모든 모듈 통합)

4. **실제 서비스 배포** (실습 11)
   - Flask 웹앱
   - REST API
   - 실시간 대시보드

### 실무 적용 시나리오

| 서비스 | 활용 방식 |
|--------|---------|
| 고객 상담봇 | PII 감지 → Ollama, 캐시 활용 |
| 내부 업무 도구 | 모든 기능 활용 (비용 최소) |
| 의료/금융 시스템 | PII → Ollama, 규제 준수 |
| 검색 보강 (RAG) | 캐시 + Hybrid 라우팅 |

### 다음 단계

**1주: 심화**
- 실제 데이터로 테스트
- 캐시 히트율 측정
- 비용 절감 확인

**2주: 확장**
- RAG 추가 (외부 정보)
- Fine-tuning (맞춤 모델)
- 사용자 인증

**1개월: 배포**
- 클라우드 호스팅 (AWS/Azure/GCP)
- 프로덕션 모니터링
- 성능 최적화

**3개월: 마스터**
- 멀티모달 (이미지/음성)
- 에이전트 시스템
- 고급 임베딩

---

## 참고자료

### 공식 문서
- [OpenAI API Docs](https://platform.openai.com/docs)
- [Ollama Documentation](https://github.com/ollama/ollama)
- [Flask Documentation](https://flask.palletsprojects.com)
- [SQLite Documentation](https://www.sqlite.org/docs.html)

### 학습 자료
- OpenAI Cookbook: https://github.com/openai/openai-cookbook
- LangChain Docs: https://python.langchain.com
- RAG Best Practices: https://huggingface.co/learn

### 커뮤니티
- OpenAI 커뮤니티 포럼
- Ollama GitHub Discussions
- r/LocalLLM (Reddit)
- HuggingFace Discussions

### 추천 도서
- "The Transformer Book" (개념 이해)
- "Designing Machine Learning Systems" (시스템 설계)
- "LLMOps" (운영 가이드)

